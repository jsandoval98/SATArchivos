﻿Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL
Imports SAT.SeguridadSAT.Encriptacion

Partial Class modulos_VerPagosDolares
    Inherits System.Web.UI.Page

#Region " Variables Privadas "
    Private mstrCodTx As String = ""
#End Region

#Region " Eventos "
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        mstrCodTx = GetURL("cod")
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Protected Sub btnReenviar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReenviar.Click
        Dim ds As DataSet
        Dim strMensaje As String = ""
        Try
            strMensaje = Convert.ToString(ViewState("strMensajeCorreo"))
            If ValidaCadena(Me.txtCorreoReenvio.Text) <> "" Then
                Using oBLL As New ConsultasWeb
                    oBLL.EnviarCorreoTexto(GetConexionPagosVirtuales, "PAGOS VIRTUALES <pagovirtual@sat.gob.pe>", ValidaCadena(Me.txtCorreoReenvio.Text) + ";pagovirtual@sat.gob.pe", "Pago Virtual SAT - Reenvio de Constancia", strMensaje)
                End Using
                Me.lblMensajeServer.Text = "La constancia se ha reenviado a: " + Me.txtCorreoReenvio.Text
                Me.btnReenviar.Enabled = False
            End If
        Catch ex As Exception
            'Using oFile As New System.IO.StreamWriter(Web.HttpContext.Current.Server.MapPath("~/App_Data/VerPagosDolares.txt"), True)
            '    oFile.WriteLine("-----------------------" + Date.Now.ToString("dd/MM/yyyy HH:mm:ss") + "-------------------")
            '    oFile.WriteLine("Acción : " & "btnReenviar_Click")
            '    oFile.WriteLine("Mensaje : " & ex.Message)
            '    oFile.WriteLine("Source  : " & ex.Source)
            'End Using
        Finally
            ds = Nothing
        End Try
    End Sub
#End Region

#Region " Métodos Privados "
    ''' <summary>Método para mostrar la información en los controles web al cargar el formulario web.</summary>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor>David Miranda P.</CreadoPor></item>
    ''' <item><FecCrea>29/03/2010</FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu></FecActu></item>
    ''' <item><Resp></Resp></item>
    ''' <item><Mot></Mot></item></list></remarks>
    Private Sub Inicio()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario, strCorreo, strTransaccion, strFechaHora, strTotalPagado As String
        Dim strMensaje As String = ""
        Try
            Me.lblTitulo.Text = "CONSTANCIA DE PAGOS VIRTUALES"
            If mstrCodTx.Length > 0 Then
                ds = oBLL.PagosVirtualesBuscarDetalleTransaccion(GetConexionPagosVirtuales, mstrCodTx.Substring(0, 1), mstrCodTx)
                If Not ds Is Nothing Then
                    If ds.Tables(0).Rows.Count > 0 Then
                        With ds.Tables(0).Rows(0)
                            strUsuario = CheckStr(.Item("Usuario"))
                            strCorreo = CheckStr(.Item("VCUSR_EMAIL"))
                            strTransaccion = CheckStr(.Item("VCTRN_NUMERO"))
                            strFechaHora = CheckStr(.Item("DTTRN_FECHAHORAINICIO"))
                            strTotalPagado = CheckDbl(.Item("NMTRN_MONTO")).ToString("#,#0.00")
                        End With
                        Me.lblCorreo.Text = strCorreo
                        Me.lblFechaHora.Text = strFechaHora
                        Me.lblOperación.Text = strTransaccion
                        Me.lblTotalPagado.Text = "US$ " + strTotalPagado
                        Me.lblUsuario.Text = strUsuario
                        Me.lblTrama.Text = Encrypt(strTransaccion, CDate(strFechaHora).AddDays(33).ToString("ddmmyyyy"))

                        If CheckStr(ds.Tables(0).Rows(0)("EnvioMail")) = "" Then
                            strMensaje = "Sr(a/ita/s): " & strUsuario & Chr(13) & Chr(13)
                            strMensaje = strMensaje & "Su transaccion se ha realizado con exito. Los datos registrados del pago para la Conferencia Internacional 'Modelos de Gestión Publica y Tributacion Local' son:" & Chr(13) & Chr(13)
                            strMensaje = strMensaje & "Numero de pedido: " & strTransaccion & Chr(13)
                            strMensaje = strMensaje & "Fecha hora: " & strFechaHora & Chr(13)
                            strMensaje = strMensaje & "Monto Total Pagado: " & Me.lblTotalPagado.Text & Chr(13) & Chr(13)
                            strMensaje = strMensaje & Chr(13) & "Gracias por utilizar el Servicio de Pagos en Linea - SAT." & Chr(13)
                            strMensaje = strMensaje & Chr(13) & "Recuerde que sus pagos se procesan en el momento." & Chr(13) & Chr(13)
                            strMensaje = strMensaje & "PD: Las tildes y enies se han omitido para evitar problemas de compatibilidad entre los software de correo electronico"
                            '*** enviar correo ****
                            oBLL.EnviarCorreoTexto(GetConexionPagosVirtuales, "PAGOS VIRTUALES <pagovirtual@sat.gob.pe>", strCorreo + ";pagovirtual@sat.gob.pe", "Pago Virtual SAT", strMensaje)
                            ViewState("strMensajeCorreo") = strMensaje
                            '*** registrar envio de correo ****
                            oBLL.PagosVirtualesRegistrarEnvioCorreo(GetConexionPagosVirtuales, strTransaccion, strCorreo)
                        End If
                    End If
                End If
                Me.grdCarrito.DataSource = ds.Tables(0)
                Me.grdCarrito.DataBind()
            Else
                Redireccionar(Paginas.Inicio)
            End If
        Catch ex As Exception
            'Using oFile As New System.IO.StreamWriter(Web.HttpContext.Current.Server.MapPath("~/App_Data/VerPagosDolares.txt"), True)
            '    oFile.WriteLine("-----------------------" + Date.Now.ToString("dd/MM/yyyy HH:mm:ss") + "-------------------")
            '    oFile.WriteLine("Acción : " & "Inicio")
            '    oFile.WriteLine("Mensaje : " & ex.Message)
            '    oFile.WriteLine("Source  : " & ex.Source)
            'End Using
        Finally
            If Not (oBLL Is Nothing) Then oBLL.Dispose()
            ds = Nothing
            oBLL = Nothing
        End Try
    End Sub
#End Region

End Class
