﻿Imports System.Web.Security

Partial Class Modulos_ReporteServer
    Inherits System.Web.UI.Page

   Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      If Not IsPostBack Then
         pInicio()
      End If
   End Sub

   Private Sub pInicio()
      Me.lblSesionesActivas.Text = Application("UsuariosActivos")
   End Sub

End Class
