Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports SAT.HomeSiteBLL
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports System.Text

Partial Class TributosRef
    Inherits PageBase

    Private mintCodigoUsuario As Integer
    Private mintCodVeh As Integer = 0

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ValidarPagina()
        ValidarCodigoBuscado()
        mintCodigoUsuario = FuncionesWeb.GetCodigoBuscado
        '-----------------------------------------------
        If IsNumeric(FuncionesWeb.GetURL("codveh")) Then
            mintCodVeh = CInt(FuncionesWeb.GetURL("codveh"))
        Else
            If IsNumeric(Session("codveh")) Then
                mintCodVeh = CInt(Session("codveh"))
            End If
        End If
        If mintCodVeh > 0 Then
            Session("codveh") = mintCodVeh
        End If
        '-----------------------------------------------
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If
        VerificarEstadoPagos()
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        CargarAnios(Me.ddlAnio)
        CargarEstadoDocumento(Me.ddlEstado)
        Me.lblTitulo.Text = GetConceptoDescripcion().ToUpper
        Me.lblAdministrado.Text = mintCodigoUsuario.ToString + " - " + GetAdministradoBuscado()
        Session("administrado") = Me.lblAdministrado.Text
        Me.btnBuscar.Attributes.Add("onclick", "return MenuAlertaProceso()")
        Me.lblFechaSistema.Text = "Fecha de consulta: " + GetFecha()
        'mostrar estado de cuenta
        pBuscarEstadoCuenta()

    End Sub

    Private Sub VerificarEstadoPagos()
        If GetEstadoPagos() Then
            Me.grdEstadoCuenta.Columns(0).Visible = True
        Else
            Me.grdEstadoCuenta.Columns(0).Visible = False
        End If
    End Sub

    Public Function CampoBeneficio() As Boolean
        Dim bolEstado As Boolean = False
        If GetEstadoBeneficio(CInt(Me.ddlAnio.SelectedValue)) Then
            bolEstado = True
        End If
        Return bolEstado
    End Function

    Public Function GetAdministrado() As String
        Return Me.lblAdministrado.Text
    End Function

    Private Sub pBuscarEstadoCuenta()
        Dim oBLL As New ConsultasVarias
        Dim dsDeuda As DataSet
        Dim intAnio As Integer = 0
        Dim intEstado As Integer = 0
        Dim i, intCantidad, j As Integer
        Dim bolRef As Boolean = False
        Dim strReferencia, strReferenciaAnterior As String
        Dim bolBeneficio As Boolean = False
        Dim dblTotalDeudaSin As Double = 0
        Dim dblTotalDeudaCon As Double = 0
        Dim strFileTemp As String = ""
        Dim dtRef As DataTable
        Dim drRef As DataRow
        Dim strReferenciaBusqueda As String = ""
        Dim intPeriodo As Integer
        Dim strTipoReporte As String = "T1W"

        Me.lblCantidadRegistros.Text = ""
        bolBeneficio = CampoBeneficio()
        VerificarEstadoPagos()
        MostrarOcultarDivPagos(False)
        Me.btnVerReferen.Enabled = False

        'A�os segun concepto
        pMostrarItemTodosxConcepto()

        '(1)--OJO CON LA UBICACION DE LA COLUMNA 7
        If bolBeneficio Then
            Me.grdEstadoCuenta.Columns(7).Visible = True
        Else
            Me.grdEstadoCuenta.Columns(7).Visible = False
        End If
        '(1)--------------------------------------

        '************ Validar Pricos *************
        'If BuscarPrico(GetConexionSiatTributos, mintCodigoUsuario, GetConceptoReca) Then
        '    If mintCodVeh = 0 Then
        '        Me.lblMensajePrico.Text = "Por su condici�n de Principal Contribuyente, le pedimos comunicarse con su sectorista para obtener su estado de cuenta."
        '        Exit Sub
        '    End If
        'End If
        '*****************************************

        If IsNumeric(Me.ddlAnio.SelectedValue) Then intAnio = Integer.Parse(Me.ddlAnio.SelectedValue)
        If IsNumeric(Me.ddlEstado.SelectedValue) Then intEstado = Integer.Parse(Me.ddlEstado.SelectedValue)
        strReferenciaBusqueda = Me.ddlReferencia.SelectedValue

        'archivo temporal para el xml
        strFileTemp = GetRutaFisica("temp/") + Date.Today.ToString("ddMMyyyy") + _
                       "_" + GetSessionID.ToString + _
                       "_" + GetConceptoReca.ToString + _
                       "_" + intAnio.ToString + _
                       "_" + intEstado.ToString + _
                       "_" + mintCodigoUsuario.ToString

        'para la impresion
        Me.hidUrlPrint.Value = "TributosImprimir.aspx?ses=" + GetSessionID.ToString + _
                               "&con=" + GetConceptoReca.ToString + _
                               "&ani=" + intAnio.ToString + _
                               "&est=" + intEstado.ToString + _
                               "&usu=" + mintCodigoUsuario.ToString
        'si la busqueda es por codigo de vehiculo
        If mintCodVeh > 0 And GetConceptoReca() = 146 Then
            strTipoReporte = "V1W"
        End If
        dsDeuda = oBLL.BuscarEstadoCuenta(GetConexionSiatTributos, mintCodigoUsuario, GetConceptoReca, intAnio, 0, intEstado, 0, Date.Today.ToShortDateString, , mintCodVeh, , strTipoReporte, True)

        'salvar en archivo xml la consulta
        If Not dsDeuda Is Nothing Then
            dsDeuda.WriteXml(strFileTemp + ".xml", XmlWriteMode.WriteSchema)
        End If

        intCantidad = 0
        If Not dsDeuda Is Nothing Then
            If dsDeuda.Tables(0).Rows.Count > 0 Then
                If Not dsDeuda.Tables(0).Columns.Contains("Saldo_beneficio") Then
                    dsDeuda.Tables(0).Columns.Add("Saldo_beneficio", GetType(Double))
                End If
                If dsDeuda.Tables(0).Columns.Contains("Referencia") Then
                    bolRef = True
                End If
                dtRef = GetEstructuraTablaReferencia()
                strReferenciaAnterior = ""
                i = 0
                While dsDeuda.Tables(0).Rows.Count > i
                    dsDeuda.Tables(0).Rows(i)("N� DE DOCUMENTO") = CheckStr(dsDeuda.Tables(0).Rows(i)("N� DE DOCUMENTO")).Replace(".", "")
                    If bolRef Then
                        strReferencia = CheckStr(dsDeuda.Tables(0).Rows(i)("Referencia"))
                        If strReferencia <> strReferenciaAnterior Then
                            strReferenciaAnterior = strReferencia
                            drRef = dtRef.NewRow
                            drRef("id") = strReferencia
                            drRef("referencia") = strReferencia
                            dtRef.Rows.Add(drRef)
                        End If
                        If strReferenciaBusqueda <> "" And strReferencia <> strReferenciaBusqueda Then
                            dsDeuda.Tables(0).Rows.RemoveAt(i)
                        Else
                            intPeriodo = CheckInt(dsDeuda.Tables(0).Rows(i)("periodo"))
                            'para el campo estado
                            strReferencia = CheckStr(dsDeuda.Tables(0).Rows(i)("Estado"))
                            If strReferencia.Length > 18 Then
                                strReferencia = Strings.Left(strReferencia, 18) + "."
                            End If
                            dsDeuda.Tables(0).Rows(i)("Estado") = strReferencia
                            dblTotalDeudaCon += CheckDbl(dsDeuda.Tables(0).Rows(i)("Saldo_beneficio"))
                            If intPeriodo > 0 Then 'no sumar cuota cero
                                dblTotalDeudaSin += CheckDbl(dsDeuda.Tables(0).Rows(i)("Saldo"))
                            End If
                            ' no sumar cuota cero
                            If intPeriodo > 0 Then
                                intCantidad = intCantidad + 1
                                i += 1
                            Else
                                If System.Configuration.ConfigurationManager.AppSettings("mostrarCuotaCero") <> "1" Then
                                    dsDeuda.Tables(0).Rows.RemoveAt(i)
                                Else
                                    'intCantidad = intCantidad + 1
                                    i += 1
                                End If
                            End If
                        End If
                    Else
                        i += 1
                    End If
                End While
                dsDeuda.AcceptChanges()

                If intCantidad = 1 Then
                    j = 0
                    While dsDeuda.Tables(0).Rows.Count > j
                        intPeriodo = CheckInt(dsDeuda.Tables(0).Rows(j)("periodo"))
                        If intPeriodo = 0 Then
                            dsDeuda.Tables(0).Rows.RemoveAt(j)
                        Else
                            j += 1
                        End If
                    End While
                End If

                dsDeuda.AcceptChanges()

                Dim dsRefe As New DataSet
                If strReferenciaBusqueda = "" Then
                    dsRefe.Tables.Add(dtRef)
                    dsRefe.WriteXml(strFileTemp + "_ref.xml", XmlWriteMode.WriteSchema)
                    SetCombo(dtRef, "id", "referencia", Me.ddlReferencia, True, "(Todos)")
                Else
                    If IO.File.Exists(strFileTemp + "_ref.xml") Then
                        dsRefe.ReadXml(strFileTemp + "_ref.xml")
                        dtRef = dsRefe.Tables(0)
                        SetCombo(dtRef, "id", "referencia", Me.ddlReferencia, True, "(Todos)")
                        SetComboSeleccionado(strReferenciaBusqueda, Me.ddlReferencia)
                    End If
                End If
                dsRefe = Nothing

                If intCantidad > Me.grdEstadoCuenta.PageSize Then
                    Me.divDataGrid.Style("height") = CStr(12 * 30 + 40)
                Else
                    Me.divDataGrid.Style("height") = CStr((intCantidad + 3) * 30 + 30)
                End If

                Me.grdEstadoCuenta.DataSource = dsDeuda.Tables(0)
                Me.grdEstadoCuenta.DataBind()

                Me.grdEstadoCuenta.Visible = True
                Dim strMensaje As New StringBuilder
                If i <= 0 Then
                    strMensaje.AppendFormat("Se encontraron {0} documentos de deuda: <br>- Total a pagar sin Beneficio: {1}<br>- Total a pagar con Beneficio: {2}", intCantidad, "S/. " + dblTotalDeudaSin.ToString("#,##0.00"), "No se aplica")
                    Me.btnVerReferen.Enabled = False
                Else
                    If dblTotalDeudaCon > 0 Then
                        strMensaje.AppendFormat("Se encontraron {0} documentos de deuda: <br>- Total a pagar sin Beneficio: S/. {1}<br>- Total a pagar con Beneficio: S/. {2}", i, dblTotalDeudaSin.ToString("#,##0.00"), dblTotalDeudaCon.ToString("#,##0.00") + " (En caso pague al contado)")
                        strMensaje.Append("<br>" + "- 1/ Determinado seg�n beneficio establecido en la ord. N� 1003, vigente hasta el 28 de abril de 2007.<br>" + _
                            "- Si el estado de su documento es reclamada deber� presentar el desistimiento de este reclamo.")
                    Else
                        If bolBeneficio Then
                            strMensaje.AppendFormat("Se encontraron {0} documentos de deuda: <br>- Total a pagar sin Beneficio: {1}<br>- Total a pagar con Beneficio: {2}", intCantidad, "S/. " + dblTotalDeudaSin.ToString("#,##0.00"), "No se aplica")
                        Else
                            strMensaje.AppendFormat("Se encontraron {0} documentos de deuda: <br>- Total a pagar : <b>{1}</b><br>", intCantidad, "S/. " + dblTotalDeudaSin.ToString("#,##0.00"))
                        End If
                        Me.btnVerReferen.Enabled = False
                    End If
                    Me.btnVerReferen.Enabled = True
                End If
                Me.lblCantidadRegistros.Text = strMensaje.ToString
                MostrarOcultarDivPagos(True)
            Else
                Me.divDataGrid.Style("height") = "40"
                Me.grdEstadoCuenta.Visible = False
                Me.lblMensajeSinDatos.Text = "<br>" + BuscarMensaje("estado_cuenta_sin_datos")
            End If
        End If
        oBLL = Nothing
        dsDeuda = Nothing
    End Sub

    Private Sub MostrarItemTodos()
        Dim intCantidadRef As Integer = 0
        If IsNumeric(ConfigurationManager.AppSettings("intCantidadReferencias")) Then
            intCantidadRef = CInt(ConfigurationManager.AppSettings("intCantidadReferencias"))
            If Me.ddlReferencia.Items.Count <= intCantidadRef Then
                If Not ddlAnio.Items(0).Text = "Todos" Then
                    Me.ddlAnio.Items.Insert(0, New ListItem("Todos", "0"))
                End If
            End If
        End If
    End Sub

    Private Sub pMostrarItemTodosxConcepto()
        If MostrarTodosLosAnios(GetConceptoReca().ToString) Or (mintCodVeh > 0 And GetConceptoReca() = 146) Then
            If Not ddlAnio.Items(0).Text = "Todos" Then
                Me.ddlAnio.Items.Insert(0, New ListItem("Todos", "0"))
                ddlAnio.SelectedIndex = 0
            End If
        End If
    End Sub

    Private Sub MostrarOcultarDivPagos(ByVal vbolMostrar As Boolean)
        Me.divPagos.Visible = vbolMostrar
        If GetEstadoPagos() = False Then
            Me.divPagos.Visible = False
        End If
    End Sub

    Protected Sub btnBuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        InicioComboReferencia()
        pBuscarEstadoCuenta()
        Me.grdEstadoCuenta.PageIndex = 0
    End Sub

    Protected Sub grdEstadoCuenta_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdEstadoCuenta.PageIndexChanging
        grdEstadoCuenta.PageIndex = e.NewPageIndex
        pBuscarEstadoCuenta()
    End Sub

    Protected Sub grdEstadoCuenta_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdEstadoCuenta.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            ProcesarFilaDataGrid(e)
        End If
    End Sub

    Protected Sub btnNuevaBusqueda_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNuevaBusqueda.Click
        SetCodigoBuscado("")
        Redireccionar(Paginas.BuscadorTributos, SetUrlLibre("tri", GetUrlLibre("tri")))
    End Sub

    Protected Sub btnPagar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPagar.Click
        pRefrescarSeleccionCuentas()
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        pRefrescarSeleccionCuentas()
    End Sub

    Private Sub pRefrescarSeleccionCuentas()
        Dim oCar As New FuncionesCarrito
        oCar.ProcesarGridCarritoTributos(grdEstadoCuenta, GetConceptoReca.ToString)
        oCar = Nothing
    End Sub

    Private Sub InicioComboReferencia()
        Me.ddlReferencia.Items.Clear()
    End Sub

    Protected Sub btnVerReferen_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnVerReferen.Click
        pBuscarEstadoCuenta()
        Me.grdEstadoCuenta.PageIndex = 0
    End Sub

    Protected Sub chkSeleccion_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim chk As CheckBox = CType(sender, CheckBox)
        Dim row As GridViewRow = CType(chk.NamingContainer, GridViewRow)
        Dim strRef As String = ""
        Dim intRow As Integer = row.RowIndex
        Dim intTotal As Integer = Me.grdEstadoCuenta.Rows.Count - 1
        Dim strCuota As String = ""
        Dim strAnio As String = ""

        strRef = CType(grdEstadoCuenta.Rows(intRow).FindControl("lblReferencia"), Label).Text
        strCuota = CType(grdEstadoCuenta.Rows(intRow).FindControl("lblPeriodo"), Label).Text
        strAnio = CType(grdEstadoCuenta.Rows(intRow).FindControl("lblAnio"), Label).Text
        If strCuota.Trim = "0" Then
            pSeleccionCuotaCero(intRow + 1, intTotal, strRef, chk.Checked, strAnio)
        End If
        pRefrescarSeleccionCuentas()

    End Sub

    Private Sub pSeleccionCuotaCero(ByVal vintIndex As Integer, _
                                  ByVal vintTotal As Integer, _
                                  ByVal vstrRef As String, _
                                  ByVal vbolSel As Boolean, _
                                  ByVal vstrAnio As String)
        Dim strRef As String = ""
        Dim strAnio As String = ""

        While vintIndex <= vintTotal
            strRef = CType(grdEstadoCuenta.Rows(vintIndex).FindControl("lblReferencia"), Label).Text
            strAnio = CType(grdEstadoCuenta.Rows(vintIndex).FindControl("lblAnio"), Label).Text
            If strRef = vstrRef And strAnio = vstrAnio Then
                If CType(grdEstadoCuenta.Rows(vintIndex).FindControl("chkSeleccion"), CheckBox).BackColor <> Drawing.Color.DarkRed Then
                    CType(grdEstadoCuenta.Rows(vintIndex).FindControl("chkSeleccion"), CheckBox).Checked = vbolSel
                    CType(grdEstadoCuenta.Rows(vintIndex).FindControl("chkSeleccion"), CheckBox).Enabled = Not vbolSel
                End If
            End If
            vintIndex += 1
        End While

    End Sub

End Class
