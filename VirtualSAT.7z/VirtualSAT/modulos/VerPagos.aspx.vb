Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL
Imports SAT.SeguridadSAT.Encriptacion

Partial Class modulos_VerPagos
    Inherits PageBase

    Private mintCodigoUsuario As Integer = 0
    Private mstrCodTx As String = ""

    Private mstrCodTarjeta As String
    Private mstrCodAutorizacion As String
    Private mstrMsjRespuesta As String

    ''' <summary>Pagina de carga.</summary>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor></CreadoPor></item>
    ''' <item><FecCrea></FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu>25/04/2016</FecActu></item>
    ''' <item><Resp>Richard Angeles P.</Resp></item>
    ''' <item><Mot>Agregar val1,val2 y val3 para pagos en MasterCard y American Express</Mot></item></list></remarks>
    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        mintCodigoUsuario = FuncionesWeb.GetCodigoBuscado
        mstrCodTx = GetURL("cod")
        mstrCodTarjeta = GetURL("val1")
        mstrCodAutorizacion = GetURL("val2")
        mstrMsjRespuesta = GetURL("val3")

        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If

    End Sub



    ''' <summary>Pagina de inicio.</summary>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor></CreadoPor></item>
    ''' <item><FecCrea></FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu>25/04/2016</FecActu></item>
    ''' <item><Resp>Richard Angeles P.</Resp></item>
    ''' <item><Mot>Seteo de variables para MasterCard y American Express</Mot></item></list></remarks>
    Private Sub Inicio()

        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario, strCorreo, strTransaccion, strFechaHora, strTotalPagado As String
        Dim i As Integer
        Dim strMensaje As String = ""
        Dim strPasarelaPagos As String = "" 'Para agregar filas de datos html

        Me.lblTitulo.Text = "CONSTANCIA DE PAGOS VIRTUALES"
        If mstrCodTx.Length > 0 Then
            ds = oBLL.PagosVirtualesBuscarDetalleTransaccion(GetConexionPagosVirtuales, mstrCodTx.Substring(0, 1), mstrCodTx)
            If Not ds Is Nothing Then
                If ds.Tables(0).Rows.Count > 0 Then
                    With ds.Tables(0).Rows(0)
                        strUsuario = CheckStr(.Item("Usuario"))
                        strCorreo = CheckStr(.Item("VCUSR_EMAIL"))
                        strTransaccion = CheckStr(.Item("VCTRN_NUMERO"))
                        strFechaHora = CheckStr(.Item("DTTRN_FECHAHORAINICIO"))
                        strTotalPagado = CheckDbl(.Item("NMTRN_MONTO")).ToString("#,#0.00")
                    End With
                    Me.lblCorreo.Text = strCorreo
                    Me.lblFechaHora.Text = strFechaHora
                    Me.lblOperaci�n.Text = strTransaccion
                    Me.lblTotalPagado.Text = "S/. " + strTotalPagado
                    Me.lblUsuario.Text = strUsuario
                    Me.lblTrama.Text = Encrypt(strTransaccion, CDate(strFechaHora).AddDays(33).ToString("ddmmyyyy"))

                    If mstrCodTarjeta = "2" Or mstrCodTarjeta = "4" Then 'MasterCard o American Express
                        strPasarelaPagos += "</td><td>C&oacute;digo de Autorizaci&oacute;n</td><td>"
                        strPasarelaPagos += "<span id=""lblCodAutorizacion"">" + mstrCodAutorizacion + "</span>"
                        strPasarelaPagos += "</td></tr><tr><td></td><td>Mensaje de Respuesta</td><td>"
                        strPasarelaPagos += "<span id=""lblMsjRespuesta"">" + mstrMsjRespuesta + "</span></td></tr><tr><td>"
                        Me.lblPasarelaPagos.Text = strPasarelaPagos
                    End If

                    If CheckStr(ds.Tables(0).Rows(0)("EnvioMail")) = "" Then
                        strMensaje = "Sr(a/ita/s): " & strUsuario & Chr(13) & Chr(13)
                        strMensaje = strMensaje & "Su transaccion se ha realizado con exito. Los datos registrados del pago son:" & Chr(13) & Chr(13)
                        strMensaje = strMensaje & "Numero de pedido: " & strTransaccion & Chr(13)
                        strMensaje = strMensaje & "Fecha hora: " & strFechaHora & Chr(13)
                        'strMensaje = strMensaje & "Monto Total Pagado: " & Me.lblTotalPagado.Text & Chr(13) & Chr(13)
                        strMensaje = strMensaje & "Monto Total Pagado: " & Me.lblTotalPagado.Text & Chr(13)
                        If mstrCodTarjeta = "2" Or mstrCodTarjeta = "4" Then 'MasterCard o American Express
                            strMensaje = strMensaje & "Codigo de Autorizacion: " & mstrCodAutorizacion & Chr(13)
                            strMensaje = strMensaje & "Mensaje de Respuesta: " & mstrMsjRespuesta & Chr(13) & Chr(13)
                        Else
                            strMensaje = strMensaje & Chr(13)
                        End If
                        strMensaje = strMensaje & "Detalle de los documentos cancelados: " & Chr(13) & Chr(13)
                        strMensaje = strMensaje & "Documento" & Chr(9) & Chr(9) & "Anio" & Chr(9) & Chr(9) & "Periodo" & Chr(9) & Chr(9) & "Importe" & Chr(13)
                        strMensaje = strMensaje & "====================================================" & Chr(13)

                        For i = 0 To ds.Tables(0).Rows.Count - 1
                            strMensaje = strMensaje & CheckStr(ds.Tables(0).Rows(i)("VCDTL_NUMDOC")) & Chr(9) & Chr(9) & CheckStr(ds.Tables(0).Rows(i)("VCDTL_ANO")) & Chr(9) & Chr(9) & CheckStr(ds.Tables(0).Rows(i)("VCDTL_PERIODO")) & Chr(9) & Chr(9) & CheckStr(ds.Tables(0).Rows(i)("NMDTL_TOTPAG")) & Chr(13)
                        Next
                        strMensaje = strMensaje & Chr(13) & "Gracias por utilizar el Servicio de Pagos en Linea - SAT." & Chr(13)
                        strMensaje = strMensaje & Chr(13) & "Recuerde que sus pagos se procesan en el momento." & Chr(13) & Chr(13)
                        strMensaje = strMensaje & "PD: Las tildes y enies se han omitido para evitar problemas de compatibilidad entre los software de correo electronico"
                        '*** enviar correo ****
                        oBLL.EnviarCorreoTexto(GetConexionPagosVirtuales, "PAGOS VIRTUALES <pagovirtual@sat.gob.pe>", strCorreo + ";pagovirtual@sat.gob.pe", "Pago Virtual SAT", strMensaje)
                        Session.Item("strMensajeCorreo") = strMensaje
                        '*** registrar envio de correo ****
                        oBLL.PagosVirtualesRegistrarEnvioCorreo(GetConexionPagosVirtuales, strTransaccion, strCorreo)

                    End If
                End If
            End If
            Me.grdCarrito.DataSource = ds.Tables(0)
            Me.grdCarrito.DataBind()

        Else
            Redireccionar(Paginas.Inicio)
        End If
        ds = Nothing
        oBLL = Nothing
    End Sub

    Protected Sub btnReenviar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnReenviar.Click

        If Not fbln_ValidarCorreo() Then Exit Sub

        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strMensaje As String = ""
        Dim strMensajeReenvio As String = SAT.Base.Lib.Datos.CheckStr(Me.txtCorreoReenvio.Text)
        strMensaje = Convert.ToString(Session.Item("strMensajeCorreo"))
        If ValidaCadena(strMensajeReenvio) <> "" Then
            oBLL.EnviarCorreoTexto(GetConexionPagosVirtuales, "PAGOS VIRTUALES <pagovirtual@sat.gob.pe>", ValidaCadena(strMensajeReenvio) + ";pagovirtual@sat.gob.pe", "Pago Virtual SAT - Reenvio de Constancia", strMensaje)
            Me.lblMensajeServer.Text = "La constancia se ha reenviado a: " + strMensajeReenvio
            Me.btnReenviar.Enabled = False
        End If
        ds = Nothing
        oBLL = Nothing
    End Sub

    ''' <summary>M�todo para validar el correo electr�nico del usuario a enviar la cuponera.</summary>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor>Mario Laura</CreadoPor></item>
    ''' <item><FecCrea>25/01/2019</FecCrea></item></list>
    ''' <list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCorreo() As Boolean
        If SAT.Base.Lib.App.Email.Validar(SAT.Base.Lib.Datos.CheckStr(Me.txtCorreoReenvio.Text)) Then
            Me.lblMensajeServer.Text = ""
            Return True
        Else
            Me.lblMensajeServer.Text = "El correo no es v�lido."
            Return False
        End If
    End Function


End Class
