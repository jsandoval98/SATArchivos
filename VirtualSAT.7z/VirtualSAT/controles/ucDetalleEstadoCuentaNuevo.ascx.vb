Imports System.Data

Namespace AlcabalaNET

    Partial Class ucDetalleEstadoCuentaNuevo
        Inherits System.Web.UI.UserControl

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            If Not IsPostBack Then
                '
            End If
        End Sub
        Public Sub MyDataBind(ByVal vdvwData As DataView)
            Me.dgrDetalle.DataSource = vdvwData
            Me.dgrDetalle.DataBind()
        End Sub

    End Class

End Namespace
