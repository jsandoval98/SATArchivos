﻿
Partial Class modulos_pagRegistroPap
    Inherits System.Web.UI.Page

End Class
