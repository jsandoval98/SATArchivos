Imports FuncionesWeb
Partial Class principal
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        '-- Comment-test-kgc
        'If GetCodigoUsuario() = "" Then
        '    Response.Redirect(BuscarMensaje("pagina_login"))
        '    Response.End()
        'End If
        '---
    End Sub

End Class
