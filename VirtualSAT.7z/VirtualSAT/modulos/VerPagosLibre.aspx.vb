Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb

Partial Class modulos_VerPagosLibre
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strCod As String = Request("cod")
        If Not strCod Is Nothing Then
            Response.Redirect("VerPagos.aspx?" + SetURL("cod", strCod))
        End If
    End Sub
End Class
