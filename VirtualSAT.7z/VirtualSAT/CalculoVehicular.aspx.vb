Option Explicit On
Option Strict On

Imports SAT.ConsultasVarias
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports SAT
Imports FuncionesWeb


Partial Class CalculoVehicular
    Inherits System.Web.UI.Page

    Protected Sub btnCalcular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCalcular.Click
        Dim strPlaca As String = ValidaCadena(Me.txtPlaca.Text)
        If strPlaca.Length > 5 Then
            BuscarPlaca(strPlaca)
        End If
        btnCalcular.Attributes.Add("onclick", "javascript:return validar();")
    End Sub

    Private Sub BuscarPlaca(ByVal vstrPlaca As String)
        Dim oBLL As New ConsultasVarias
        Dim dsPlaca As DataSet
        Dim i As Integer

        'buscar en siat
        dsPlaca = oBLL.BuscarDatosPlacaSIAT(GetConexionSiatTributos, vstrPlaca)
        Me.grdProps.DataSource = dsPlaca.Tables(0)
        Me.grdProps.DataBind()

        dsPlaca = oBLL.BuscarPlacaSunarp(GetConexionSunarp, vstrPlaca)
        If dsPlaca.Tables(0).Rows.Count > 0 Then
            Me.lblResultado.Text = "Fecha de la primera inscripci�n en SUNARP: " + CheckStr(dsPlaca.Tables(0).Rows(0)("sdFecIns")) 'sdFecIns
        End If
        oBLL = Nothing
        dsPlaca = Nothing

    End Sub

    Private Function Calcular(ByVal intAnio As Integer) As Boolean
        Dim intPrimerAnio As Integer = 0
        Dim intSegundoAnio As Integer = 0
        Dim intTercerAnio As Integer = 0
        If (intAnio >= 1900 And intAnio <= Now.Year) Then
            intPrimerAnio = intAnio + 1
            intSegundoAnio = intAnio + 2
            intTercerAnio = intAnio + 3
            Me.lblResultado.Text = "A�os de Afectaci�n: " & intPrimerAnio & ", " & intSegundoAnio & " y " & intTercerAnio & "."
            Me.lblMensaje.Text = ""
        Else
            Me.lblMensaje.ForeColor = Drawing.Color.Red
        End If

    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                btnCalcular.Attributes.Add("onclick", "javascript:return validar();")
            End If

        Catch ex As Exception

        End Try
    End Sub

End Class
