﻿Option Explicit On
Option Strict On
Imports FuncionesWeb
Imports System.Data
Imports CaptchaDLL
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Partial Class modulos_pitazo_NuevoRegistro
    Inherits System.Web.UI.Page
    Private intCaptcha As Integer = 4
    Private strCelular As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("CaptchaImageText") = CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        End If
    End Sub
    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub


    Protected Sub btnBuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        Dim ds As New DataSet
        Dim obj As New SAT.ConsultasVarias
        Dim strDocumento As String = CheckStr(Me.NroDocumento.Text.Trim)
        Dim intTipoDocumento As Integer = Convert.ToInt32(Me.TipoDocumento.Text)

        Dim strAPaterno As String = ""
        Dim strAMaterno As String = ""
        Dim strNombres As String = ""
        Dim strTFijo As String = ""
        Dim strDireccion As String = ""
        Dim strMensaje As String = ""
        Dim strScript As String = ""


        Me.lblAPaterno.Text = ""
        Me.lblAMaterno.Text = ""
        Me.lblNombres.Text = ""
        Me.txtTFijo.Text = ""
        Me.txtTCelular.Text = ""
        Me.txtDireccion.Text = ""
        Me.hdnfldtxtCodPer.Value = ""
        Me.lblAPaterno.Enabled = False
        Me.lblAMaterno.Enabled = False
        Me.lblNombres.Enabled = False


        strCelular = CheckStr(Me.txtCelular.Text.Trim)

        Try
            ds = obj.BuscarPersona(GetConexionSiatTributos, 0, "", "", intTipoDocumento, strDocumento)

            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then
                strAPaterno = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("ApePat"))
                strAMaterno = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("ApeMat"))
                strNombres = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("Nombre"))
                strTFijo = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("Teléfono 1"))
                strDireccion = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("DomFis"))
                Me.lblAPaterno.Text = strAPaterno
                Me.lblAMaterno.Text = strAMaterno
                Me.lblNombres.Text = strNombres
                Me.txtTFijo.Text = strTFijo
                Me.txtTCelular.Text = strCelular
                Me.txtDireccion.Text = strDireccion
                Me.hdnfldtxtCodPer.Value = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("Código"))
                If String.IsNullOrEmpty(strTFijo) Then
                    Me.txtTFijo.Focus()
                ElseIf String.IsNullOrEmpty(strDireccion) Then
                    Me.txtDireccion.Focus()
                End If
            Else

                ds = obj.BuscarReniecSiat(GetConexionSiatReniec, strDocumento)

                If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then
                    strAPaterno = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("SP_APP"))
                    strAMaterno = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("SP_APM"))
                    strNombres = SAT.Base.Lib.Datos.CheckStr(ds.Tables(0).Rows(0)("SP_NOM"))
                    Me.lblAPaterno.Text = strAPaterno
                    Me.lblAMaterno.Text = strAMaterno
                    Me.lblNombres.Text = strNombres
                    Me.txtTCelular.Text = strCelular
                    Me.txtTFijo.Focus()
                Else
                    Me.lblAPaterno.Enabled = True
                    Me.lblAMaterno.Enabled = True
                    Me.lblNombres.Enabled = True
                    Me.txtTCelular.Text = strCelular
                    Me.lblAPaterno.Focus()
                End If


            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            ds = Nothing
        End Try
    End Sub
    Protected Sub btnRegistrar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegistrar.Click
        Try
            If Not fbln_ValidarDatos() Then Exit Sub
            If Not fbln_ValidarCaptha() Then Exit Sub
            RegistrarUsuario()

        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        End Try
    End Sub
    Private Sub RegistrarUsuario()
        Dim ds As New DataSet
        Dim intCodPer As Integer = CheckInt(Convert.ToInt32(Val(Me.hdnfldtxtCodPer.Value)))
        Dim intTipoDocumento As String = CheckStr(Me.TipoDocumento.Text)
        Dim strDocumento As String = CheckStr(Me.NroDocumento.Text)
        Dim strAPaterno As String = CheckStr(Me.lblAPaterno.Text)
        Dim strAMaterno As String = CheckStr(Me.lblAMaterno.Text)
        Dim strNombres As String = CheckStr(Me.lblNombres.Text)
        Dim strDireccion As String = CheckStr(Me.txtDireccion.Text)
        Dim strTFijo As String = CheckStr(Me.txtTFijo.Text)
        Dim strEmail As String = CheckStr(Me.txtEmail.Text)
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")
        Dim strPassword As String = "" 
        Dim strRuta As String = ""
        Dim strCodUsuario As String = ""
        Dim strcbPapeletasEmail As String = CheckStr(Me.hdncbPapeletasEmail.Value)
        Dim strcbPapeletasSMS As String = CheckStr(Me.hdncbPapeletasSMS.Value)
        Dim strcbCapturasSMS As String = CheckStr(Me.hdncbCapturasSMS.Value)




        Try
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                ds = oBLL.RegistrarSuscripcionServicioPitazo(GetConexionSoporteWEB, intCodPer, intTipoDocumento, _
                                                             strDocumento, strAPaterno, strAMaterno, strNombres, _
                                                             strDireccion, strTFijo, strCelular, strEmail, _
                                                             strIP, strPassword, strcbPapeletasEmail, _
                                                             strcbPapeletasSMS, strcbCapturasSMS)
            End Using
            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then
                With ds.Tables(0).Rows(0)
                    strCodUsuario = Convert.ToString(CheckInt(.Item("nCodUsu")))
                End With
                If Not String.IsNullOrEmpty(strEmail) And Not String.IsNullOrEmpty(strCelular) Then
                    strRuta = "CodigoConfirmacion.aspx?" + SetURL("codigo", strCodUsuario) 'strCodUsuario
                    Response.Redirect(strRuta, False)
                ElseIf String.IsNullOrEmpty(strCelular) And Not String.IsNullOrEmpty(strEmail) Then
                    strRuta = "CorreoConfirmacion.aspx?" + SetURL("codigo", strCodUsuario) 'strCodUsuario
                    Response.Redirect(strRuta, False)
                ElseIf Not String.IsNullOrEmpty(strCelular) And String.IsNullOrEmpty(strEmail) Then
                    strRuta = "CodigoConfirmacion.aspx?" + SetURL("codigo", strCodUsuario) ' strCodUsuario
                    Response.Redirect(strRuta, False)
                End If
            End If

        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try

    End Sub
    Private Function GenerarPassword(ByVal largo As Integer) As String
        'Cargamos la matriz con números y letras 
        Dim Resultado As String = ""
        Dim Caracter() As String = New String() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}

        Randomize()
        Do While Len(Resultado) < largo
            Resultado = Resultado & Caracter(Convert.ToInt32(10 * Rnd()))
        Loop
        Return Resultado

    End Function
    Private Function Encripta(ByVal strIn As String) As String
        Dim strOut As String = ""
        Dim c1, c2, c3, n As Integer
        Dim w1, w2, w3, w4 As Integer

        strIn = "SAT" + strIn

        For n = 1 To Len(strIn) Step 3
            c1 = Asc(Mid(strIn, n, 1))
            c2 = Asc(Mid(strIn, n + 1, 1) + Chr(0))
            c3 = Asc(Mid(strIn, n + 2, 1) + Chr(0))
            w1 = Convert.ToInt32(c1 / 4)
            w2 = Convert.ToInt32((c1 And 3) * 16 + Int(c2 / 16))
            If Len(strIn) >= n + 1 Then
                w3 = Convert.ToInt32(((c2 And 15) * 4 + Int(c3 / 64)))
            Else
                w3 = -1
            End If
            If Len(strIn) >= n + 2 Then
                w4 = c3 And 63
            Else
                w4 = -1
            End If
            strOut = strOut + mimeencode(w1) + mimeencode(w2) + _
                mimeencode(w3) + mimeencode(w4)
        Next
        Return strOut

    End Function
    Private Function mimeencode(ByVal intIn As Integer) As String
        Dim Base64Chars As String
        Dim strencode As String = ""

        Base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" & _
          "abcdefghijklmnopqrstuvwxyz" & _
          "0123456789" & _
          "+/"

        If intIn >= 0 Then
            strencode = Mid(Base64Chars, intIn + 1, 1)
        Else
            strencode = ""
        End If
        Return strencode
    End Function
    Private Function fbln_ValidarDatos() As Boolean

        Dim strEmail As String = CheckStr(Me.txtEmail.Text.Trim)
        Dim strDocumento As String = CheckStr(Me.NroDocumento.Text.Trim)
        Dim strScript As String = ""
        Dim strMensaje As String = ""
        Dim blnValidado As Boolean = True

        strCelular = CheckStr(Me.txtCelular.Text.Trim)

        If Not strCelular = "" Then
            If fbln_ValidarCelular(strCelular, strDocumento) Then strMensaje += "El número de celular ya se encuentra registrado."
            If Not strEmail = "" Then
                If fbln_ValidarEmail(strEmail, strDocumento) Then strMensaje += "El email ya se encuentra registrado."
            End If
        End If
        If Not strEmail = "" Then
            If fbln_ValidarEmail(strEmail, strDocumento) Then strMensaje += "El email ya se encuentra registrado."
        End If

        If Not strMensaje = "" Then
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
            blnValidado = False
        End If
        Return blnValidado
    End Function
    Private Function fbln_ValidarEmail(ByVal vstrEmail As String, ByVal vstrDocumento As String) As Boolean
        Dim ds As New DataSet
        Dim blnValidado As Boolean = False
        Try
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                ds = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, vstrEmail, "", vstrDocumento)
            End Using
            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then blnValidado = True
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
        Return blnValidado
    End Function
    Private Function fbln_ValidarCelular(ByVal vstrCelular As String, ByVal vstrDocumento As String) As Boolean
        Dim ds As New DataSet
        Dim blnValidado As Boolean = False
        Try
            ' Realiza la búsqueda del usuario por número de celular
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                ds = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, "", vstrCelular, vstrDocumento)
            End Using
            ' Verifica que el número de celular se encuentre registrado
            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then blnValidado = True
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
        Return blnValidado
    End Function
    Private Function fbln_ValidarCaptha() As Boolean
        Dim va1 As String = Session("CaptchaImageText").ToString().ToLower()
        Dim va2 As String = txtCaptcha.Text.ToLower()
        Dim blnRespuesta As Boolean
        If Session("CaptchaImageText") IsNot Nothing AndAlso txtCaptcha.Text.ToLower() = Session("CaptchaImageText").ToString().ToLower() Then
            blnRespuesta = True
        Else
            Dim strMensaje As String = ""
            Dim strScript As String = ""
            strMensaje += "Código capcha incorrecto"
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
            Session("CaptchaImageText") = CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        End If
        Return blnRespuesta
    End Function
End Class
