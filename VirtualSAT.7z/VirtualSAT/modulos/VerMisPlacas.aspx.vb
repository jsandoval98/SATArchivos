Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones

Partial Class modulos_VerMisPlacas
    Inherits System.Web.UI.Page

#Region " Declaraciones "
    Private intCodigoUsuario As Integer
#End Region

#Region " Eventos "
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
            MostrarPlacas()
        End If
    End Sub

    '''<summary>Procedimiento para anular la suscripci�n al servicio de SMS</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>David Miranda Palomino</CreadoPor></item>
    '''<item><FecCrea>30/07/2009</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu>06/11/2009</FecActu></item>
    '''<item><Resp>David Miranda P.</Resp></item>
    '''<item><Mot>Agregar la terminal (IP) del usuario.</Mot></item></list></remarks>
    Protected Sub btnAnularSms_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAnularSms.Click
        pAnularSuscripcionServicio(2)
    End Sub

    Protected Sub btnAnularPapeleta_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAnularPapeleta.Click
        pAnularSuscripcionServicio(1)
    End Sub

    Protected Sub btnAnularImpVehicular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAnularImpVehicular.Click
        pAnularSuscripcionServicio(3)
    End Sub

    Protected Sub btnInscribirPapeleta_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInscribirPapeleta.Click
        pRegistrarSuscripcionServicio(1)
    End Sub

    Protected Sub btnInscribirSms_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInscribirSms.Click
        pRegistrarSuscripcionServicio(2)
    End Sub

    Protected Sub btnInscribirImpVehicular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnInscribirImpVehicular.Click
        pRegistrarSuscripcionServicio(3)
    End Sub

    Protected Sub btnRegistrarCelular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegistrarCelular.Click
        Me.pnlCelular.Visible = True
        Me.pnlCorreo.Visible = False
        Me.btnRegistrarCelular.Visible = False
        Me.txtNumCelular.Focus()
        Me.txtNumCelular.Text = ""
        Me.txtNumCelularConfirmar.Text = ""
        Me.btnRegistrarNumero.Visible = True
        Me.btnConfirmarCelular.Visible = False
    End Sub

    Protected Sub btnRegistrarEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegistrarEmail.Click
        Me.pnlCelular.Visible = False
        Me.pnlCorreo.Visible = True
        Me.btnRegistrarEmail.Visible = False
    End Sub

    Protected Sub btnRegistrarNumero_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegistrarNumero.Click
        If Not fbln_ValidarNumeroCelular() Then Exit Sub
        Dim dsCelular As New DataSet
        Dim strMensaje As String = ""
        Dim strMensajeCel As String = ""
        Dim strScript As String = ""
        Dim blnEnviado As Boolean = False

        Using oBLL As New ConsultasWeb
            dsCelular = oBLL.RegistrarServicioSMS(GetConexionSoporteWEB, CheckInt(GetCodigoRegistroUsuario), Me.txtNumCelular.Text, GetIPTerminal)
        End Using

        If SAT.Base.Lib.Datos.RowCount(dsCelular) > 0 Then
            Me.hidCelular.Value = Me.txtNumCelular.Text

            ' Mensaje para el celular
            strMensajeCel = "Servicio de Administracion Tributaria." & Chr(10)
            strMensajeCel += "Su codigo de confirmacion al servicio Pitazo Preventivo e Informativo por sms es: " & SAT.Base.Lib.Datos.CheckStr(dsCelular.Tables(0).Rows(0).Item("cPasswordConfirmacion"))
            Using oSMS As New SAT.SIAT.COM.BLL.Libreria.NX.Sms
                blnEnviado = oSMS.EnviarMensaje(Me.hidCelular.Value, strMensajeCel)
            End Using

            ' Mensaje para la alerta
            strMensaje = ""
            strMensaje += "Estimado ciudadano(a),\n\n"
            strMensaje += "Para concluir con el registro del celular se le ha enviado el c�digo de confirmaci�n a su n�mero de celular,\n"
            strMensaje += "por favor ingrese el c�digo de confirmaci�n en el cuadro de texto C�digo de Confirmaci�n,\n"
            strMensaje += "luego haga clic en el bot�n Confirmar C�digo.\n"
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); $(""#ctl00_cplPrincipal_txtNumCelularConfirmar"").focus(); $(""#ctl00_cplPrincipal_txtNumCelularConfirmar"").addClass('ui-state-error'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmaci�n", strScript)

            Me.btnConfirmarCelular.Visible = True
            Me.btnRegistrarNumero.Visible = False
            Me.txtNumCelularConfirmar.Focus()
        End If
    End Sub

    Protected Sub btnCancelarCelular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelarCelular.Click
        Me.pnlCelular.Visible = False
        Me.btnRegistrarCelular.Visible = True
        Me.txtEmail.Text = ""
        Me.txtEmail.Focus()
    End Sub

    Protected Sub btnConfirmarCelular_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarCelular.Click
        If Not ValidarNumeroConfirmacion() Then Exit Sub
        Dim ds As New DataSet

        Dim strMensaje As String = ""
        Dim strScript As String = ""
        Dim blnConfirmado As Boolean = False
        Try
            Me.lblMensaje.Text = ""

            Using oBLL As New ConsultasWeb
                ds = oBLL.ConfirmarServicioSMS(GetConexionSoporteWEB, CheckInt(GetCodigoRegistroUsuario), Me.txtNumCelularConfirmar.Text, GetIPTerminal)
            End Using

            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then
                'If IsNumeric(ds.Tables(0).Rows(0).Item("bConfirmacionSMS")) Then
                blnConfirmado = SAT.Base.Lib.Datos.CheckBln(ds.Tables(0).Rows(0).Item("bConfirmacionSMS"))
                'End If
                If blnConfirmado Then
                    ' Mensaje para la alerta
                    strMensaje = ""
                    strMensaje += "El registro del celular se realiz� correctamente."
                    strScript = "<script language='javascript'> alert('" & strMensaje & "');</script>"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmaci�n", strScript)

                    Inicio()
                    MostrarPlacas()
                Else
                    strMensaje = ""
                    strMensaje += "No se puede confirmar el n�mero de celular, el c�digo de cofirmaci�n es incorrecto."
                    strScript = "<script language='javascript'> alert('" & strMensaje & "'); $(""#ctl00_cplPrincipal_txtNumCelularConfirmar"").focus(); $(""#ctl00_cplPrincipal_txtNumCelularConfirmar"").addClass('ui-state-error');</script>"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmaci�n", strScript)
                End If
            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
    End Sub

    Protected Sub btnCancelarEmail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelarEmail.Click
        Me.pnlCorreo.Visible = False
        Me.btnRegistrarEmail.Visible = True
    End Sub

    Protected Sub btnRegistrarCorreo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegistrarCorreo.Click
        If Not fbln_ValidarCorreoElectronico() Then Exit Sub
        Dim dsEmail As New DataSet
        Dim strEmail As String = SAT.Base.Lib.Datos.CheckStr(Me.txtEmail.Text)
        Dim strMensaje As String = ""
        Dim strMensajeCel As String = ""
        Dim strScript As String = ""
        Dim blnEnviado As Boolean = False
        Dim strApePat, strApeMat, strNombre, strCadenaEnvio As String
        Dim strServer As String = ""

        Using oBLL As New ConsultasWeb
            dsEmail = oBLL.RegistrarEmail(GetConexionSoporteWEB, CheckInt(GetCodigoRegistroUsuario), strEmail)
        End Using

        If SAT.Base.Lib.Datos.RowCount(dsEmail) > 0 Then

            strApePat = CheckStr(dsEmail.Tables(0).Rows(0)("VAPEPAT"))
            strApeMat = CheckStr(dsEmail.Tables(0).Rows(0)("VAPEMAT"))
            strNombre = CheckStr(dsEmail.Tables(0).Rows(0)("VNOMBRE"))
            strEmail = CheckStr(dsEmail.Tables(0).Rows(0)("VEMAIL"))
            strCadenaEnvio = CheckStr(dsEmail.Tables(0).Rows(0)("NCODUSU"))

            ' Mensaje para el email
            strMensaje = ""
            strMensaje += "Gracias por registrarse como usuario del servicio Pit@zo preventivo e informativo. " & Chr(13) & Chr(13)

            If Request.ServerVariables("SERVER_NAME") = "satwebdesa" Or Request.ServerVariables("SERVER_NAME") = "satwebdesa" Then
                strServer = "http://satwebdesa/website/pitazo/rgConfirmacion.aspx?c=" & strCadenaEnvio & Chr(13) & Chr(13)
            ElseIf Request.ServerVariables("SERVER_NAME") = "webiis_pre" Or Request.ServerVariables("SERVER_NAME") = "webiispre" Then
                strServer = "http://webiispre/website/pitazo/rgConfirmacion.aspx?c=" & strCadenaEnvio & Chr(13) & Chr(13)
            ElseIf Request.ServerVariables("SERVER_NAME") = "localhost" Or Request.ServerVariables("SERVER_NAME") = "localhost" Then
                strServer = "http://localhost/website/pitazo/rgConfirmacion.aspx?c=" & strCadenaEnvio & Chr(13) & Chr(13)
            Else
                strServer = "http://www.sat.gob.pe/website/pitazo/rgConfirmacion.aspx?c=" & strCadenaEnvio & Chr(13) & Chr(13)
            End If

            'If mstrInicioPitazo.ToUpper <> "I" Then
            strMensaje += "A fin de concluir con el proceso de registro, visite el siguiente enlace " & Chr(13) & Chr(13)
            strMensaje += "(Si tienes problemas con el codigo de seguridad, por favor copia directamente el link en tu navegador y recarga la pagina) : " & Chr(13)
            strMensaje += strServer
            'End If
            strMensaje += "Esta es la informacion de la cuenta:" & Chr(13) & Chr(13)
            strMensaje += "Nombre  : " & Trim(UCase(strNombre)) & " " & Trim(UCase(strApePat)) & " " & Trim(UCase(strApeMat)) & " " & Chr(13) & Chr(13)
            strMensaje += "Usuario : " & strEmail & Chr(13) & Chr(13)
            'strMensaje += "Clave   : " & strPassword & Chr(13) & Chr(13) & Chr(13)
            strMensaje += "Atentamente," & Chr(13) & Chr(13)
            strMensaje += "Servicio de Administracion Tributaria" & Chr(13) & Chr(13)

            strMensaje += "PD: Las tildes y enies se han omitido para evitar problemas de compatibilidad entre los software de correo electronico" & Chr(13) & Chr(13)


            Using oBLLMail As New SAT.SIAT.COM.BLL.Libreria.NX.Correo
                oBLLMail.EnvioEmail("REGISTRO - SAT <satvirtual@sat.gob.pe>", strEmail, "SAT Confirmacion de registro", strMensaje)
            End Using

            ' Mensaje para la alerta
            strMensaje = ""
            strMensaje += "Estimado ciudadano(a),\n\n"
            strMensaje += "Para concluir con el registro del correo electr�nico se le ha enviado un mensaje a su correo,\n"
            strMensaje += "por favor ingrese a su buz�n y siga las instrucciones para activar su correo electr�nico registrado,\n"
            strMensaje += "luego ingrese nuevamente a la secci�n de Pitazo Preventivo e Inform�tivo."
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmaci�n", strScript)

            Me.pnlCorreo.Visible = False
            Me.btnRegistrarEmail.Visible = False
            Me.txtPlaca.Focus()
        End If
    End Sub

#Region " Placas de veh�culos "
    Protected Sub btnAgregar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAgregar.Click
        AgregarPlaca()
    End Sub

    Protected Sub grdMisPlacas_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdMisPlacas.PageIndexChanging
        Me.grdMisPlacas.PageIndex = e.NewPageIndex
        grdMisPlacas.PageIndex = e.NewPageIndex
        MostrarPlacas()
    End Sub

    Protected Sub grdMisPlacas_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdMisPlacas.RowDataBound
        On Error Resume Next

        If e.Row.RowType <> DataControlRowType.DataRow Then Return
        Dim LnkEliminar As LinkButton = CType(e.Row.FindControl("LinkEliminar"), LinkButton)

        If LnkEliminar IsNot Nothing Then LnkEliminar.Attributes.Add("onclick", "javascript:window.event.returnValue=confirm('Est� seguro de Eliminar?');")

    End Sub

    Protected Sub grdMisPlacas_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdMisPlacas.RowDeleting
        If e.RowIndex > -1 Then
            Dim strPlaca As String
            Dim index As Integer

            index = e.RowIndex
            strPlaca = CStr(Me.grdMisPlacas.DataKeys(index).Value)

            EliminarPlaca(strPlaca)

        End If
    End Sub

    Protected Sub grdMisPlacas_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdMisPlacas.SelectedIndexChanged
        Dim strPlaca As String = CType(grdMisPlacas.SelectedRow.FindControl("lblPlaca"), Label).Text
        If strPlaca <> "" Then
            Redireccionar(Paginas.Papeletas) ', SetURL("cod", strPlaca)
        End If
    End Sub
#End Region
#End Region

#Region " M�todos Privados "
    '''<summary>M�todo para validar la confirmaci�n del c�digo del celular y los servicios a los cuales esta suscrito el usuario.</summary>
    '''<remarks>
    '''<list type="bullet">
    '''   <item><CreadoPor>David Miranda P.</CreadoPor></item>
    '''   <item><FecCrea>04/11/2009</FecCrea></item>
    '''</list>
    '''<list type="bullet">
    '''   <item><FecActu>02/12/2010</FecActu></item>
    '''   <item><Resp>David Miranda P.</Resp></item>
    '''   <item><Mot>Agregar m�s criterios de validaci�n</Mot></item>
    '''</list>
    '''</remarks>
    Private Function ValidarNumeroConfirmacion() As Boolean
        Dim blnValidado As Boolean = True
        Dim strMensaje As String = ""
        Dim strCelular As String = SAT.Base.Lib.Datos.CheckStr(Me.txtNumCelular.Text)
        Dim strCelularBD As String = SAT.Base.Lib.Datos.CheckStr(Me.hidCelular.Value)
        Dim strCodigo As String = SAT.Base.Lib.Datos.CheckStr(Me.txtNumCelularConfirmar.Text)
        Dim strScript As String = ""

        If strCodigo = "" Then strMensaje += "- C�digo de confirmaci�n."
        If Not strCodigo.Length = 4 Then strMensaje += "\n- El c�digo de confirmaci�n debe contener 4 d�gitos."
        If Not IsNumeric(strCodigo) Then strMensaje += "\n- El c�digo de confirmaci�n debe contener s�lo d�gitos."
        If Not strCelular = strCelularBD Then strMensaje += "\n- El n�mero de celular ha sido modificado, ingrese el que corresponde."
        'If Not (Me.cbPapeletas.Checked Or Me.cbImpVehicular.Checked) Then strMensaje += "\n- Seleccione el servicio o servicios a los que quiere suscribirse."

        If strMensaje.Length > 0 Then
            strMensaje = "Debe completar la siguiente informaci�n para confirmar la suscripci�n:\n" & strMensaje
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validaci�n", strScript)
            blnValidado = False
        End If

        Return blnValidado
    End Function

    Private Function fbln_ValidarNumeroCelular() As Boolean
        Dim blnValidado As Boolean = True
        Dim strScript As String = ""
        Dim strMensaje As String = ""
        Dim strCelular As String = SAT.Base.Lib.Datos.CheckStr(Me.txtNumCelular.Text)
        If Not strCelular = "" Then
            If SAT.Base.Lib.Datos.CheckInt(strCelular) = 0 Then strMensaje += "\n- El n�mero de celular no es n�merico."
            If Not strCelular.Length = 9 Then strMensaje += "\n- El n�mero de celular debe contener 9 d�gitos."
            If Not strCelular.Substring(0, 1) = "9" Then strMensaje += "\n- El n�mero de celular debe iniciar con el n�mero 9."
            'If fbln_ValidarCelular(strCelular) Then strMensaje += "\n- El n�mero de celular ya se encuentra registrado."
        Else
            strMensaje += "\n- Debe ingresar el n�mero de celular."
        End If

        If Not strMensaje = "" Then
            strMensaje = "Para realizar el registro debe completar la informaci�n o corregir los datos incorrectos:\n" & strMensaje
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
            blnValidado = False
        End If

        Return blnValidado
    End Function

    Private Function fbln_ValidarCorreoElectronico() As Boolean
        Dim strEmail As String = SAT.Base.Lib.Datos.CheckStr(Me.txtEmail.Text)

        Dim strScript As String = ""
        Dim strMensaje As String = ""
        Dim blnValidado As Boolean = True

        If strEmail = "" Then strMensaje += "\n- Ingrese su correo electr�nico."

        If Not strEmail = "" Then
            If fbln_ValidarEmail(strEmail) Then strMensaje += "\n- El correo electr�nico ya se encuentra registrado."
        End If

        If Not strMensaje = "" Then
            strMensaje = "Para realizar el registro debe completar la informaci�n o corregir los datos incorrectos:\n" & strMensaje
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); $(""#ctl00_cplPrincipal_txtEmail"").focus(); $(""#ctl00_cplPrincipal_txtEmail"").addClass('ui-state-error'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
            blnValidado = False
        End If

        Return blnValidado
    End Function

    Private Function fbln_ValidarEmail(ByVal vstrEmail As String) As Boolean
        Dim ds As New DataSet
        Dim blnValidado As Boolean = False
        Try
            Using oBLL As New ConsultasWeb
                ds = oBLL.BuscarUsuarioWEB(GetConexionSoporteWEB, 0, vstrEmail, "")
            End Using
            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then blnValidado = True
        Catch
            Throw
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
        Return blnValidado
    End Function

    Private Function fbln_ValidarCelular(ByVal vstrCelular As String) As Boolean
        Dim ds As New DataSet
        Dim blnValidado As Boolean = False
        Try
            Using oBLL As New ConsultasWeb
                ds = oBLL.BuscarUsuarioWEB(GetConexionSoporteWEB, 0, "", vstrCelular)
            End Using
            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then blnValidado = True
        Catch
            Throw
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
        Return blnValidado
    End Function

    Private Sub Inicio()
        Me.lblTitulo.Text = "Pit@zo - Preventivo e Informativo"
        Me.lblMensaje.Visible = False
        Me.btnAnularPapeleta.Attributes.Add("onClick", "javascript:window.event.returnValue=confirm('�Est� seguro de anular el servicio: \nNotificaci�n de Papeletas por email?');")
        Me.btnAnularSms.Attributes.Add("onClick", "javascript:window.event.returnValue=confirm('�Est� seguro de anular el servicio: \nAlertas SMS de Papeletas e Impuesto Vehicular?');")
        Me.btnAnularImpVehicular.Attributes.Add("onClick", "javascript:window.event.returnValue=confirm('�Est� seguro de anular el servicio: \nNotificaci�n de Estado de Cuenta de Impuesto Vehicular por email?');")
        Me.btnInscribirPapeleta.Attributes.Add("onClick", "javascript:window.event.returnValue=confirm('�Est� seguro de susbribirse al servicio: \nNotificaci�n de Papeletas por email?');")
        Me.btnInscribirSms.Attributes.Add("onClick", "javascript:window.event.returnValue=confirm('�Est� seguro de suscribirse al servicio: \nAlertas SMS de Papeletas e Impuesto Vehicular?');")
        Me.btnInscribirImpVehicular.Attributes.Add("onClick", "javascript:window.event.returnValue=confirm('�Est� seguro de suscribirse al servicio: \nNotificaci�n de Estado de Cuenta de Impuesto Vehicular por email?');")
        MostrarDatosUsuario()
        pMostrarServicios()
        Me.txtPlaca.Focus()
        Me.pnlCelular.Visible = False
        Me.pnlCorreo.Visible = False
    End Sub

    Private Sub MostrarDatosUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim bolEstadoCelular As Boolean = False
        Dim strCelular As String = ""
        Dim strCorreo As String = ""

        Try
            intCodigoUsuario = GetCodigoRegistroUsuario()
            ds = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intCodigoUsuario)
            If ds.Tables(0).Rows.Count > 0 Then
                strCelular = CheckStr(ds.Tables(0).Rows(0).Item("VCELULA"))
                strCorreo = CheckStr(ds.Tables(0).Rows(0).Item("vEmail"))
                If strCorreo = "" Then
                    Me.btnRegistrarEmail.Visible = True
                    Me.lblEmail.Visible = False
                Else
                    Me.btnRegistrarEmail.Visible = False
                    Me.lblEmail.Visible = True
                    Me.lblEmail.Text = strCorreo
                End If
                If IsNumeric(ds.Tables(0).Rows(0).Item("bConfirmacionSMS")) Then
                    bolEstadoCelular = CType(ds.Tables(0).Rows(0).Item("bConfirmacionSMS"), Boolean)
                End If
                If bolEstadoCelular Then
                    Me.lblCelular.Text = Left(strCelular, 4) + "*****"
                    Me.lblCelular.Visible = True
                    Me.btnRegistrarCelular.Visible = False
                Else
                    'Me.lblCelular.Text = "(No registrado)"
                    Me.lblCelular.Visible = False
                    Me.btnRegistrarCelular.Visible = True
                    'Me.btnAnularSms.Visible = False
                End If
            End If
        Catch ex As Exception
            Me.lblMensaje.Text = "Error al cargar data "
        Finally
            oBLL = Nothing
            ds = Nothing
        End Try
    End Sub

    Public Function fUrlEncuesta() As String
        Return Resources.Parametros.strURLEncuestaServicios
    End Function
#Region " Servicios "
    '''<summary>M�todo para ocultar los servicios a los que no se encuentra suscrito el usuario.</summary>
    '''<remarks>
    '''<list type="bullet">
    '''   <item><CreadoPor>David Miranda P.</CreadoPor></item>
    '''   <item><FecCrea>02/11/2009</FecCrea></item>
    '''</list>
    '''<list type="bullet">
    '''   <item><FecActu></FecActu></item>
    '''   <item><Resp></Resp></item>
    '''   <item><Mot></Mot></item>
    '''</list>
    '''</remarks>
    Private Sub pMostrarServicios()
        Dim ds As New DataSet
        Dim dv As New DataView
        Dim intCodigoUsuario As Integer = GetCodigoRegistroUsuario()
        Dim strJS As String = ""
        Try
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                ds = oBLL.BuscarServiciosxCodigo(GetConexionSoporteWEB, intCodigoUsuario)
            End Using
            If GetNroRegistros(ds) > 0 Then
                dv = ds.Tables(0).DefaultView
                dv.RowFilter = "siCodServicio = 1"
                If GetNroRegistros(dv.ToTable) <= 0 Then
                    'Me.lblSerPapeletas.Visible = False
                    Me.btnAnularPapeleta.Visible = False
                    Me.btnInscribirPapeleta.Visible = True
                Else
                    Me.btnAnularPapeleta.Visible = True
                    Me.btnInscribirPapeleta.Visible = False
                End If
                dv.RowFilter = ""
                dv.RowFilter = "siCodServicio = 2"
                If GetNroRegistros(dv.ToTable) <= 0 Then
                    'Me.lblSerSMS.Visible = False
                    Me.btnAnularSms.Visible = False
                    Me.btnInscribirSms.Visible = True
                Else
                    Me.btnAnularSms.Visible = True
                    Me.btnInscribirSms.Visible = False
                End If
                dv.RowFilter = ""
                dv.RowFilter = "siCodServicio = 3"
                If GetNroRegistros(dv.ToTable) <= 0 Then
                    'Me.lblSerIV.Visible = False
                    Me.btnAnularImpVehicular.Visible = False
                    Me.btnInscribirImpVehicular.Visible = True
                Else
                    Me.btnAnularImpVehicular.Visible = True
                    Me.btnInscribirImpVehicular.Visible = False
                End If
            Else
                'Me.lblSerPapeletas.Visible = False
                Me.btnAnularPapeleta.Visible = False
                Me.btnInscribirPapeleta.Visible = True
                'Me.lblSerSMS.Visible = False
                Me.btnAnularSms.Visible = False
                Me.btnInscribirSms.Visible = True
                'Me.lblSerIV.Visible = False
                Me.btnAnularImpVehicular.Visible = False
                Me.btnInscribirImpVehicular.Visible = True
                strJS = "alert('Estimado ciudadano(a),\nUsted no se encuentra suscrito a ning�n servicio de Pitazo Preventivo e Inform�tivo,\nPara suscribirse haga clic en el bot�n Inscribirse de cada servicio.');"
                'strJS += "parent.window.close();"
                'strJS += "location.href='http://www.sat.gob.pe';"
                pJSClientScriptBlock(Me, strJS, "Servicios")
            End If
        Catch ex As Exception
            Throw ex
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            If Not (dv Is Nothing) Then dv.Dispose()
            ds = Nothing
            dv = Nothing
        End Try
    End Sub

    Private Sub pAnularSuscripcionServicio(ByVal vintCodServicio As Integer)
        Dim dsSer As New DataSet
        Dim strJS As String = ""
        Dim strMensaje As String = ""
        Dim strScript As String = ""
        Try
            intCodigoUsuario = GetCodigoRegistroUsuario()
            If intCodigoUsuario > 1 Then
                Using objSer As New SAT.HomeSiteBLL.ConsultasWeb
                    dsSer = objSer.AnularSuscripcion(GetConexionSoporteWEB, intCodigoUsuario, vintCodServicio, GetIPTerminal)
                End Using
                Select Case vintCodServicio
                    Case 1
                        'Me.lblSerPapeletas.Visible = False
                        Me.btnAnularPapeleta.Visible = False
                        Me.btnInscribirPapeleta.Visible = True
                        strMensaje = "El servicio de notificaci�n de papeletas por email fue anulado con �xito, si desea puede suscribirse nuevamente."
                    Case 2
                        'Me.lblSerSMS.Visible = False
                        Me.btnAnularSms.Visible = False
                        Me.btnInscribirSms.Visible = True
                        strMensaje = "El servicio de alertas SMS de papeletas e impuesto vehicular fue anulado con �xito, si desea puede suscribirse nuevamente."
                    Case 3
                        'Me.lblSerIV.Visible = False
                        Me.btnAnularImpVehicular.Visible = False
                        Me.btnInscribirImpVehicular.Visible = True
                        strMensaje = "El servicio de notificaci�n de estado de cuenta de impuesto vehicular por email fue anulado con �xito, si desea puede suscribirse nuevamente."
                End Select
                strMensaje = "alert('" & strMensaje & "');"
                pJSClientScriptBlock(Me, strMensaje, "AnularServicio")
                If GetNroRegistros(dsSer) <= 0 Then
                    strJS = "alert('Estimado ciudadano(a),\nUsted no se encuentra suscrito a ning�n servicio de Pitazo Preventivo e Inform�tivo,\nPara suscribirse haga clic en el bot�n Inscribirse de cada servicio.');"
                    'strJS += "parent.window.close();"
                    'strJS += "parent.location = 'http://www.sat.gob.pe';"
                    pJSClientScriptBlock(Me, strJS, "Servicios")
                End If
            End If
        Catch ex As Exception
            Me.lblMensaje.Text = "Error al anular la suscripci�n al servicio."
        Finally
            If Not (dsSer Is Nothing) Then dsSer.Dispose()
            dsSer = Nothing
        End Try
    End Sub

    Private Sub pRegistrarSuscripcionServicio(ByVal vintCodServicio As Integer)
        Dim blnSer As Boolean = False
        Dim strJS As String = ""
        Dim strMensaje As String = ""
        Dim strScript As String = ""
        Try

            intCodigoUsuario = GetCodigoRegistroUsuario()
            If intCodigoUsuario > 1 Then
                Using objSer As New SAT.HomeSiteBLL.ConsultasWeb
                    blnSer = objSer.RegistarSuscripcionServicio(GetConexionSoporteWEB, intCodigoUsuario, vintCodServicio, GetIPTerminal)
                End Using
                Select Case vintCodServicio
                    Case 1
                        Me.btnAnularPapeleta.Visible = True
                        Me.btnInscribirPapeleta.Visible = False
                        strMensaje = "Su suscripci�n al servicio de Notificaci�n de Papeletas por Email, se realiz� correctamente."
                    Case 2
                        Me.btnAnularSms.Visible = True
                        Me.btnInscribirSms.Visible = False
                        strMensaje = "Su suscripci�n al servicio de Alertas SMS de Papeletas e Impuesto Vehicular, se realiz� correctamente."
                    Case 3
                        Me.btnAnularImpVehicular.Visible = True
                        Me.btnInscribirImpVehicular.Visible = False
                        strMensaje = "Su suscripci�n al servicio de Notificaci�n de Estado de Cuenta de Impuesto Vehicular por Email, se realiz� correctamente."
                End Select
                'If blnSer Then
                '    strJS = "alert('Usted ya no se encuentra suscrito a ning�n servicio de Pitazo Preventivo e Inform�tivo, \npara suscribirse nuevamente ingrese a la secci�n Pitazo Preventivo e Informativo.');"
                '    strJS += "parent.window.close();"
                '    'strJS += "parent.location = 'http://www.sat.gob.pe';"
                '    pJSClientScriptBlock(Me, strJS, "Servicios")
                'End If
                'strMensaje = "Para realizar el registro debe completar la informaci�n o corregir los datos incorrectos:\n" & strMensaje
                strScript = "alert('" & strMensaje & "');"
                'Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmacion", strScript)
                pJSClientScriptBlock(Me, strScript, "Confirmacion")
            End If
        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al anular la suscripci�n al servicio."
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        End Try
    End Sub
#End Region

#Region " Placas de veh�culos "
    Private Sub AgregarPlaca()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Try
            intCodigoUsuario = GetCodigoRegistroUsuario()

            Dim strPlaca As String = Nothing
            strPlaca = Trim(Me.txtPlaca.Text)
            strPlaca = UCase(strPlaca)
            strPlaca = ValidaCadena(strPlaca)
            If strPlaca.Length > 4 Then
                ds = oBLL.RegistrarPlaca(GetConexionSoporteWEB, intCodigoUsuario, strPlaca)
                MostrarPlacas()
                Me.txtPlaca.Text = ""
            Else
                Me.lblMensaje.Text = "Placa incorrecta "
                Me.lblMensaje.ForeColor = Drawing.Color.Red
            End If

        Catch ex As Exception
            Me.lblMensaje.Text = "Error  al Registrar Placa"
        Finally
            oBLL = Nothing
        End Try
    End Sub

    Private Sub EliminarPlaca(ByVal strPlaca As String)
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Try
            intCodigoUsuario = GetCodigoRegistroUsuario()

            ds = oBLL.EliminarPlacaUsuario(GetConexionSoporteWEB, intCodigoUsuario, strPlaca)
            MostrarPlacas()

        Catch ex As Exception
            Me.lblMensaje.Text = "Error: " & ex.Message
        Finally
            oBLL = Nothing
        End Try
    End Sub

    Private Sub MostrarPlacas()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim intItem As Integer
        Try
            intCodigoUsuario = GetCodigoRegistroUsuario()

            ds = oBLL.MostrarPlacasUsuario(GetConexionSoporteWEB, intCodigoUsuario)
            For intItem = 0 To ds.Tables(0).Rows.Count - 1
                ds.Tables(0).Rows(intItem)("NCODUSU") = intItem + 1
            Next

            If ds.Tables.Count > 0 Then
                Me.grdMisPlacas.DataSource = ds.Tables(0)
                Me.grdMisPlacas.DataBind()

                Me.lblMensaje.Text = "Listado de placa(s) registrada(s). Nota: Para dejar de recibir alertas en su correo, dar clic en Eliminar."
                Me.lblMensaje.ForeColor = Drawing.Color.Black
                Me.lblCantRegistros.Text = "Se encontraron <b>" + ds.Tables(0).Rows.Count.ToString + "</b> placas registradas."
                'Me.txtPlaca.Text = ""
            End If
        Catch ex As Exception
            Me.lblMensaje.Text = "Error al cargar data "
        Finally
            oBLL = Nothing
            ds = Nothing
        End Try
    End Sub
#End Region

#End Region

End Class
