
Partial Class cabecera
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.lblFechaHora.Text = Date.Today.ToLongDateString.ToUpper
    End Sub
End Class
