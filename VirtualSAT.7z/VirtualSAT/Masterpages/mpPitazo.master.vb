﻿
Partial Class masterpage_mpPitazo
    Inherits System.Web.UI.MasterPage
End Class

