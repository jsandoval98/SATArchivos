Option Explicit On
Option Strict On

Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito

Public Class PageBase
   Inherits System.Web.UI.Page

   Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

   End Sub

   Public Sub ProcesarFilaDataGrid(ByRef e As System.Web.UI.WebControls.GridViewRowEventArgs)
      Dim strTipEdo As String = CType(e.Row.FindControl("lblEstadoID"), Label).Text
      Dim strDocumento As String = CType(e.Row.FindControl("lblDocumento"), Label).Text
      Dim strConcepto As String = CType(e.Row.FindControl("lblCodCre"), Label).Text
      Dim strSaldo As Double = CType(CType(e.Row.FindControl("lblDeuda"), Label).Text, Double)

      If strTipEdo <> "1" Then
         CType(e.Row.FindControl("chkSeleccion"), CheckBox).Enabled = False         
      End If

      If strSaldo <= 0 Then
         CType(e.Row.FindControl("chkSeleccion"), CheckBox).Enabled = False         
      End If

      If Not e.Row.FindControl("lblPagado") Is Nothing Then
         If CDbl(CType(e.Row.FindControl("lblPagado"), Label).Text) > 0 Then
            CType(e.Row.FindControl("chkSeleccion"), CheckBox).Enabled = False
            CType(e.Row.FindControl("chkSeleccion"), CheckBox).ToolTip = "No se puede pagar por internet porque esta cuenta tiene pagos parciales."            
         End If
      End If

      If Not e.Row.FindControl("lblPeriodo") Is Nothing Then
         If CInt(CType(e.Row.FindControl("lblPeriodo"), Label).Text) <> 0 Then
            CType(e.Row.FindControl("imgAyuda"), HtmlControls.HtmlImage).Visible = False
         Else
            e.Row.CssClass = "AltRowStyle"
         End If
      End If

      If BuscarDocumentoCarrito(strDocumento) Then
         CType(e.Row.FindControl("chkSeleccion"), CheckBox).Checked = True
         CType(e.Row.FindControl("chkSeleccion"), CheckBox).Enabled = False
      Else
         If HabilitarCheckPago(strConcepto) Then
            CType(e.Row.FindControl("chkSeleccion"), CheckBox).Enabled = True
         Else
            CType(e.Row.FindControl("chkSeleccion"), CheckBox).Enabled = False
         End If
      End If

   End Sub

End Class

