Imports System.Data

Partial Class controles_ucFiltros
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        Dim dsAnios As New DataSet
        Dim dsEstados As New DataSet
        dsAnios.ReadXml(Request.MapPath("~/App_Data/") + "Anios.xml")
        If Not dsAnios Is Nothing Then
            Me.ddlAnio.DataSource = dsAnios.Tables(0)
            Me.ddlAnio.DataBind()
        End If
        dsEstados.ReadXml(Request.MapPath("~/App_Data/") + "EstDocumento.xml")
        If Not dsAnios Is Nothing Then
            Me.ddlEstado.DataSource = dsEstados.Tables(0)
            Me.ddlEstado.DataBind()
        End If
    End Sub

End Class
