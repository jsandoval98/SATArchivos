﻿Option Explicit On
Option Strict On

Imports System
Imports System.Web
Imports System.Web.UI

Imports System.Globalization
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data

Imports SAT
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones
Imports SAT.SeguridadSAT.Encriptacion


Partial Class modulos_RegistrarDic
    Inherits PageBase

    Private strNameCnxSIAT001 As String = "BDSIAT001"
    Private strNameCnxSIAT002 As String = "BDSIAT002"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'ValidarPagina()
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)

            fctrl_BuscarControl("divResumen").Visible = False
            ddlCodigoInfSufijo.Enabled = False
            ddlCodigoInfSufijo.Items.Add("")
            ddlCodigoInfSufijo.Items.Add("a")
            ddlCodigoInfSufijo.Items.Add("b")
            ddlCodigoInfSufijo.SelectedIndex = 0
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario

        '------- VALIDA USER FOR REGISTER
        If String.IsNullOrEmpty(strUsuario) Or strUsuario.Contains("Invitado") Then
            divAuteticaDatos.Visible = True
            divRegistrar.Visible = False
            divResumen.Visible = False

        Else

            divAuteticaDatos.Visible = False
            divRegistrar.Visible = True
            divResumen.Visible = False

            Dim strCorreo As String = CStr(Session.Item("email"))
            If pValidarCorreoSospechoso(strCorreo) = 1 Then
                Me.lblMensajeSospechoso.Text = "Mensaje: El correo " + strCorreo + " se encuentra en observación por el operador de la tarjeta."
                Me.lblMensajeLogin.ForeColor = Drawing.Color.Red
                btnPagar.Visible = False
                pOcultarTodo()
                lblMensajeSospechoso.Visible = True
                Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
                Exit Sub
            End If

        End If
        '-------

        ds = Nothing
        oBLL = Nothing
    End Sub

    ''' ///////////////////////////////////////////// LOGIN ///////////////////////////////////////////////////////////
    Private Sub pLogin()
        Dim strUsuario As String = ValidaCorreo(Me.txtEmailLogin.Text)
        Dim strClave As String = Me.txtClave.Text.Trim
        Dim ds As DataSet
        Dim strEstadoRegistro As String
        Dim bolOK As Boolean = False
        Dim strMensaje As String = ""
        Dim strPass As String = ""
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        If strUsuario = "" Or strClave = "" Then
            strMensaje = "Ingrese su correo y clave."
            Me.lblMensajeLogin.Text = strMensaje
            Exit Sub
        End If

        'Validar correo sospechoso

        If pValidarCorreoSospechoso(strUsuario) = 1 Then
            Me.lblMensajeSospechoso.Text = "Mensaje: El correo " + strUsuario + " se encuentra en observación por el operador de la tarjeta. "
            Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
            btnPagar.Visible = False
            pOcultarTodo()
            lblMensajeSospechoso.Visible = True
            Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
            Exit Sub
        Else
            Using oBLL As New ConsultasWeb
                ds = oBLL.BuscarUsuarioWEB(GetConexionSoporteWEB, 0, strUsuario, "")
                If ds.Tables(0).Rows.Count > 0 Then
                    strEstadoRegistro = CheckStr(ds.Tables(0).Rows(0)("vEstPer"))
                    strPass = CheckStr(ds.Tables(0).Rows(0)("vPasswd"))
                    Select Case strEstadoRegistro
                        Case "1"
                            If ValidarClave(strClave, strPass) Then
                                bolOK = True
                            Else
                                strMensaje = "Clave incorrecta."
                            End If
                        Case "0"
                            strMensaje = "Su usuario(correo) no ha sido confirmado, en estos momentos se le esta enviado un correo para confirmar la propiedad del correo."
                        Case Else

                    End Select
                Else
                    strMensaje = "Correo no registrado: " + strUsuario
                End If

            End Using

            If bolOK Then
                'pMostrarDatosUsuario(ds.Tables(0))

                lblusr.Text = strUsuario

                divAuteticaDatos.Visible = False
                divRegistrar.Visible = True
                divResumen.Visible = False

            Else
                Me.lblMensajeLogin.Text = strMensaje
                divAuteticaDatos.Visible = True
                divRegistrar.Visible = False
                divResumen.Visible = False

            End If

            ds = Nothing
        End If

    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        pLogin()
    End Sub

    Protected Function pValidarCorreoSospechoso(ByVal sCorreo As String) As Integer
        Dim validaOK As Integer = 0
        Dim dsUsuario As New DataSet
        Dim strCorreo As String
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")

        If txtEmailLogin.Text = "" Then
            strCorreo = CStr(Session.Item("email"))
        Else
            strCorreo = ValidaCorreo(Me.txtEmailLogin.Text)
        End If

        Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
            dsUsuario = oBLL.ConsultarCorreoSospechoso(GetConexionPagosVirtuales, strCorreo)
            If dsUsuario.Tables(0).Rows.Count > 0 Then
                validaOK = 1
            End If

        End Using

        dsUsuario = Nothing
        Return validaOK

    End Function
    Shared Function ValidaCorreo(ByVal vstrCadena As String) As String
        If vstrCadena Is Nothing Or vstrCadena Is DBNull.Value Then
            Return ""
        End If
        vstrCadena = vstrCadena.Replace("'", "")
        vstrCadena = vstrCadena.Replace("--", "")
        vstrCadena = vstrCadena.Replace("&", "")
        vstrCadena = vstrCadena.Replace("""", "")
        vstrCadena = vstrCadena.Replace("%", "")
        vstrCadena = vstrCadena.Replace("#", "")
        Return vstrCadena.Trim
    End Function
    Private Sub pOcultarTodo()
        Me.divAuteticaDatos.Visible = False
        'Me.divAutenticaTexto.Visible = False
        'Me.divFormaPago.Visible = False
    End Sub
    ''' ///////////////////////////////////////////// FIN - LOGIN ///////////////////////////////////////////////////////////


    Protected Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click

        'Dim strNumDocS As String
        Dim strPlaca As String
        Dim strFechaInf As String
        Dim strFechaNoti As String
        Dim strCodigoInf As String
        Dim strNumLic As String
        Dim strFechaReval As String

        Dim shCodMun As Int16 = 1
        Dim strNumDocS As String = txtNumDocS.Text.Trim
        Dim strEstadoPapeleta As String = ""
        Dim strPlacaPapeleta As String = ""
        Dim strDocImpCargo As String = ""
        Dim strCodInfraccion As String = ""
        Dim strImportePagado As String = ""
        Dim strFechaPago As String = ""
        Dim strEstadoMensaje As String = ""

        Dim dtTabla As New DataTable
        dtTabla = fdta_Papeleta_BuscarEstado(shCodMun, strNumDocS)

        'Validar Estado
        If dtTabla.Rows.Count > 0 Then
            strEstadoPapeleta = dtTabla.Rows(0)(3).ToString
            strPlacaPapeleta = dtTabla.Rows(0)(4).ToString
            strDocImpCargo = dtTabla.Rows(0)(5).ToString
            strCodInfraccion = dtTabla.Rows(0)(6).ToString
            strImportePagado = dtTabla.Rows(0)(7).ToString
            strFechaPago = dtTabla.Rows(0)(8).ToString

            If strEstadoPapeleta = "Cancelado" Then
                strEstadoMensaje = "El número de papeleta " + strNumDocS + " no registra deuda pendiente<br>"
                strEstadoMensaje = strEstadoMensaje + "Placa del vehículo infractor: " + strPlacaPapeleta + "<br>"
                strEstadoMensaje = strEstadoMensaje + "N° documento de imputación de cargo: " + strDocImpCargo + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Código de infracción: " + strCodInfraccion + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Importe pagado: " + strImportePagado + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Fecha de pago: " + strFechaPago
            End If

            If strEstadoPapeleta = "Anulado" Then
                strEstadoMensaje = "El número de papeleta " + strNumDocS + " se encuentra anulado para mayor información comuníquese con AlóSAT al teléfono 315-2400 o al correo asuservicio@sat.gob.pe"
            End If

            If strEstadoPapeleta = "Pendiente" Then
                'RN003 - Para los documentos en estado “Pendiente”, se direccionará al resultado de la consulta de papeletas.
            End If

            If strEstadoPapeleta = "Pagado" Then
                strEstadoMensaje = "El número de papeleta " + strNumDocS + " no registra deuda pendiente<br>"
                strEstadoMensaje = strEstadoMensaje + "Placa del vehículo infractor: " + strPlacaPapeleta + "<br>"
                strEstadoMensaje = strEstadoMensaje + "N° documento de imputación de cargo: " + strDocImpCargo + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Código de infracción: " + strCodInfraccion + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Importe pagado: " + strImportePagado + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Fecha de pago: " + strFechaPago
            End If

            If strEstadoPapeleta = "Registrado" Then
                strEstadoMensaje = "La operación de pago  de la papeleta " + strNumDocS + " se encuentra pendiente de confirmación, para mayor información comuníquese con su operador bancario"
            End If

            lblMensaje.Text = strEstadoMensaje
            Exit Sub
        End If

        'Validar Código de infracción
        Dim strCodigoInfLetra As String = txtCodigoInfLetra.Text.Trim
        Dim strCodigoInfNumero As String = txtCodigoInfNumero.Text.Trim
        Dim strCodigoInfSufijo As String = ddlCodigoInfSufijo.SelectedValue.Trim
        Dim strCodigoInfLetraNumero As String = strCodigoInfLetra + strCodigoInfNumero

        Dim strFechaInfraccion As String = txtFechaInf.Text.Trim
        Dim dtFechaInfraccion As Date = Convert.ToDateTime(strFechaInfraccion)

        Dim dtFechaMenor As Date = Convert.ToDateTime("31/12/2019")
        Dim dtFechaMayor As Date = Convert.ToDateTime("01/01/2019")

        'Validación Código Infracción Letra
        If strNumDocS.Length > 0 AndAlso (strNumDocS.Substring(0, 1) = "E" Or IsNumeric(strNumDocS)) Then
            If Not (strCodigoInfLetra.Substring(0, 1) = "M" Or strCodigoInfLetra.Substring(0, 1) = "G" Or strCodigoInfLetra.Substring(0, 1) = "L") Then
                strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                lblMensaje.Text = strEstadoMensaje
                Exit Sub
            End If
        End If

        If strNumDocS.Length > 0 AndAlso (strNumDocS.Substring(0, 1) = "C" Or _
                                          strNumDocS.Substring(0, 2) = "CE" Or _
                                          strNumDocS.Substring(0, 1) = "I") Then

            If dtFechaInfraccion <= dtFechaMenor Then 'menor o igual al 31 de diciembre de 2019

                If Not (strCodigoInfLetra.Substring(0, 1) = "N" Or _
                        strCodigoInfLetra.Substring(0, 1) = "R" Or _
                        strCodigoInfLetra.Substring(0, 1) = "E" Or _
                        strCodigoInfLetra.Substring(0, 1) = "U" Or _
                        strCodigoInfLetra.Substring(0, 1) = "V" Or _
                        strCodigoInfLetra.Substring(0, 1) = "Z") Then
                    strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                End If

                If dtFechaInfraccion >= dtFechaMayor Then 'mayor o igual al 01 de enero de 2019
                    strEstadoMensaje = String.Empty
                    If Not (strCodigoInfLetra.Substring(0, 1) = "U" Or _
                            strCodigoInfLetra.Substring(0, 1) = "V") Then
                        strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                    End If
                End If
            Else
                If dtFechaInfraccion >= dtFechaMayor Then 'mayor o igual al 01 de enero de 2019
                    If Not (strCodigoInfNumero.Substring(0, 1) = "N" Or _
                            strCodigoInfNumero.Substring(0, 1) = "V") Then
                        strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                    End If
                End If
            End If

            If strEstadoMensaje.Length <> 0 Then
                lblMensaje.Text = strEstadoMensaje
                Exit Sub
            End If

        End If

        'Validación Código Infracción Número - SENSITIVA

        'Validación Código Infracción Sufijo
        If strCodigoInfLetraNumero = "G18" Or _
           strCodigoInfLetraNumero = "G31" Or _
           strCodigoInfLetraNumero = "G72" Then
            If Not (strCodigoInfSufijo = "a" Or _
                    strCodigoInfSufijo = "b") Then
                strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                lblMensaje.Text = strEstadoMensaje
                Exit Sub
            End If
        End If

        'Nombre de la Falta
        Dim dtFalta As New DataTable

        Dim dtFechaRef As Date = Date.Now
        Dim strFechaRef As String = dtFechaRef.ToString("dd/MM/yyyy")
        Dim strCodFal As String = strCodigoInfLetra + strCodigoInfNumero + strCodigoInfSufijo
        dtFalta = fdta_Infraccion_BuscarPorCodigo(strFechaRef, strCodFal)

        If dtFalta.Rows.Count = 0 Then
            strEstadoMensaje = "El Código de Infracción no existe"
            lblMensaje.Text = strEstadoMensaje
            Exit Sub
        End If

        'Datos Personales
        strPlaca = txtPlaca.Text.Trim
        strFechaInf = txtFechaInf.Text.Trim
        strFechaNoti = txtFechaNoti.Text.Trim
        strCodigoInf = txtCodigoInfLetra.Text.Trim + txtCodigoInfNumero.Text.Trim + ddlCodigoInfSufijo.Text.Trim
        strNumLic = txtNumLic.Text.Trim
        strFechaReval = txtFechaReval.Text.Trim

        lblNumDocSRes.Text = strNumDocS
        lblPlacaRes.Text = strPlaca
        lblFechaInfRes.Text = strFechaInf
        lblCodigoInfRes.Text = strCodigoInf
        lblDesInfRes.Text = dtFalta.Rows(0)(5).ToString.Trim
        lblNumLicRes.Text = strNumLic

        'Datos Ocultos
        hdnfldReglaInf.Value = dtFalta.Rows(0)(4).ToString.Trim
        hdnfldCodCre.Value = dtFalta.Rows(0)(8).ToString.Trim

        'Calculo del Importe a Pagar
        'Dim ObjRE As New SAT.SIAT.COM.BLL.RE.Conciliacion.NX.Deuda
        Dim dtDeuda As DataTable

        Dim strFecCalculo As String = dtFechaRef.ToString("dd/MM/yyyy")
        Dim strFecPago As String = dtFechaRef.ToString("dd/MM/yyyy")

        Dim arrParam As New ArrayList
        arrParam.Add(1) '@psiCodMun
        arrParam.Add(strNumDocS) '@pcPapele
        arrParam.Add(strPlaca) '@pcPlaca
        arrParam.Add(strFechaInf) '@psdFecInf
        arrParam.Add(4) '@psiCodRgl
        arrParam.Add(34) '@psiCodBLe
        arrParam.Add(strCodigoInf) '@pcCodFal
        arrParam.Add(0) '@psiTipDiD
        arrParam.Add("") '@pcDocIde
        arrParam.Add(strNumLic) '@pcLicCon
        arrParam.Add(strFecCalculo) '@psdFecCal
        arrParam.Add(0) '@psiCodUsu 
        arrParam.Add(strFecPago) '@psdFecPag
        arrParam.Add(1) '@psiTipAge 
        arrParam.Add(1) '@psiCodDPo
        arrParam.Add(0) '@psiModo
        arrParam.Add(0) '@piCantVehiculo
        arrParam.Add("1") '@pcCalDescuento
        arrParam.Add(Nothing) '@pcFecRevLicencia

        'dtDeuda = ObjRE.ConsultarDeudaDigitada(arrParam)
        dtDeuda = fdta_Papeleta_ConsultarDeudaDigitada(arrParam)

        Dim dblCuota As Double
        'Dim dblReinc As Double
        If dtDeuda.Rows.Count > 0 Then
            dblCuota = Convert.ToDouble(dtDeuda.Rows(0).Item("nCuota")) - Convert.ToDouble(dtDeuda.Rows(0).Item("nDesCuo"))
            'dblReinc = Convert.ToDouble(dtDeuda.Rows(0).Item("nReinci")) - Convert.ToDouble(dtDeuda.Rows(0).Item("nDesRei"))
        End If

        'lblImporteRes.Text = dblCuota.ToString("0.00") + " - " + dblReinc.ToString("0.00")
        lblImporteRes.Text = dblCuota.ToString("0.00")

        fctrl_BuscarControl("divRegistrar").Visible = False
        fctrl_BuscarControl("divResumen").Visible = True

    End Sub

    Protected Sub btnCorregir_Click(sender As Object, e As EventArgs) Handles btnCorregir.Click

        lblMensaje.Text = String.Empty
        fctrl_BuscarControl("divRegistrar").Visible = True
        fctrl_BuscarControl("divResumen").Visible = False

        Dim strCodigoInfLetra As String = txtCodigoInfLetra.Text.Trim
        Dim strCodigoInfNumero As String = txtCodigoInfNumero.Text.Trim

        Dim strCodigoInfLetraNumero As String = strCodigoInfLetra + strCodigoInfNumero

        If strCodigoInfLetraNumero = "G18" Or _
           strCodigoInfLetraNumero = "G31" Or _
           strCodigoInfLetraNumero = "G72" Then
            ddlCodigoInfSufijo.Enabled = True
        Else
            ddlCodigoInfSufijo.Enabled = False
        End If

    End Sub

    Private Function fctrl_BuscarControl(ByVal pstrNameControl As String) As Control
        'Return FindControl(pstrNameControl)
        Return Master.FindControl("cplPrincipal").FindControl(pstrNameControl)
    End Function

    Private Function fbol_ValidarNumDocS() As Boolean
        Dim bolVal As Boolean = True

        Dim strNumDocS As String = txtNumDocS.Text.Trim()
        Dim strMensaje As String = String.Empty

        strMensaje = "Ingrese una Papeleta Válida"

        'Validacion RN002
        If strNumDocS.Length = 8 AndAlso IsNumeric(strNumDocS) Then
            strMensaje = String.Empty
        Else
            If strNumDocS.Length = 9 AndAlso (strNumDocS.Substring(0, 1) = "C" Or strNumDocS.Substring(0, 1) = "E") Then
                If IsNumeric(strNumDocS.Substring(1, 8)) Then
                    strMensaje = String.Empty
                End If
            Else
                If strNumDocS.Length = 10 AndAlso (strNumDocS.Substring(0, 2) = "CE") Then
                    If IsNumeric(strNumDocS.Substring(2, 8)) Then
                        strMensaje = String.Empty
                    End If
                Else
                    If strNumDocS.Length = 12 AndAlso (strNumDocS.Substring(0, 1) = "I") Then
                        strMensaje = String.Empty
                    End If
                End If
            End If
        End If

        If strMensaje.Length > 0 Then
            bolVal = False
        End If

        lblMensaje.Text = strMensaje
        Return bolVal
    End Function

    Private Function fbol_ValidarRegistro() As Boolean
        Dim bolVal As Boolean = True

        Dim strErrorNumDocS As String = lblErrorNumDocS.Text.Trim()
        Dim strErrorPlaca As String = lblErrorPlaca.Text.Trim()
        Dim strErrorFechaInf As String = lblErrorFechaInf.Text.Trim()
        Dim strErrorFechaNoti As String = lblErrorFechaNoti.Text.Trim()
        Dim strErrorCodigoInf As String = lblErrorCodigoInf.Text.Trim()
        Dim strErrorFechaReval As String = lblErrorFechaReval.Text.Trim()

        Return bolVal
    End Function

    Private Function fdta_Papeleta_BuscarEstado(ByVal pshsiCodMun As Int16, ByVal pstrcPapele As String) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Papeleta_BuscarEstado", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psiCodMun", pshsiCodMun)
        cmd.Parameters.AddWithValue("@pcPapele", pstrcPapele)

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function

    Private Function fdta_Papeleta_ConsultarDeudaDigitada(ByVal arrParam As ArrayList) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Papeleta_ObtenerDeudaDigitada", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psiCodMun", arrParam(0))
        cmd.Parameters.AddWithValue("@pcPapele", arrParam(1))
        cmd.Parameters.AddWithValue("@pcPlaca", arrParam(2))
        cmd.Parameters.AddWithValue("@psdFecInf", arrParam(3))
        cmd.Parameters.AddWithValue("@psiCodRgl", arrParam(4))
        cmd.Parameters.AddWithValue("@psiCodBLe", arrParam(5))
        cmd.Parameters.AddWithValue("@pcCodFal", arrParam(6))
        cmd.Parameters.AddWithValue("@psiTipDiD", arrParam(7))
        cmd.Parameters.AddWithValue("@pcDocIde", arrParam(8))
        cmd.Parameters.AddWithValue("@pcLicCon", arrParam(9))
        cmd.Parameters.AddWithValue("@psdFecCal", arrParam(10))
        cmd.Parameters.AddWithValue("@psiCodUsu", arrParam(11))
        cmd.Parameters.AddWithValue("@psdFecPag", arrParam(12))
        cmd.Parameters.AddWithValue("@psiTipAge", arrParam(13))
        cmd.Parameters.AddWithValue("@psiCodDPo", arrParam(14))
        cmd.Parameters.AddWithValue("@psiModo", arrParam(15))
        cmd.Parameters.AddWithValue("@piCantVehiculo", arrParam(16))
        cmd.Parameters.AddWithValue("@pcCalDescuento", arrParam(17))
        cmd.Parameters.AddWithValue("@pcFecRevLicencia", arrParam(18))

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function


    Private Function fdta_Infraccion_BuscarPorCodigo(ByVal pstrFechaRef As String, ByVal pstrCodFal As String) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Infraccion_BuscarPorCodigo", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psdFechaRef", pstrFechaRef)
        cmd.Parameters.AddWithValue("@pcCodFal", pstrCodFal)

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function

    Protected Sub btnPagar_Click(sender As Object, e As EventArgs) Handles btnPagar.Click

        If chkTerminos.Checked Then
            'EliminarCuentaCarrito()
            ProcesarGridCarritoTransito("Papeletas")

            Dim strURL As String = BuscarMensaje("pagina_carrito_inicio") + "?" + SetUrlLibre("mysession", MySessionID)
            strURL = strURL + "&" + SetUrlLibre("tri", GetUrlLibre("tri"))
            strURL = strURL + "&" + SetUrlLibre("dic", "1")
            'lblMensajeRes.Text = strURL
            Response.Redirect(strURL)
        End If

    End Sub

    Public Sub ProcesarGridCarritoTransito(ByVal vstrConcepto As String)
        'Public Sub ProcesarGridCarritoTransito(ByVal vdg As GridView, ByVal vstrConcepto As String)
        Dim i As Integer = 0
        Dim dtCarritoTemp As DataTable
        Dim bolBeneficio As Boolean = False
        Dim dblMonto As Double = 0

        'Dim strCodigoInf As String
        'strCodigoInf = txtCodigoInfLetra.Text.Trim + txtCodigoInfNumero.Text.Trim + ddlCodigoInfSufijo.Text.Trim

        dtCarritoTemp = GetEstructuraTablaCarrito()
        'For i = 0 To vdg.Rows.Count - 1
        bolBeneficio = GetEstadoBeneficio()
        If Not bolBeneficio Then
            dblMonto = Double.Parse(lblImporteRes.Text.Trim) 'Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblDeuda"), Label).Text)
        Else
            dblMonto = 0 'Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblBeneficio"), Label).Text)
        End If
        'If CType(vdg.Rows.Item(i).FindControl("chkSeleccion"), CheckBox).Checked And dblMonto > 0 Then
        Dim dr As DataRow
        dr = dtCarritoTemp.NewRow

        dr("id") = i
        dr("concepto") = vstrConcepto
        'dr("referencia") = CType(vdg.Rows.Item(i).FindControl("lblPlaca"), Label).Text + " " + GetNombreReglamento(Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblCodCre"), Label).Text)) + " " + CType(vdg.Rows.Item(i).FindControl("lblFalta"), Label).Text + " " + CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text
        dr("referencia") = lblPlacaRes.Text.Trim + " " + hdnfldReglaInf.Value.Trim + " " + lblCodigoInfRes.Text.Trim + " " + Date.Now.ToString("dd/MM/yyyy")
        'dr("documento") = CType(vdg.Rows.Item(i).FindControl("lblDocumento"), Label).Text
        dr("documento") = lblNumDocSRes.Text.Trim
        dr("monto") = dblMonto
        dr("ncuota") = 0
        dr("emision") = 0
        dr("reajuste") = 0
        'If IsNumeric(vdg.Rows.Item(i).FindControl("lblMora")) Then
        '    dr("mora") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblMora"), Label).Text)
        'Else
        '    dr("mora") = 0
        'End If
        dr("mora") = 0

        'dr("importe") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblImporte"), Label).Text)
        dr("importe") = dblMonto

        dr("reinci") = 0
        'dr("gastos") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblGastos"), Label).Text)
        dr("gastos") = 0
        dr("costas") = 0
        'dr("descuento") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblDescuento"), Label).Text)
        dr("descuento") = 0
        'dr("sicodcre") = Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblCodCre"), Label).Text)
        dr("sicodcre") = Integer.Parse(hdnfldCodCre.Value)
        'dr("anio") = CDate(CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text).Year
        dr("anio") = Date.Now.Year
        'dr("periodo") = CDate(CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text).Month
        dr("periodo") = Date.Now.Month
        'dr("datosimp") = CType(vdg.Rows.Item(i).FindControl("lblPlaca"), Label).Text + " " + CType(vdg.Rows.Item(i).FindControl("lblFalta"), Label).Text + " " + CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text
        dr("datosimp") = lblPlacaRes.Text.Trim + " " + lblCodigoInfRes.Text.Trim + " " + Date.Now.ToString("dd/MM/yyyy")
        dr("icodper") = 0
        dr("server") = "P"

        dtCarritoTemp.Rows.Add(dr)
        'End If
        'Next
        CargarPagosCarritoTransito(dtCarritoTemp, vstrConcepto)
    End Sub

    Public Sub EliminarCuentaCarrito()
        Dim ds As DataSet = GetCarrito()
        Dim i As Integer
        ds.Tables(0).Clear()
        SalvarCarrito(ds)
    End Sub

End Class
