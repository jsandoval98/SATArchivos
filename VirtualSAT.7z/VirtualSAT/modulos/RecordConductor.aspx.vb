Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones
Imports System.IO
Imports CaptchaDLL

Partial Class modulos_RecordConductor
    Inherits PageBase

    Private intCaptcha As Integer = 4

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        'If Request.QueryString("tipoSancion") = "cond" Then
        Me.lblTitulo.Text = "INFRACCIONES DEL CONDUCTOR"
        Me.lblTexto.Text = "Ingresando los datos solicitados, podr� obtener el historial de papeletas dirigidas a determinado conductor."
        'Else
        'Me.lblTitulo.Text = "INFRACCIONES DEL PEAT�N"
        'Me.lblTexto.Text = "Ingresando los datos solicitados, podr� obtener el historial de papeletas dirigidas a determinado peat�n."
        ' End If

        lblFecha.Text = ""
        lblMensajeVacio.Text = ""
        Me.fecConsulta.Visible = False
        Me.divContenido.Visible = False
    End Sub

    Private Function getFileSQL() As String
        Dim strContents As String
        Dim objReader As StreamReader
        Dim strFile As String = HttpContext.Current.Request.MapPath("~/modulos/library/recordFiltro.sql")
        Try
            objReader = New StreamReader(strFile)
            strContents = objReader.ReadToEnd()
            objReader.Close()
            Return strContents
        Catch Ex As Exception
            Throw Ex
        End Try

    End Function

    Private Sub BuscarLicencia(ByVal vintTipo As Integer)
        Dim oBLL As New ConsultasVarias
        Dim dsRecord As DataSet
        Dim strLicencia As String
        Dim strDNI As String
        Dim vstrFecCal As String = Date.Now.ToString("dd/MM/yyyy")
        Dim strMensaje As String = ""
        Dim intCantidad As Integer
        Dim strDoc As String = ""
        Dim i As Integer
        Dim dvRecord As DataView
        Dim dsReporte As New DataSet
        Dim strNombre As String = ""
        Dim dsReniec As DataSet

        strLicencia = ValidaCadena(txtLicencia.Text)
        strDNI = ValidaCadena(Me.txtDNI.Text)
        If vintTipo = 1 Then
            strDoc = strLicencia
            Me.grdRecord.Columns(7).Visible = False
            Me.grdRecord.Columns(8).Visible = True
        ElseIf vintTipo = 2 Then
            strDoc = strDNI
            Me.grdRecord.Columns(7).Visible = True
            Me.grdRecord.Columns(8).Visible = False
        End If

        Me.grdRecord.DataSource = Nothing
        Me.grdRecord.DataBind()
        Me.lblConductor.Text = ""
        Me.lblMensajeVacio.Text = ""

        If strDoc <> "" Then
            dsRecord = oBLL.BuscarInfraccionesConductor(GetConexionSiatTransitoLinea, 1, vintTipo.ToString, vintTipo.ToString, strDoc, vstrFecCal)
            dsRecord.Tables(0).Columns.Add(New DataColumn("dFecInf", Type.GetType("System.DateTime")))
            For i = 0 To dsRecord.Tables(0).Rows.Count - 1
                dsRecord.Tables(0).Rows(i)("dFecInf") = CDate(dsRecord.Tables(0).Rows(i)("cFecInf"))
            Next
            dvRecord = New DataView(dsRecord.Tables(0))
            dvRecord.Sort = "dFecInf Desc"
            dsReporte.Tables.Add(dvRecord.ToTable)

            If Not dsReporte Is Nothing Then
                intCantidad = dsReporte.Tables(0).Rows.Count
                If intCantidad > 0 Then
                    Me.divContenido.Visible = True
                    strNombre = CheckStr(dsRecord.Tables(0).Rows(0)("cNomCon"))
                    If strNombre.Trim = "" And strDNI <> "" Then
                        dsReniec = oBLL.BuscarReniecSiat(ConfigurationManager.AppSettings("CadenaConexionReniec"), strDNI)
                        If dsReniec.Tables(0).Rows.Count > 0 Then
                            strNombre = CheckStr(dsReniec.Tables(0).Rows(0)("SP_APP")) + " " + CheckStr(dsReniec.Tables(0).Rows(0)("SP_APM")) + " " + CheckStr(dsReniec.Tables(0).Rows(0)("SP_NOM"))
                        End If
                    End If
                    Me.lblConductor.Text = "CONDUCTOR: " + strNombre.ToUpper
                    Me.grdRecord.DataSource = dsReporte.Tables(0)
                    Me.grdRecord.DataBind()
                Else
                    Me.divContenido.Visible = False
                    lblMensajeVacio.Text = "No se encontraron registros."
                End If
            End If
            oBLL = Nothing
            dsRecord = Nothing
            dsReporte = Nothing
        Else
            lblMensajeVacio.Text = strMensaje
        End If
        lblFecha.Text = "Informe actualizado al " + vstrFecCal

    End Sub

    Private Function ValidaCampos(ByVal vTipoDoc As String) As String
        If vTipoDoc = "1" Then
            If txtLicencia.Text = "" Then
                Return "Ingrese el n�mero de Licencia."
            End If
        End If
        Return ""
    End Function

    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Protected Sub CaptchaContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptchaContinue.Click
        GestionarConsulta()
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    '''<summary>M�todo para validar el c�digo captcha.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCaptha() As Boolean
        Dim blnRespuesta As Boolean
        If Session("CaptchaImageText") IsNot Nothing AndAlso txtCaptcha.Text.ToLower() = Session("CaptchaImageText").ToString().ToLower() Then
            blnRespuesta = True
            Me.fecConsulta.Visible = True
        Else
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
            Me.fecConsulta.Visible = False
        End If
        Return blnRespuesta
    End Function

    '''<summary>M�todo para ejecutar las consultas en base al tipo de consulta.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Sub GestionarConsulta()
        If (Me.hidTipConsulta.Value = "busqLicencia") Then
            If fbln_ValidarCaptha() Then
                Me.txtDNI.Text = ""
                BuscarLicencia(1)
            Else
                Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If

        If (Me.hidTipConsulta.Value = "busqDNI") Then
            If fbln_ValidarCaptha() Then
                Me.txtLicencia.Text = ""
                BuscarLicencia(2)
            Else
                Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If

    End Sub

   

End Class
