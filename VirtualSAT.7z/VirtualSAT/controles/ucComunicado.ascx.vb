
Partial Class controles_ucComunicado
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.lblComunicado.Text = (Resources.Parametros.strComunicado)
    End Sub
End Class
