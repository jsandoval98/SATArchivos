Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL
Imports System.IO

Partial Class CarritoPagosPagar
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Pagar()
        End If
    End Sub

    Private Sub Pagar()
        Dim dsCarrito As DataSet = GetCarrito()
        Dim strCampos(15) As String
        Dim strFilas() As String
        Dim strDetalle As String = ""
        Dim dblTotalWeb As Double = 0
        Dim dblTotalSiat As Double = 0
        Dim strCodPer As String = ""
        Dim intCantidad As Integer = 0
        Dim i As Integer
        Dim dtPagos As New DataTable
        Dim oBLL As ConsultasVarias
        Dim oBLLPagos As New ConsultasWeb
        Dim strCuotaUnica As String = ""
        Dim strDocumento As String
        Dim dblMontoWeb, dblMontoSiat As Double
        Dim strDiferencias As String = ""

        'detalle=detalle & numdoc & "|" & codtrib & "|" & ano & "|" & periodo & "|" & datosimp & "|" & n_cuota & "|" & n_emisio & "|" & n_reajus & "|" & n_mora & "|" & n_importe & "|" & n_reinci & "|" & n_gasadm & "|" & n_costas & "|" & n_descuento & "|" & n_totpag & "|" & formdere
        If Not dsCarrito Is Nothing Then
            If dsCarrito.Tables.Count = 0 Then
                Exit Sub
            End If
            oBLL = New ConsultasVarias
            dtPagos = oBLL.BuscarDetalleCuentaCte(GetConexionSiatTributosLinea, GetMuniID, dsCarrito.Tables(0), GetFecha)
            intCantidad = dtPagos.Rows.Count
            If intCantidad > 0 Then
                For i = 0 To dtPagos.Rows.Count - 1
                    With dtPagos.Rows(i)
                        strDocumento = CheckStr(.Item("documento")).Replace(".", "")
                        strCampos(0) = strDocumento
                        strCampos(1) = CheckStr(.Item("sicodcre"))
                        strCampos(2) = CheckStr(.Item("anio"))
                        strCampos(3) = CheckStr(.Item("periodo"))
                        strCampos(4) = CheckStr(.Item("referencia"))
                        strCampos(5) = CheckStr(.Item("ncuota"))
                        strCampos(6) = CheckStr(.Item("emision"))
                        strCampos(7) = CheckStr(.Item("reajuste"))
                        strCampos(8) = CheckStr(.Item("mora"))
                        strCampos(9) = CheckStr(.Item("importe"))
                        strCampos(10) = CheckStr(.Item("reinci"))
                        strCampos(11) = CheckStr(.Item("gastos"))
                        strCampos(12) = CheckStr(.Item("costas"))
                        strCampos(13) = CheckStr(.Item("descuento"))
                        strCampos(14) = CheckStr(.Item("monto"))
                        strCodPer = CheckStr(.Item("icodper"))
                        dblMontoWeb = Math.Round(CheckDbl(.Item("monto")), 2)
                        If strCampos(1) = "200" Then
                            dblMontoSiat = Math.Round(CheckDbl(.Item("montosiat")) - CheckDbl(.Item("descuento")), 2)
                        Else
                            dblMontoSiat = Math.Round(CheckDbl(.Item("montosiat")), 2)
                        End If
                        dblTotalWeb += Math.Round(dblMontoWeb, 2)
                        dblTotalSiat += Math.Round(dblMontoSiat, 2)
                        If dblMontoWeb <> dblMontoSiat Then
                            strDiferencias += strDocumento + ";"
                        End If
                    End With
                    Array.Resize(strFilas, i + 1)
                    strFilas(i) = String.Join("|", strCampos)
                    'registrar la cuota unica
                    strCuotaUnica = CheckStr(dtPagos.Rows(i)("cuotaunica"))
                    If strCuotaUnica <> "" Then
                        oBLLPagos.PagosVirtualesRegistrarCuotaUnica(GetConexionPagosVirtuales, strDocumento, strCuotaUnica, "")
                    End If
                Next
                strDetalle = String.Join("@", strFilas)
            End If
        End If
        strDetalle = strDetalle.Replace("'", "")
        strDetalle = strDetalle.Replace("&", "")
        strDetalle = strDetalle.Replace("?", "")
        oBLLPagos = Nothing
        oBLL = Nothing
        If dblTotalWeb > 0 And Math.Round(dblTotalWeb, 2) = Math.Round(dblTotalSiat, 2) Then
            dsCarrito.Tables(0).Clear()
            SalvarCarrito(dsCarrito)
            Response.Redirect(BuscarMensaje("pagina_pagos_virtuales") + "?" + SetURL("mysession", MySessionID) + "+&forpago=0&ccontri=" + strCodPer + "&items=" + intCantidad.ToString + "&monto=" + dblTotalWeb.ToString("#0.00") + "&detalle=" + strDetalle + "&cod=" + GetCodigoRegistroUsuario.ToString() + "&" + SetURL("per", GetCodigoUsuario()))
            'Response.Write(BuscarMensaje("pagina_pagos_virtuales") + "?forpago=0&ccontri=" + strCodPer + "&items=" + intCantidad.ToString + "&monto=" + dblTotal.ToString("#0.00") + "&detalle=" + strDetalle + "&cod=216125")
        Else
            'mensaje error
            Dim oFile As New StreamWriter(GetRutaFisica("../app_data/") + "ErrorCarritoSuma.txt", True)
            oFile.WriteLine("-----------------------" + Date.Now.ToString + "-------------------")
            oFile.WriteLine("Cod  :" + strCodPer.ToString)
            oFile.WriteLine("Web  :" + dblTotalWeb.ToString)
            oFile.WriteLine("Siat :" + dblTotalSiat.ToString)
            oFile.WriteLine("Dif  :" + strDiferencias)
            Me.lblMensajeServer.Text = "Ha ocurrido un error al procesar el pedido, favor de reintentar mas tarde."
            oFile.Close()
        End If
    End Sub

End Class
