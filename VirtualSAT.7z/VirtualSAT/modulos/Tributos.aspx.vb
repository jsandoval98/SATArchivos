Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb

Partial Class Tributos
    Inherits PageBase

    Private mintCodigoUsuario As Integer

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'mintCodigoUsuario = FuncionesWeb.GetCodigoUsuario
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        CargarAnios(Me.ddlAnio)
        Buscar(Date.Today.Year)
    End Sub

    Private Sub Buscar(Optional ByVal vintAnio As Integer = 0)
        Dim oBLL As New ConsultasVarias
        Dim ds As DataSet
        ds = oBLL.BuscarEstadoCuenta(GetConexionSiatTributos, mintCodigoUsuario, GetConceptoReca, vintAnio, 0, 0, 0, Date.Today.ToShortDateString)
        If Not ds Is Nothing Then
            Me.grdEstadoCuenta.DataSource = ds.Tables(0)
            Me.grdEstadoCuenta.DataBind()
        End If
        oBLL = Nothing
    End Sub

    Protected Sub btnBuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnBuscar.Click
        If IsNumeric(Me.ddlAnio.SelectedValue) Then
            Buscar(Integer.Parse(Me.ddlAnio.SelectedValue))
        End If
    End Sub

End Class
