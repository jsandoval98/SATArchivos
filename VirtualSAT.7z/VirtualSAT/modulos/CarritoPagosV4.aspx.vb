Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones

Partial Class modulos_CarritoPagosV4
    Inherits PageBase

    Private mintCodigoUsuario As Integer = 0

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ValidarPagina()
        mintCodigoUsuario = FuncionesWeb.GetCodigoBuscado
        Me.lblPagadas.Text = ""
        If Not IsPostBack Then
            Inicio2()
            pInicio()
        End If

    End Sub

    Private Sub Inicio2()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing
    End Sub

    Public Function PaginaPagar() As String
        Dim strURL As String = BuscarMensaje("pagina_carrito_procesa") + "?" + SetUrlLibre("mysession", MySessionID)
        Return strURL + "&" + SetUrlLibre("tri", GetUrlLibre("tri"))
    End Function

    Public Function PaginaPagarHtml() As String
        Dim strPagina As String = PaginaPagar()
        strPagina = System.Web.HttpUtility.HtmlEncode(strPagina)
        Return strPagina
    End Function

    Public Function PaginaVerPagos() As String
        Return GetNombrePagina(Paginas.VerPagos, SetURL("cod", ""))
    End Function

    Private Sub pInicio()        
        Dim ds As DataSet
        Me.lblTitulo.Text = "1 - Carrito de pagos"
        Dim i As Integer = 0
        Dim strDocumento As String = ""
        Dim oBLL As New ConsultasWeb
        Dim dsPagos As DataSet
        Dim bolPagado As Boolean = False

        ds = GetCarrito()

        If ds.Tables.Count > 0 Then
            While ds.Tables(0).Rows.Count > i
                strDocumento = CheckStr(ds.Tables(0).Rows(i)("documento"))
                strDocumento = strDocumento.Replace(".", "")
                dsPagos = oBLL.BuscarDocumentoPagadoWeb(GetConexionSoporteWEB, strDocumento)
                If dsPagos.Tables(0).Rows.Count > 0 Then
                    EliminarCuentaCarrito(strDocumento)
                    Me.lblPagadas.Text += strDocumento + "."
                End If
                i += 1
            End While
        End If

        If GetEstadoDescuentoArbitrios2008(Date.Today.Year) Then
            ProcesarDescuentoArbitrios()
        End If

        ds = GetCarrito()

        If Me.lblPagadas.Text <> "" Then Me.lblPagadas.Text = "Las siguientes cuentas ya estan siendo pagadas en otra operaci�n o estan bloquedas: " + Me.lblPagadas.Text

        Me.grdCarrito.DataSource = ds.Tables(0)
        Me.grdCarrito.DataBind()

        pCargarAniosCombo()
        pValidarUsuarioSesion()   '<<<<<<<<<<<<<<<<<<<
        MostrarTotales()
        oBLL = Nothing

    End Sub

    Private Sub pCargarAniosCombo()
        'Dim intAnio As Integer = Date.Today.Year
        'Dim i As Integer
        'For i = intAnio To intAnio + 10
        '   Me.ddlAnioTarjeta.Items.Add(i.ToString)
        'Next
    End Sub

    Private Sub MostrarTotales()
        Dim arrCarrito As ArrayList

        arrCarrito = GetDatosCarrito()

        Me.btnPagar.Disabled = True

        If Not arrCarrito Is Nothing Then
            Me.lblMonto.Text = Format(arrCarrito(1).ToString, "{0:#,#0.00}")
            Dim dblMonto As Double
            If Double.TryParse(Me.lblMonto.Text, dblMonto) = True Then
                If dblMonto > 0 Then
                    Me.btnPagar.Disabled = False
                Else
                    pOcultarTodo()
                End If
            Else
                pOcultarTodo()
            End If
        Else
            pOcultarTodo()
        End If

    End Sub

    Protected Sub grdCarrito_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdCarrito.RowDeleting
        Dim strDocumento As String = CType(Me.grdCarrito.Rows(e.RowIndex).FindControl("lblDocumento"), Label).Text
        EliminarCuentaCarrito(strDocumento)
        pInicio()
    End Sub

    Public Sub EliminarCuentaCarrito(ByVal vstrDocumento As String)
        Dim ds As DataSet = GetCarrito()
        Dim i As Integer
        If ds.Tables.Count > 0 Then
            For i = 0 To ds.Tables(0).Rows.Count - 1
                If CheckStr(vstrDocumento).Replace(".", "") = CheckStr(ds.Tables(0).Rows(i)("documento")).Replace(".", "") Then
                    ds.Tables(0).Rows(i).Delete()
                    Exit For
                End If
            Next
        End If
        ds.AcceptChanges()
        SalvarCarrito(ds)
    End Sub

    Private Sub MensajeAlerta(ByVal vstrMensaje As String)
        Dim strScript As String = "<script language=JavaScript>"
        vstrMensaje = vstrMensaje.Replace(".", "\n")
        strScript += "alert(""" & vstrMensaje & """);"
        strScript += "</script>"
        ClientScript.RegisterStartupScript(Type.GetType("System.String"), "MensajeAlerta", strScript)
    End Sub

    Protected Sub btnRegresar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegresar.Click
        Select Case GetConceptoReca()
            Case 145, 146, 200
                Redireccionar(Paginas.EstadoCuentaTributario, SetUrlLibre("tri", GetUrlLibre("tri")))
            Case -1
                Redireccionar(Paginas.Papeletas, SetUrlLibre("tri", GetUrlLibre("tri")))
        End Select
    End Sub

    Private Sub ProcesarDescuentoArbitrios()
        Dim dsCarrito As DataSet
        'predios para cuota unica
        Dim arrPredios As New ArrayList
        Dim strCodPre, strCodPreAnt As String
        Dim strCodPer As String
        Dim dvTemp As DataView
        Dim arrAux() As String
        Dim intAnio As Integer
        Dim strDocumento As String = ""
        Dim i As Integer
        Dim intCodCre As Integer

        dsCarrito = GetCarrito()

        strCodPreAnt = ""

        For i = 0 To dsCarrito.Tables(0).Rows.Count - 1
            strCodPre = CheckStr(dsCarrito.Tables(0).Rows(i)("icodPre"))
            strCodPer = CheckStr(dsCarrito.Tables(0).Rows(i)("icodPer"))
            intCodCre = CheckInt(dsCarrito.Tables(0).Rows(i)("siCodCre"))
            intAnio = CheckInt(dsCarrito.Tables(0).Rows(i)("anio"))
            strDocumento = CheckStr(dsCarrito.Tables(0).Rows(i)("documento"))

            strDocumento = strDocumento.Replace(".", "")
            '-------------- consulta de predios
            If strCodPre + "/" + strCodPer + "/" + intAnio.ToString <> strCodPreAnt And GetEstadoDescuentoArbitrios2008(intAnio) And intCodCre = 200 Then
                arrPredios.Add(strCodPre + "/" + strCodPer + "/" + intAnio.ToString)
                strCodPreAnt = strCodPre + "/" + strCodPer + "/" + intAnio.ToString
            End If
            '-------------- consulta de predios
        Next

        Dim k As Integer
        Dim nDescuento As Double = 0
        Dim strValores(8) As String
        Dim strAnio As String
        Dim dsCuentas As DataSet
        Dim oBLLTrib As New ConsultasWeb
        Dim strCuotaUnica As String = ""
        Dim strDocAux As String = ""
        Dim intEncontrados As Integer = 0
        Dim intItemEncontrado As Integer = 0
        Dim strBusqueda(1) As Object
        Dim dr As DataRow
        Dim dblTotalDescuento As Double = 0

        For i = 0 To arrPredios.Count - 1
            strCodPre = CStr(arrPredios(i))
            arrAux = Strings.Split(strCodPre, "/")
            strCodPre = arrAux(0)
            strCodPer = arrAux(1)
            strAnio = arrAux(2)

            strValores(0) = "1"
            strValores(1) = strCodPer
            strValores(2) = "200"
            strValores(3) = strCodPre
            strValores(4) = ""
            strValores(5) = strAnio
            strValores(6) = "999"
            strValores(7) = Date.Today.ToShortDateString
            strValores(8) = "1"

            dsCuentas = oBLLTrib.DeudaConsultarDeudaDocumentos1(GetConexionSiatTributos, strValores)
            If dsCuentas.Tables(0).Rows.Count > 0 Then
                strCuotaUnica = CheckStr(dsCuentas.Tables(0).Rows(0)("CuotaUnica"))
            End If
            If strCuotaUnica <> "" Then
                intEncontrados = 0
                For k = 0 To dsCuentas.Tables(0).Rows.Count - 1
                    strDocAux = CheckStr(dsCuentas.Tables(0).Rows(k)("cNumDoc"))
                    dr = dsCarrito.Tables(0).Rows.Find(strDocAux)
                    If Not dr Is Nothing Then
                        intEncontrados += 1
                        dr("descuento") = 0
                        dr("monto") = CheckDbl(dsCuentas.Tables(0).Rows(k)("nSaldo")) + CheckDbl(dsCuentas.Tables(0).Rows(k)("nMorDif"))
                        dr("cuotaunica") = ""
                        dr.AcceptChanges()
                    End If
                Next
                dsCarrito.AcceptChanges()

                dvTemp = New DataView(dsCarrito.Tables(0))
                dvTemp.RowFilter = " anio = " + strAnio + " And iCodPre=" + strCodPre + " And icodper = " + strCodPer

                If intEncontrados >= 4 And dvTemp.Count = intEncontrados Then
                    For k = 0 To dsCuentas.Tables(0).Rows.Count - 1
                        strDocAux = CheckStr(dsCuentas.Tables(0).Rows(k)("cNumDoc"))
                        dr = dsCarrito.Tables(0).Rows.Find(strDocAux)
                        If Not dr Is Nothing Then
                            nDescuento = Math.Round(CheckDbl(dsCuentas.Tables(0).Rows(k)("ncuota")) * 0.05, 2)
                            dblTotalDescuento += nDescuento
                            intEncontrados += 1
                            dr("descuento") = Math.Round(nDescuento, 2)
                            dr("monto") = Math.Round(CheckDbl(dr("monto")) - nDescuento, 2)
                            dr("cuotaunica") = strCuotaUnica
                            dr.AcceptChanges()
                        End If
                    Next
                End If
            End If
        Next

        dsCarrito.AcceptChanges()
        SalvarCarrito(dsCarrito)

        If dblTotalDescuento > 0 Then
            Me.lblDescuento.Text = "Total de descuento Arbitrios : S/. " + dblTotalDescuento.ToString("#,#0.00")
        End If

        dsCarrito = Nothing
        dsCuentas = Nothing
        oBLLTrib = Nothing

    End Sub

    Protected Function pValidarCorreoSospechoso(ByVal sCorreo As String) As Integer
        Dim validaOK As Integer = 0
        Dim dsUsuario As New DataSet
        Dim strCorreo As String
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")

        If txtEmailLogin.Text = "" Then
            strCorreo = CStr(Session.Item("email"))
        Else
            strCorreo = ValidaCorreo(Me.txtEmailLogin.Text)
        End If

        Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb

            dsUsuario = oBLL.ConsultarCorreoSospechoso(GetConexionPagosVirtuales, strCorreo)

            If dsUsuario.Tables(0).Rows.Count > 0 Then

                validaOK = 1
            End If

        End Using

        dsUsuario = Nothing

        Return validaOK

    End Function

    Private Sub pLogin()
        Dim strUsuario As String = ValidaCorreo(Me.txtEmailLogin.Text)
        Dim strClave As String = Me.txtClave.Text.Trim
        Dim ds As DataSet
        Dim strEstadoRegistro As String
        Dim bolOK As Boolean = False
        Dim strMensaje As String = ""
        Dim strPass As String = ""
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")

        If strUsuario = "" Or strClave = "" Then
            strMensaje = "Ingrese su correo y clave."
            Me.lblMensajeLogin.Text = strMensaje
            Exit Sub
        End If

        'Validar correo sospechoso

        If pValidarCorreoSospechoso(strUsuario) = 1 Then
            Me.lblMensajeSospechoso.Text = "Mensaje: El correo " + strUsuario + " se encuentra en observaci�n por el operador de la tarjeta. "
            Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
            btnPagar.Visible = False
            pOcultarTodo()
            lblMensajeSospechoso.Visible = True
            Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
            Exit Sub
        Else
            Using oBLL As New ConsultasWeb
                ds = oBLL.BuscarUsuarioWEB(GetConexionSoporteWEB, 0, strUsuario, "")
                If ds.Tables(0).Rows.Count > 0 Then
                    strEstadoRegistro = CheckStr(ds.Tables(0).Rows(0)("vEstPer"))
                    strPass = CheckStr(ds.Tables(0).Rows(0)("vPasswd"))
                    Select Case strEstadoRegistro
                        Case "1"
                            If ValidarClave(strClave, strPass) Then
                                bolOK = True
                            Else
                                strMensaje = "Clave incorrecta."
                            End If
                        Case "0"
                            strMensaje = "Su usuario(correo) no ha sido confirmado, en estos momentos se le esta enviado un correo para confirmar la propiedad del correo."
                        Case Else

                    End Select
                Else
                    strMensaje = "Correo no registrado: " + strUsuario
                End If

            End Using

            If bolOK Then
                pMostrarDatosUsuario(ds.Tables(0))
                pMuestraOcultaDivs(False)
            Else
                Me.lblMensajeLogin.Text = strMensaje
            End If

            ds = Nothing
        End If

    End Sub

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        pLogin()
    End Sub

    Protected Sub lnkMostrarLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkMostrarLogin.Click
        pMuestraOcultaDivs(True)
    End Sub

    Private Sub pValidarUsuarioSesion()
        Dim intCodUsuWeb As Integer = GetCodigoRegistroUsuario()
        Dim dsUsuario As DataSet
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")

        If intCodUsuWeb <= 1 Then
            pMuestraOcultaDivs(True)
        Else
            Using oBLL As New ConsultasWeb
                dsUsuario = oBLL.BuscarUsuarioWEB(GetConexionSoporteWEB, intCodUsuWeb, "", "")
                If dsUsuario.Tables(0).Rows.Count > 0 Then
                    pMostrarDatosUsuario(dsUsuario.Tables(0))
                    pMuestraOcultaDivs(False)

                    Dim strCorreo As String = CStr(Session.Item("email"))

                    If pValidarCorreoSospechoso(strCorreo) = 1 Then
                        Me.lblMensajeSospechoso.Text = "Mensaje: El correo " + strCorreo + " se encuentra en observaci�n por el operador de la tarjeta."
                        Me.lblMensajeLogin.ForeColor = Drawing.Color.Red
                        btnPagar.Visible = False
                        pOcultarTodo()
                        lblMensajeSospechoso.Visible = True
                        Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End If

                End If

            End Using
        End If
    End Sub

    Private Sub pCambiaTipoTarjeta(ByVal vstrTipoTarjeta As String)
        Select Case vstrTipoTarjeta
            Case "0"
                Me.divTarjeta.Style.Item("visibility") = "hidden"
            Case "1"
                Me.divTarjeta.Style.Item("visibility") = "hidden"
            Case "2"
                Me.divTarjeta.Style.Item("visibility") = ""
        End Select

    End Sub

    Private Sub pMostrarDatosUsuario(ByVal vdtUsuario As DataTable)
        Dim strNombreCompleto As String = ""
        Dim intCodUsu As Integer = 0

        If vdtUsuario.Rows.Count > 0 Then
            strNombreCompleto = CheckStr(vdtUsuario.Rows(0)("vNombres")).ToUpper
            Me.lblNombreUsuario.Text = strNombreCompleto
            Me.lblDocumento.Text = CheckStr(vdtUsuario.Rows(0)("vNroDoc")).ToUpper
            Me.lblCorreo.Text = CheckStr(vdtUsuario.Rows(0)("vEmail")).ToLower
            Me.hidEmailServer.Value = CheckStr(vdtUsuario.Rows(0)("vEmail")).ToLower
            intCodUsu = CheckInt(vdtUsuario.Rows(0)("nCodUsu"))
            Me.hidUsuServer.Value = intCodUsu.ToString
            Session.Item("email") = Me.lblCorreo.Text
            Session.Item("ncodusu") = intCodUsu.ToString
        End If

    End Sub

    Private Sub pEnviarCorreoNuevoUsuario(ByVal vdtUsuario As DataTable)
        Dim strNombreCompleto As String = ""
        Dim strMensaje As String = ""
        Dim strClave As String = ""
        Dim strUsuario As String = ""
        Dim strEmail As String = ""

        If vdtUsuario.Rows.Count > 0 Then
            strNombreCompleto = CheckStr(vdtUsuario.Rows(0)("vNombres")).ToUpper
            strEmail = CheckStr(vdtUsuario.Rows(0)("vEmail")).ToLower
            strClave = CheckStr(vdtUsuario.Rows(0)("vPasswd"))
            strClave = DesencriptaNet(strClave)

            strMensaje = strMensaje & "Gracias por registrarse como usuario de SAT Virtual. " & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Esta es la informacion de la cuenta:" & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Nombre  : " & strNombreCompleto & Chr(13)
            strMensaje = strMensaje & "Usuario : " & strEmail & Chr(13)
            strMensaje = strMensaje & "Clave   : " & strClave & Chr(13) & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Atentamente," & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Servicio de Administracion Tributaria" & Chr(13) & Chr(13)
            strMensaje = strMensaje & "PD: Las tildes y enies se han omitido para evitar problemas de compatibilidad entre los software de correo electronico"

            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                oBLL.EnviarCorreoTexto(GetConexionSoporteWEB, "SAT de Lima <satvirtual@sat.gob.pe>", strEmail, "Servicio de Consultas y/o Pagos en Linea - SAT", strMensaje)
            End Using

        End If

    End Sub

    Private Sub pEnviarCorreoConfirmarCorreo(ByVal vdtUsuario As DataTable)
        Dim strNombreCompleto As String = ""
        Dim strMensaje As String = ""
        Dim strClave As String = ""
        Dim strUsuario As String = ""
        Dim strEmail As String = ""
        Dim strCadenaSecreta As String = ""

        If vdtUsuario.Rows.Count > 0 Then
            strCadenaSecreta = CheckStr(vdtUsuario.Rows(0)("NCODUSU")) & "R" & CheckStr(vdtUsuario.Rows(0)("VNRODOC"))
            strNombreCompleto = CheckStr(vdtUsuario.Rows(0)("vNombres")).ToUpper
            strEmail = CheckStr(vdtUsuario.Rows(0)("vEmail")).ToLower
            strClave = CheckStr(vdtUsuario.Rows(0)("vPasswd"))
            strClave = DesencriptaNet(strClave)

            strMensaje = strMensaje & "Gracias por registrarse como usuario de SAT Virtual. " & Chr(13) & Chr(13)
            strMensaje = strMensaje & "A fin de concluir con el proceso de registro en SAT Virtual, visite el siguiente enlace " & Chr(13) & Chr(13)
            strMensaje = strMensaje & "(Si tienes problemas con el codigo de seguridad, por favor copia directamente el link en tu navegador y recarga la pagina) : " & Chr(13)
            If Request.ServerVariables("SERVER_NAME") = "satwebdesa" Then
                strMensaje = strMensaje & "http://satwebdesa/website/rgcon.asp?c=" & strCadenaSecreta + Chr(13) & Chr(13)
            ElseIf Request.ServerVariables("SERVER_NAME") = "satwebpre" Then
                strMensaje = strMensaje & "http://satwebpre/website/rgcon.asp?c=" & strCadenaSecreta + Chr(13) & Chr(13)
            ElseIf Request.ServerVariables("SERVER_NAME") = "localhost" Then
                strMensaje = strMensaje & "http://localhost/website/rgcon.asp?c=" & strCadenaSecreta + Chr(13) & Chr(13)
            Else
                strMensaje = strMensaje & "http://www.sat.gob.pe/website/rgcon.asp?c=" & strCadenaSecreta + Chr(13) & Chr(13)
            End If
            strMensaje = strMensaje & "Esta es la informacion de la cuenta:" & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Usuario : " & strEmail & Chr(13)
            strMensaje = strMensaje & "Clave   : " & strClave & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Atentamente," & Chr(13) & Chr(13)
            strMensaje = strMensaje & "Servicio de Administracion Tributaria" & Chr(13) & Chr(13)

            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                oBLL.EnviarCorreoTexto(GetConexionSoporteWEB, "SAT de Lima <satvirtual@sat.gob.pe>", strEmail, "Servicio de Consultas y/o Pagos en Linea - SAT", strMensaje)
            End Using

        End If

    End Sub

    Private Sub pMuestraOcultaDivs(ByVal vbolEstado As Boolean)
        Me.divAuteticaDatos.Visible = vbolEstado
        Me.divAutenticaTexto.Visible = Not vbolEstado
        Me.divFormaPago.Visible = Not vbolEstado
    End Sub

    Private Sub pOcultarTodo()
        Me.divAuteticaDatos.Visible = False
        Me.divAutenticaTexto.Visible = False
        Me.divFormaPago.Visible = False
    End Sub

    Shared Function ValidaCorreo(ByVal vstrCadena As String) As String
        If vstrCadena Is Nothing Or vstrCadena Is DBNull.Value Then
            Return ""
        End If
        vstrCadena = vstrCadena.Replace("'", "")
        vstrCadena = vstrCadena.Replace("--", "")
        vstrCadena = vstrCadena.Replace("&", "")
        vstrCadena = vstrCadena.Replace("""", "")
        vstrCadena = vstrCadena.Replace("%", "")
        vstrCadena = vstrCadena.Replace("#", "")
        Return vstrCadena.Trim
    End Function









End Class
