Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL

Partial Class modulos_CarritoPagos
   Inherits PageBase

   Private mintCodigoUsuario As Integer = 0

   Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      ValidarPagina()
      mintCodigoUsuario = FuncionesWeb.GetCodigoBuscado
      Me.lblPagadas.Text = ""
      If Not IsPostBack Then
         Inicio()
      End If
   End Sub

   Public Function PaginaPagar() As String
      Return GetNombrePagina(Paginas.CarritoPagar, SetUrlLibre("tri", GetUrlLibre("tri")))
   End Function

   Public Function PaginaVerPagos() As String
      Return GetNombrePagina(Paginas.VerPagos, SetURL("cod", ""))
   End Function

   Private Sub Inicio()
      Dim ds As DataSet
      Me.lblTitulo.Text = "CARRITO DE PAGOS"
      Dim i As Integer = 0
      Dim strDocumento As String = ""
      Dim oBLL As New ConsultasWeb
      Dim dsPagos As DataSet
      Dim bolPagado As Boolean = False

      ds = GetCarrito()

      If ds.Tables.Count > 0 Then
         While ds.Tables(0).Rows.Count > i
            strDocumento = CheckStr(ds.Tables(0).Rows(i)("documento"))
            strDocumento = strDocumento.Replace(".", "")
            dsPagos = oBLL.BuscarDocumentoPagadoWeb(GetConexionSoporteWEB, strDocumento)
            If dsPagos.Tables(0).Rows.Count > 0 Then
               EliminarCuentaCarrito(strDocumento)
               Me.lblPagadas.Text += strDocumento + "."
            End If
            i += 1
         End While
      End If

      ProcesarDescuentoArbitrios()

      ds = GetCarrito()

      If Me.lblPagadas.Text <> "" Then Me.lblPagadas.Text = " Cuentas: " + Me.lblPagadas.Text
      Me.grdCarrito.DataSource = ds.Tables(0)
      Me.grdCarrito.DataBind()

      MostrarTotales()

   End Sub

   Private Sub MostrarTotales()
      Dim arrCarrito As ArrayList

      arrCarrito = GetDatosCarrito()
      'deshabilitado por defecto
      Me.btnPagar.Disabled = True

      If Not arrCarrito Is Nothing Then
         Me.lblMonto.Text = Format(arrCarrito(1).ToString, "{0:#,#0.00}")
         Dim dblMonto As Double
         If Double.TryParse(Me.lblMonto.Text, dblMonto) = True Then
            If dblMonto > 0 Then
               Me.btnPagar.Disabled = False
            End If
         End If
      End If

   End Sub

   Protected Sub grdCarrito_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdCarrito.RowDeleting
      Dim strDocumento As String = CType(Me.grdCarrito.Rows(e.RowIndex).FindControl("lblDocumento"), Label).Text
      EliminarCuentaCarrito(strDocumento)
      Inicio()
   End Sub

   Public Sub EliminarCuentaCarrito(ByVal vstrDocumento As String)
      Dim ds As DataSet = GetCarrito()
      Dim i As Integer
      If ds.Tables.Count > 0 Then
         For i = 0 To ds.Tables(0).Rows.Count - 1
            If CheckStr(vstrDocumento).Replace(".", "") = CheckStr(ds.Tables(0).Rows(i)("documento")).Replace(".", "") Then
               ds.Tables(0).Rows(i).Delete()
               Exit For
            End If
         Next
      End If
      ds.AcceptChanges()
      SalvarCarrito(ds)
   End Sub

   Private Sub MensajeAlerta(ByVal vstrMensaje As String)
      Dim strScript As String = "<script language=JavaScript>"
      vstrMensaje = vstrMensaje.Replace(".", "\n")
      strScript += "alert(""" & vstrMensaje & """);"
      strScript += "</script>"
      ClientScript.RegisterStartupScript(Type.GetType("System.String"), "MensajeAlerta", strScript)
   End Sub

   Protected Sub btnRegresar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegresar.Click
      Select Case GetConceptoReca()
         Case 145, 146, 200
            Redireccionar(Paginas.EstadoCuentaTributario, SetUrlLibre("tri", GetUrlLibre("tri")))
         Case -1
            Redireccionar(Paginas.Papeletas, SetUrlLibre("tri", GetUrlLibre("tri")))
      End Select
   End Sub

   Private Sub ProcesarDescuentoArbitrios()
      Dim dsCarrito As DataSet
      'predios para cuota unica
      Dim arrPredios As New ArrayList
      Dim strCodPre, strCodPreAnt As String
      Dim strCodPer As String
      Dim dvTemp As DataView
      Dim arrAux() As String
      Dim intAnio As Integer
      Dim strDocumento As String = ""
      Dim i As Integer
      Dim intCodCre As Integer
      'Dim dvArbitrios As DataView

      dsCarrito = GetCarrito()
      'dvArbitrios = New DataView(dsCarrito.Tables(0))
      'dvArbitrios.RowFilter = "siCodCre = 200"

      strCodPreAnt = ""

      For i = 0 To dsCarrito.Tables(0).Rows.Count - 1
         strCodPre = CheckStr(dsCarrito.Tables(0).Rows(i)("icodPre"))
         strCodPer = CheckStr(dsCarrito.Tables(0).Rows(i)("icodPer"))
         intCodCre = CheckInt(dsCarrito.Tables(0).Rows(i)("siCodCre"))
         intAnio = CheckInt(dsCarrito.Tables(0).Rows(i)("anio"))
         strDocumento = CheckStr(dsCarrito.Tables(0).Rows(i)("documento"))

         strDocumento = strDocumento.Replace(".", "")
         '-------------- consulta de predios
         If strCodPre + "/" + strCodPer + "/" + intAnio.ToString <> strCodPreAnt And GetEstadoDescuentoArbitrios2008(intAnio) And intCodCre = 200 Then
            arrPredios.Add(strCodPre + "/" + strCodPer + "/" + intAnio.ToString)
            strCodPreAnt = strCodPre + "/" + strCodPer + "/" + intAnio.ToString
         End If
         '-------------- consulta de predios
      Next

      Dim k As Integer
      Dim nDescuento As Double = 0
      Dim strValores(8) As String
      Dim strAnio As String
      Dim dsCuentas As DataSet
      Dim oBLLTrib As New ConsultasWeb
      Dim strCuotaUnica As String = ""
      Dim strDocAux As String = ""
      Dim intEncontrados As Integer = 0
      Dim intItemEncontrado As Integer = 0
      Dim strBusqueda(1) As Object
      Dim dr As DataRow
      Dim dblTotalDescuento As Double = 0

      For i = 0 To arrPredios.Count - 1
         strCodPre = CStr(arrPredios(i))
         arrAux = Strings.Split(strCodPre, "/")
         strCodPre = arrAux(0)
         strCodPer = arrAux(1)
         strAnio = arrAux(2)

         strValores(0) = "1"
         strValores(1) = strCodPer
         strValores(2) = "200"
         strValores(3) = strCodPre
         strValores(4) = ""
         strValores(5) = strAnio
         strValores(6) = "999"
         strValores(7) = Date.Today.ToShortDateString
         strValores(8) = "1"

         dsCuentas = oBLLTrib.DeudaConsultarDeudaDocumentos1(GetConexionSiatTributos, strValores)
         If dsCuentas.Tables(0).Rows.Count > 0 Then
            strCuotaUnica = CheckStr(dsCuentas.Tables(0).Rows(0)("CuotaUnica"))
         End If
         If strCuotaUnica <> "" Then
            intEncontrados = 0
            For k = 0 To dsCuentas.Tables(0).Rows.Count - 1
               strDocAux = CheckStr(dsCuentas.Tables(0).Rows(k)("cNumDoc"))
               dr = dsCarrito.Tables(0).Rows.Find(strDocAux)
               If Not dr Is Nothing Then
                  intEncontrados += 1
                  dr("descuento") = 0
                  dr("monto") = CheckDbl(dsCuentas.Tables(0).Rows(k)("nSaldo")) + CheckDbl(dsCuentas.Tables(0).Rows(k)("nMorDif"))
                  dr("cuotaunica") = ""
                  dr.AcceptChanges()
               End If
            Next
            dsCarrito.AcceptChanges()

            dvTemp = New DataView(dsCarrito.Tables(0))
            dvTemp.RowFilter = " anio = " + strAnio + " And iCodPre=" + strCodPre + " And icodper = " + strCodPer

            If intEncontrados >= 4 And dvTemp.Count = intEncontrados Then
               For k = 0 To dsCuentas.Tables(0).Rows.Count - 1
                  strDocAux = CheckStr(dsCuentas.Tables(0).Rows(k)("cNumDoc"))
                  dr = dsCarrito.Tables(0).Rows.Find(strDocAux)
                  If Not dr Is Nothing Then
                     nDescuento = Math.Round(CheckDbl(dsCuentas.Tables(0).Rows(k)("ncuota")) * 0.05, 2)
                     dblTotalDescuento += nDescuento
                     intEncontrados += 1
                     dr("descuento") = Math.Round(nDescuento, 2)
                     dr("monto") = Math.Round(CheckDbl(dr("monto")) - nDescuento, 2)
                     dr("cuotaunica") = strCuotaUnica
                     dr.AcceptChanges()
                  End If
               Next
            End If
         End If
      Next

      dsCarrito.AcceptChanges()
      SalvarCarrito(dsCarrito)

      If dblTotalDescuento > 0 Then
         Me.lblDescuento.Text = "Total de descuento Arbitrios : S/. " + dblTotalDescuento.ToString("#,#0.00")
      End If

      dsCarrito = Nothing
      dsCuentas = Nothing
      oBLLTrib = Nothing

   End Sub


End Class
