Imports FuncionesWeb

Partial Class Inicio
    Inherits PageBase

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()

    End Sub

End Class
