Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports SAT.HomeSiteBLL
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports System.Text
Imports System.Collections.Generic

Partial Class modulos_TributosResumen
   Inherits System.Web.UI.Page

   Private mintCodigoUsuario As Integer
   Private mintCodVeh As Integer = 0
   Private helper As GridViewHelper
   Private mQuantities As List(Of Int32)

   Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      ValidarPagina()
      ValidarCodigoBuscado()
      mintCodigoUsuario = FuncionesWeb.GetCodigoBuscado

      If Not IsPostBack Then
         Inicio()
         RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
      End If
      VerificarEstadoPagos()
   End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        Me.lblTitulo.Text = GetConceptoDescripcion().ToUpper
        Me.lblAdministrado.Text = mintCodigoUsuario.ToString + " - " + GetAdministradoBuscado()
        Me.lblFechaSistema.Text = "Fecha de consulta: " + GetFecha()
        Session("administrado") = Me.lblAdministrado.Text

        If rbtMostrar.SelectedIndex = -1 Then
            rbtMostrar.SelectedIndex = 0
        End If
        Filtrar()

    End Sub

   Private Sub Filtrar()

      helper = New GridViewHelper(grdEstadoCuenta, True)

      Select Case Me.rbtMostrar.SelectedValue
         Case "1"
            's�lo por tributo
            helper.SetSuppressGroup("TRIBUTO")
            helper.RegisterSummary("Saldo", SummaryOperation.Sum, "TRIBUTO")
            helper.HideColumnsWithoutGroupSummary()
            helper.RegisterSummary("Saldo", SummaryOperation.Sum)
            helper.ApplyGroupSort()
            Buscar()
         Case "2"
            's�lo por a�o
            helper.SetSuppressGroup("A�O")
            helper.RegisterSummary("Saldo", SummaryOperation.Sum, "A�O")
            helper.HideColumnsWithoutGroupSummary()
            helper.RegisterSummary("Saldo", SummaryOperation.Sum)
            helper.ApplyGroupSort()
            Buscar("2")

         Case "3"
            'detalle por tributo
            Dim g As GridViewGroup = helper.RegisterGroup("TRIBUTO", True, True)
            helper.RegisterSummary("Saldo", SummaryOperation.Sum, "TRIBUTO")
            helper.ApplyGroupSort()
            Buscar()
         Case "4"
            'detalle por a�o
            Dim g As GridViewGroup = helper.RegisterGroup("A�O", True, True)
            helper.RegisterSummary("Saldo", SummaryOperation.Sum, "A�O")
            helper.ApplyGroupSort()
            Buscar("2")
      End Select

   End Sub

   Private Sub helper_GroupSummary(ByVal groupName As String, ByVal values As Object(), ByVal row As GridViewRow)
      row.Cells(0).HorizontalAlign = HorizontalAlign.Right
      row.Cells(0).Text = "Total"
      row.BackColor = Drawing.Color.FromArgb(236, 236, 236)
   End Sub

   Private Sub helper_GroupHeader(ByVal groupName As String, ByVal values As Object(), ByVal row As GridViewRow)

      If groupName = "TRIBUTO" Then
         row.BackColor = Drawing.Color.LightCyan
         row.Cells(0).Text = "&nbsp;&nbsp;" + row.Cells(0).Text
      ElseIf groupName = "A�O" Then
         row.BackColor = Drawing.Color.FromArgb(236, 236, 236)
         row.Cells(0).Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + row.Cells(0).Text
      End If

   End Sub

   Private Sub VerificarEstadoPagos()
      If GetEstadoPagos() Then
         Me.grdEstadoCuenta.Columns(0).Visible = True
      Else
         Me.grdEstadoCuenta.Columns(0).Visible = False
      End If
   End Sub

   Public Function CampoBeneficio() As Boolean
      Dim bolEstado As Boolean = False
      If GetEstadoBeneficio(1900) Then
         bolEstado = True
      End If
      Return bolEstado
   End Function

   Public Function GetAdministrado() As String
      Return Me.lblAdministrado.Text
   End Function

   Private Sub Buscar(Optional ByVal vstrOrden As String = "1")
      Dim oBLL As New ConsultasVarias
      Dim ds As DataSet
      Dim intAnio As Integer = 0
      Dim intEstado As Integer = 0
      Dim intCantidad As Integer
      Dim bolRef As Boolean = False
      Dim bolBeneficio As Boolean = False
      Dim dblTotalDeudaSin As Double = 0
      Dim dblTotalDeudaCon As Double = 0
      Dim strFileTemp As String = ""
      Dim strReferenciaBusqueda As String = ""
      Dim intConcepto As Integer = 0
      Dim dv As DataView

      Me.lblCantidadRegistros.Text = ""
      intEstado = 1
      bolBeneficio = CampoBeneficio()
      VerificarEstadoPagos()
      MostrarOcultarDivPagos(False)

      '************ Validar Pricos *************
      'If BuscarPrico(GetConexionSiatTributos, mintCodigoUsuario, GetConceptoReca) Then
      '    If mintCodVeh = 0 Then
      '        Me.lblMensajePrico.Text = "Por su condici�n de Principal Contribuyente, le pedimos comunicarse con su sectorista para obtener su estado de cuenta."
      '        Exit Sub
      '    End If
      'End If
      '*****************************************

      strFileTemp = GetRutaFisica("temp/") + Date.Today.ToString("ddMMyyyy") + _
                     "_" + GetSessionID.ToString + _
                     "_" + intConcepto.ToString + _
                     "_" + intAnio.ToString + _
                     "_" + intEstado.ToString + _
                     "_" + mintCodigoUsuario.ToString

      If IO.File.Exists(strFileTemp + ".xml") Then
         'desde file salvado
         ds = New DataSet
         ds.ReadXml(strFileTemp + ".xml")
      Else
         'desde base de datos            
         ds = oBLL.BuscarEstadoCuenta(GetConexionSiatTributos, _
                                       mintCodigoUsuario, _
                                       intConcepto, _
                                       intAnio, 0, _
                                       intEstado, 0, _
                                       Date.Today.ToShortDateString, , _
                                       mintCodVeh, , _
                                       "T1W", False)

         ds.WriteXml(strFileTemp + ".xml", XmlWriteMode.WriteSchema)
      End If

      'para la impresion
      Me.hidUrlPrint.Value = "TributosImprimir.aspx?ses=" + GetSessionID.ToString + _
                             "&con=" + intConcepto.ToString + _
                             "&ani=" + intAnio.ToString + _
                             "&est=" + intEstado.ToString + _
                             "&usu=" + mintCodigoUsuario.ToString

      intCantidad = 0
      Dim strOrden As String
      If Not ds Is Nothing Then
         If ds.Tables(0).Rows.Count > 0 Then
            dv = New DataView(ds.Tables(0))
            If vstrOrden = "1" Then
               strOrden = "TRIBUTO, A�O, PERIODO"
            Else
               strOrden = "A�O, TRIBUTO, PERIODO"
            End If
            dv.Sort = strOrden
            dv.RowFilter = "periodo <> 0"
            Me.grdEstadoCuenta.DataSource = dv
            Me.grdEstadoCuenta.DataBind()
            Me.grdEstadoCuenta.Visible = True

            Dim strMensaje As New StringBuilder
            Me.lblCantidadRegistros.Text = strMensaje.ToString
            MostrarOcultarDivPagos(True)

         Else
            Me.grdEstadoCuenta.Visible = False
            Me.lblMensajeSinDatos.Text = "<br>" + BuscarMensaje("estado_cuenta_sin_datos")
         End If
      End If
      oBLL = Nothing
      ds = Nothing
   End Sub

   Private Sub MostrarOcultarDivPagos(ByVal vbolMostrar As Boolean)
      Me.divPagos.Visible = vbolMostrar
      If GetEstadoPagos() = False Then
         Me.divPagos.Visible = False
      End If
   End Sub

   Protected Sub grdEstadoCuenta_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdEstadoCuenta.RowDataBound
      If e.Row.RowType = DataControlRowType.DataRow Then
         'ProcesarFilaDataGrid(e)
      End If
   End Sub

   Protected Sub grdEstadoCuenta_Sorting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSortEventArgs) Handles grdEstadoCuenta.Sorting

   End Sub

   Protected Sub rbtMostrar_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles rbtMostrar.SelectedIndexChanged
      Filtrar()
   End Sub

   Protected Sub btnNuevaBusqueda_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNuevaBusqueda.Click
      SetCodigoBuscado("")
      Redireccionar(Paginas.BuscadorTributos, SetUrlLibre("tri", GetUrlLibre("tri")))
   End Sub

End Class
