﻿Option Explicit On
Option Strict On
Imports FuncionesWeb
Imports System.Data
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Imports SAT.SIAT.COM.BLL.Libreria.NX.Sms_Ip

Partial Class modulos_pitazo_Default
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    End Sub
    Protected Sub btnIniciar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnIniciar.Click
        Dim strTipo As String = CheckStr(Convert.ToString(Me.hdnfldtxtTipoDocumento.Value))
        Select Case strTipo
            Case "C" ' CELULAR
                pValidarRegistroUsuarioCelular()
            Case "E" ' EMAIL
                pValidarRegistroUsuarioEmail()
        End Select
    End Sub
    Private Sub pValidarRegistroUsuarioEmail()
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim dsUsuarioDoc As New DataSet
        Dim dsUsuario As New DataSet
        Dim strCodUsuario As String = ""
        Dim intCodUsuario As Integer = 0
        Dim strEstadoUsuario As String = ""
        Dim blnEstadoCelular As Boolean = False
        Dim strDocumento As String = CheckStr(Convert.ToString(Me.hdnfldtxtDocumento.Value))
        Dim strEmail As String = CheckStr(Convert.ToString(Me.hdnfldtxtEmail.Value))
        Dim strScript As String = ""
        Dim strMensaje As String = ""
        Dim strRuta As String = ""
        Try
            ' Realiza la búsqueda del usuario por número de documento

            dsUsuarioDoc = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, "", "", strDocumento)

            If SAT.Base.Lib.Datos.RowCount(dsUsuarioDoc) > 0 Then
                Try
                    ' Realiza la búsqueda del usuario por correo

                    dsUsuario = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, strEmail, "", strDocumento)

                    If SAT.Base.Lib.Datos.RowCount(dsUsuario) > 0 Then
                        With dsUsuario.Tables(0).Rows(0)
                            strEstadoUsuario = CheckStr(.Item("vEstPer"))
                            If IsNumeric(.Item("bConfirmacionSMS")) Then
                                blnEstadoCelular = SAT.Base.Lib.Datos.CheckBln(.Item("bConfirmacionSMS"))
                            End If
                            intCodUsuario = CheckInt(.Item("nCodUsu"))
                            strCodUsuario = Convert.ToString(CheckInt(.Item("nCodUsu")))
                        End With

                        Select Case strEstadoUsuario
                            Case "0" ' No se encuentra activo el usuario
                                'strMensaje = "El e-mail no se encuentra activo"
                                'strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                                'Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
                                strRuta = "CorreoConfirmacion.aspx?" + SetURL("codigo", strCodUsuario)
                                Response.Redirect(strRuta, False)
                            Case "1" ' Usuario Activo
                                pMostrarPlacaVehiculos(strCodUsuario)
                            Case Else
                        End Select
                    Else 'Si el email no se encuentra registrado
                        strMensaje = "El e-mail no se encuentra registrado"
                        strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
                    End If
                Catch ex As Exception
                    SAT.Base.Web.App.Errores.Registrar(Me, ex)
                Finally
                    If Not (dsUsuario Is Nothing) Then dsUsuario.Dispose()
                    dsUsuario = Nothing
                End Try
            Else 'Si el número de documento no se encuentra registrado
                strMensaje = "El documento no se encuentra registrado"
                strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (dsUsuario Is Nothing) Then dsUsuario.Dispose()
            dsUsuario = Nothing
        End Try

    End Sub
    Private Sub pValidarRegistroUsuarioCelular()
        Dim dsUsuarioDoc As New DataSet
        Dim dsUsuario As New DataSet
        Dim dsCelular As New DataSet
        Dim strCodUsuario As String = ""
        Dim intCodUsuario As Integer = 0
        Dim strEstadoUsuario As String = ""
        Dim blnEstadoCelular As Boolean = False
        Dim strCelular As String = Convert.ToString(Me.hdnfldtxtCelular.Value)
        Dim strDocumento As String = Convert.ToString(Me.hdnfldtxtDocumento.Value)
        Dim strScript As String = ""
        Dim strMensaje As String = ""
        Dim strMensajeCel As String = ""
        Dim strFecEnv As String = ""
        Dim blnEnviado As Boolean = False
        Dim strClaveCelular As String = ""
        Dim respuesta As String = ""
        Dim strRuta As String = ""

        Try
            ' Realiza la búsqueda del usuario por número de documento
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                dsUsuarioDoc = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, "", "", strDocumento)
            End Using
            If SAT.Base.Lib.Datos.RowCount(dsUsuarioDoc) > 0 Then
                Try
                    ' Realiza la búsqueda del usuario por número de celular
                    Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                        dsUsuario = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, "", strCelular, strDocumento)
                    End Using
                    ' Verifica que el número de celular se encuentre registrado
                    If SAT.Base.Lib.Datos.RowCount(dsUsuario) > 0 Then
                        With dsUsuario.Tables(0).Rows(0)
                            strEstadoUsuario = CheckStr(.Item("vEstPer"))
                            strFecEnv = SAT.Base.Lib.Datos.CheckStr(.Item("sdFechaEnvioMensaje"))
                            blnEstadoCelular = SAT.Base.Lib.Datos.CheckBln(.Item("bConfirmacionSMS"))
                            strClaveCelular = SAT.Base.Lib.Datos.CheckStr(.Item("cPasswordConfirmacion"))
                            strCodUsuario = Convert.ToString(CheckInt(.Item("nCodUsu")))
                            intCodUsuario = CheckInt(.Item("nCodUsu"))
                        End With
                        ' Verifica que exista suscripción por celular, 
                        ' Si no existe fecha de envío no hubo suscripción por número de celular
                        If String.IsNullOrEmpty(strFecEnv) Then
                            strMensaje = "El celular no se encuentra activo"
                            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
                        Else
                            ' Verifica que el celular se encuentre confirmado
                            If blnEstadoCelular Then
                                pMostrarPlacaVehiculos(strCodUsuario)
                            Else
                                'strMensaje = "El celular no se encuentra activo"
                                'strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                                'Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
                                strRuta = "CodigoConfirmacion.aspx?" + SetURL("codigo", strCodUsuario)
                                Response.Redirect(strRuta, False)
                            End If
                        End If
                    Else
                        strMensaje = "El celular no se encuentra registrado"
                        strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
                    End If
                Catch ex As Exception
                    SAT.Base.Web.App.Errores.Registrar(Me, ex)
                Finally
                    If Not (dsUsuario Is Nothing) Then dsUsuario.Dispose()
                    dsUsuario = Nothing
                End Try
            Else 'Si el número de documento no se encuentra registrado
                strMensaje = "El documento no se encuentra registrado"
                strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validacion", strScript)
            End If


        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (dsUsuario Is Nothing) Then dsUsuario.Dispose()
            dsUsuario = Nothing
        End Try


    End Sub
    Private Sub pMostrarPlacaVehiculos(ByVal strCodUsuario As String)
        Dim strRuta As String = ""
        strRuta = "PlacasContactos.aspx?" + SetURL("codigo", strCodUsuario)
        Response.Redirect(strRuta, False)

    End Sub
End Class