$(document).on("ready",init);
function init(){

    var confirmacion = $('#confirmacion');
    confirmacion.css({ 
        'left': ($(window).width() / 2 - $(confirmacion).width() / 2) + 'px',
        'top': ($(window).height() / 2 - $(confirmacion).height() / 2) + 'px'       
    });	

	$(".quitar-placa").click(mostrarPopup);
	$(".overlay").click(ocultarPopup);
	
	function mostrarPopup(){
	    $('.overlay').fadeIn(); 
		$('#confirmacion').fadeIn(); 
	}
	function ocultarPopup(){
	    $('.overlay').fadeOut(); 
		$('#confirmacion').fadeOut(); 
	}
	
	// Escape para cerrar
    $(document).keyup(function(event){
    if(event.which==27)
        {
           $('.overlay').fadeOut(); 
		   $('#confirmacion').fadeOut(); 
        }
    });

}
