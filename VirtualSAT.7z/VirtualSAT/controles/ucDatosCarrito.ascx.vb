Option Explicit On
Option Strict On

Imports FuncionesCarrito
Imports FuncionesWeb
Imports System.Data
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL

Public Class controles_ucDatosCarrito
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Refrescar()
    End Sub

    Public Sub Refrescar()
        Dim arrCarrito As ArrayList
        Dim dblMonto As Double = 0
        ProcesarDescuentoArbitrios()
        arrCarrito = GetDatosCarrito()
        Me.lnkCarrito.Enabled = False
        If Not arrCarrito Is Nothing Then
            Me.valCantidad.Value = arrCarrito(0).ToString
            If IsNumeric(arrCarrito(1).ToString) Then
                dblMonto = Double.Parse(arrCarrito(1).ToString)
                If dblMonto > 0 Then
                    Me.lnkCarrito.Enabled = True
                End If
            End If
        End If
        Me.valMonto.Value = "S/. " + Format(dblMonto, "#0.00")
    End Sub

    Protected Sub lnkCarrito_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lnkCarrito.Click
        Dim strURL As String = BuscarMensaje("pagina_carrito_inicio") + "?" + SetUrlLibre("mysession", MySessionID)
        Response.Redirect(strURL + "&" + SetUrlLibre("tri", GetUrlLibre("tri")))
    End Sub

    Private Sub ProcesarDescuentoArbitrios()
        Dim dsCarrito As DataSet
        'predios para cuota unica
        Dim arrPredios As New ArrayList
        Dim strCodPre, strCodPreAnt As String
        Dim strCodPer As String
        Dim dvTemp As DataView
        Dim arrAux() As String
        Dim intAnio As Integer
        Dim strDocumento As String = ""
        Dim i As Integer
        Dim intCodCre As Integer

        dsCarrito = GetCarrito()

        If dsCarrito.Tables.Count = 0 Then
            Exit Sub
        End If

        strCodPreAnt = ""

        For i = 0 To dsCarrito.Tables(0).Rows.Count - 1
            strCodPre = CheckStr(dsCarrito.Tables(0).Rows(i)("icodPre"))
            strCodPer = CheckStr(dsCarrito.Tables(0).Rows(i)("icodPer"))
            intCodCre = CheckInt(dsCarrito.Tables(0).Rows(i)("siCodCre"))
            intAnio = CheckInt(dsCarrito.Tables(0).Rows(i)("anio"))
            strDocumento = CheckStr(dsCarrito.Tables(0).Rows(i)("documento"))

            strDocumento = strDocumento.Replace(".", "")
            '-------------- consulta de predios
            If strCodPre + "/" + strCodPer + "/" + intAnio.ToString <> strCodPreAnt And GetEstadoDescuentoArbitrios2008(intAnio) And intCodCre = 200 Then
                arrPredios.Add(strCodPre + "/" + strCodPer + "/" + intAnio.ToString)
                strCodPreAnt = strCodPre + "/" + strCodPer + "/" + intAnio.ToString
            End If
            '-------------- consulta de predios
        Next

        Dim k As Integer
        Dim nDescuento As Double = 0
        Dim strValores(8) As String
        Dim strAnio As String
        Dim dsCuentas As DataSet
        Dim oBLLTrib As New ConsultasWeb
        Dim strCuotaUnica As String = ""
        Dim strDocAux As String = ""
        Dim intEncontrados As Integer = 0
        Dim intItemEncontrado As Integer = 0
        Dim strBusqueda(1) As Object
        Dim dr As DataRow
        Dim dblTotalDescuento As Double = 0

        For i = 0 To arrPredios.Count - 1
            strCodPre = CStr(arrPredios(i))
            arrAux = Strings.Split(strCodPre, "/")
            strCodPre = arrAux(0)
            strCodPer = arrAux(1)
            strAnio = arrAux(2)

            strValores(0) = "1"
            strValores(1) = strCodPer
            strValores(2) = "200"
            strValores(3) = strCodPre
            strValores(4) = ""
            strValores(5) = strAnio
            strValores(6) = "999"
            strValores(7) = Date.Today.ToShortDateString
            strValores(8) = "1"

            dsCuentas = oBLLTrib.DeudaConsultarDeudaDocumentos1(GetConexionSiatTributos, strValores)
            If dsCuentas.Tables(0).Rows.Count > 0 Then
                strCuotaUnica = CheckStr(dsCuentas.Tables(0).Rows(0)("CuotaUnica"))
            End If
            If strCuotaUnica <> "" Then
                intEncontrados = 0
                For k = 0 To dsCuentas.Tables(0).Rows.Count - 1
                    strDocAux = CheckStr(dsCuentas.Tables(0).Rows(k)("cNumDoc"))
                    dr = dsCarrito.Tables(0).Rows.Find(strDocAux)
                    If Not dr Is Nothing Then
                        intEncontrados += 1
                        dr("descuento") = 0
                        dr("monto") = CheckDbl(dsCuentas.Tables(0).Rows(k)("nSaldo")) + CheckDbl(dsCuentas.Tables(0).Rows(k)("nMorDif"))
                        dr("cuotaunica") = ""
                        dr.AcceptChanges()
                    End If
                Next
                dsCarrito.AcceptChanges()

                dvTemp = New DataView(dsCarrito.Tables(0))
                dvTemp.RowFilter = " anio = " + strAnio + " And iCodPre=" + strCodPre + " And icodper = " + strCodPer

                If intEncontrados >= 4 And dvTemp.Count = intEncontrados Then
                    For k = 0 To dsCuentas.Tables(0).Rows.Count - 1
                        strDocAux = CheckStr(dsCuentas.Tables(0).Rows(k)("cNumDoc"))
                        dr = dsCarrito.Tables(0).Rows.Find(strDocAux)
                        If Not dr Is Nothing Then
                            nDescuento = Math.Round(CheckDbl(dsCuentas.Tables(0).Rows(k)("ncuota")) * 0.05, 2)
                            dblTotalDescuento += nDescuento
                            intEncontrados += 1
                            dr("descuento") = Math.Round(nDescuento, 2)
                            dr("monto") = Math.Round(CheckDbl(dr("monto")) - nDescuento, 2)
                            dr("cuotaunica") = strCuotaUnica
                            dr.AcceptChanges()
                        End If
                    Next
                End If
            End If
        Next
        dsCarrito.AcceptChanges()
        SalvarCarrito(dsCarrito)

        dsCarrito = Nothing
        dsCuentas = Nothing
        oBLLTrib = Nothing
    End Sub

End Class
