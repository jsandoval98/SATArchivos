Imports FuncionesWeb

Partial Class controles_cabecera
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.lblUsuario.Text = GetCodigoUsuario() + " |"
    End Sub
End Class
