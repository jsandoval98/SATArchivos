Option Explicit On
Option Strict On

Imports SAT.SeguridadSAT.Encriptacion
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports System.Web
Imports SAT.HomeSiteBLL
Imports System.Data.SqlClient

Public Class FuncionesWeb


#Region " Conexiones Base Datos "

    Public Shared Function GetConexionSoporteWEB() As String
        Return ConfigurationManager.AppSettings("con_homesite")
    End Function

    Public Shared Function GetConexionPagosVirtuales() As String
        Return ConfigurationManager.AppSettings("con_pagos_virtuales")
    End Function

    Public Shared Function GetConexionSiatTransito() As String
        Return ConfigurationManager.AppSettings("con_siattransito_replica")
    End Function

    Public Shared Function GetConexionSiatTransitoMovil() As String
        Return ConfigurationManager.AppSettings("con_siattransito_movil")
    End Function

    Public Shared Function GetConexionSiatTributos() As String
        Return ConfigurationManager.AppSettings("con_siattributos")
    End Function

    Public Shared Function GetConexionSiatTributosLinea() As String
        Return ConfigurationManager.AppSettings("con_siattributos")
    End Function

    Public Shared Function GetConexionSiatTransitoLinea() As String
        Return ConfigurationManager.AppSettings("con_siattransito")
    End Function

    Public Shared Function GetConexionUsuariosWeb() As String
        Return ConfigurationManager.AppSettings("UsuariosWeb")
    End Function

    Public Shared Function GetConexionSunarp() As String
        Return System.Configuration.ConfigurationManager.AppSettings("CadenaConexionSunarp")
    End Function

    Public Shared Function GetConexionSiatTransitoReplica() As String
        Return ConfigurationManager.AppSettings("con_siattransito_replica_directo")
    End Function

    Public Shared Function GetConexionConsultaPagos() As String
        Return ConfigurationManager.AppSettings("con_ConsultaPagos")
    End Function

    Public Shared Function GetConexionSiatReniec() As String
        Return System.Configuration.ConfigurationManager.AppSettings("conexion_siat_reniec")
    End Function


#End Region

#Region " MANEJO PAGINAS WEB "

    Public Enum Paginas
        Inicio = 1
        CarritoPagos = 4
        BuscadorTributos = 5
        EstadoCuentaTributario = 6
        CarritoPagar = 7
        Papeletas = 8
        VerPagos = 9
        TributarioResumen = 10
        Cargando = 11
        PapeletasEmail = 12
        Record = 13
        Capturas = 14
    End Enum

    Public Shared Function SetURL(ByVal vstrKey As String, ByVal vstrValor As String) As String
        vstrKey += "="
        vstrValor = Encrypt(vstrValor, GetCadenaEncript)
        vstrKey += Web.HttpUtility.UrlEncodeUnicode(vstrValor)
        Return vstrKey
    End Function

    Public Shared Function SetUrlLibre(ByVal vstrKey As String, ByVal vstrValor As String) As String
        vstrKey += "="
        vstrKey += Web.HttpUtility.UrlEncodeUnicode(vstrValor)
        Return vstrKey
    End Function

    Public Shared Function GetURL(ByVal vstrKey As String) As String
        Dim strValor As String = ""
        strValor = System.Web.HttpContext.Current.Request(vstrKey)
        If Not strValor Is Nothing Then
            'strValor = Web.HttpUtility.UrlDecode(strValor)
            strValor = Decrypt(strValor, GetCadenaEncript)
        End If
        Return strValor
    End Function

    Public Shared Function GetUrlLibre(ByVal vstrKey As String) As String
        Dim strValor As String = ""
        strValor = System.Web.HttpContext.Current.Request(vstrKey)
        If strValor Is Nothing Then
            strValor = ""
        End If
        Return strValor
    End Function

    Public Shared Function MySessionID() As String
        Dim strGet As String
        strGet = System.Web.HttpContext.Current.Request("mysession")
        If strGet Is Nothing Then
            strGet = ""
        End If
        'strGet = Web.HttpUtility.UrlEncodeUnicode(strGet)
        Return strGet
    End Function

    Public Shared Function MySessionIdURL() As String
        Return System.Web.HttpUtility.UrlEncodeUnicode(MySessionID)
    End Function

    Public Shared Function GetSessionID() As Integer
        Dim strCadenaValida As String
        Dim arrSession As String()
        Dim intCodPer As Integer = 0

        strCadenaValida = CheckStr(Decrypt(MySessionID(), GetCadenaEncript))
        arrSession = Split(strCadenaValida, "|")
        If arrSession.GetLength(0) > 1 Then
            If IsNumeric(arrSession(2)) Then
                intCodPer = CType(arrSession(2), Integer)
            End If
        End If
        strCadenaValida = Nothing
        arrSession = Nothing
        Return intCodPer
    End Function

    Public Shared Sub ValidarPagina()
        Dim strCodPer As String = GetCodigoUsuario()
        If strCodPer = "" Then
            Redireccionar(Paginas.Inicio, SetUrlLibre("tri", GetUrlLibre("tri")))
        End If
    End Sub

    Public Shared Function GetIPTerminal() As String
        Return System.Web.HttpContext.Current.Request.ServerVariables("REMOTE_ADDR")
    End Function

#End Region

#Region " SEGURIDAD "

    Public Shared Sub RegistroAccesoPagina(ByVal vstrConexionID As String, ByVal vstrURL As String)
        Dim oBLL As New ConsultasWeb
        Dim strValores(10) As String
        strValores(0) = System.Web.HttpContext.Current.Request.ServerVariables("REMOTE_ADDR")  '	@pVNUMIP
        strValores(1) = vstrURL '	@pVURL
        'strValores(2) = System.Web.HttpContext.Current.Request.ServerVariables("REMOTE_HOST") '	@pVHOST
        strValores(2) = Strings.Left(System.Web.HttpContext.Current.Request.QueryString.ToString, 200)
        strValores(3) = System.Web.HttpContext.Current.Request.ServerVariables("LOCAL_ADDR") '	@pVLOCAL
        strValores(4) = System.Web.HttpContext.Current.Request.ServerVariables("SERVER_NAME")  '	@pVSERVER
        strValores(5) = System.Web.HttpContext.Current.Request.ServerVariables("HTTP_USER_AGENT") '	@pVBROWSER
        strValores(6) = CheckStr(System.Web.HttpContext.Current.Request.ServerVariables("HTTP_UA_PIXELS")) '	@pVRESOLUCION
        strValores(7) = "" '	@pVVERFLASH
        strValores(8) = GetCodigoRegistroUsuario().ToString '	@pNCODUSU
        strValores(9) = "0" '	@pNCODPWE
        strValores(10) = "www.sat.gob.pe - " + System.Web.HttpContext.Current.Session.SessionID   '	@pVCODSESION
        oBLL.RegistroAccesoPagina(vstrConexionID, strValores)
        oBLL = Nothing
    End Sub

    Public Shared Function GetCadenaEncript() As String
        Return ConfigurationManager.AppSettings("strValorCadena")  ' Actived-test-kgc

        'Return Date.Today.ToShortDateString.Replace("/", "").Substring(0, 4) + System.Web.HttpContext.Current.Request.ServerVariables("REMOTE_HOST").Replace(".", "").Substring(0, 4) 'TODO RAP: DESCOMENTAR ' Comment-by-test-kgc


    End Function

    Private Shared Base64Chars As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    Public Shared Function EncriptaNet(ByVal strIn As String) As String
        Dim strOut As String = ""
        strIn = "SAT" + strIn
        Dim c1, c2, c3 As Integer
        Dim w1, w2, w3, w4, n As Integer

        For n = 1 To Len(strIn) Step 3
            c1 = Asc(Mid(strIn, n, 1))
            c2 = Asc(Mid(strIn, n + 1, 1) + Chr(0))
            c3 = Asc(Mid(strIn, n + 2, 1) + Chr(0))
            w1 = CInt(c1 / 4)
            w2 = CInt(c1 And 3) * 16 + CInt(c2 / 16)
            If Len(strIn) >= n + 1 Then
                w3 = (c2 And 15) * 4 + CInt(c3 / 64)
            Else
                w3 = -1
            End If
            If Len(strIn) >= n + 2 Then
                w4 = c3 And 63
            Else
                w4 = -1
            End If
            strOut = strOut + mimeencode(w1) + mimeencode(w2) + _
                mimeencode(w3) + mimeencode(w4)
        Next
        Return strOut

    End Function

    Private Shared Function mimeencode(ByVal intIn As Integer) As String
        If intIn >= 0 Then
            mimeencode = Mid(Base64Chars, intIn + 1, 1)
        Else
            mimeencode = ""
        End If
    End Function

    Public Shared Function DesencriptaNet(ByVal strIn As String) As String
        Dim strOut As String = ""
        Dim w1, w2, w3, w4, n As Integer
        Dim w5, w6 As Integer
        For n = 1 To Len(strIn) Step 4
            w1 = mimedecode(Mid(strIn, n, 1))
            w2 = mimedecode(Mid(strIn, n + 1, 1))
            w3 = mimedecode(Mid(strIn, n + 2, 1))
            w4 = mimedecode(Mid(strIn, n + 3, 1))
            w5 = Convert.ToInt32(w2 / 16)
            w6 = Convert.ToInt32(w3 / 4)
            If w2 >= 0 Then strOut = strOut + Chr(((w1 * 4 + w5) And 255))
            If w3 >= 0 Then strOut = strOut + Chr(((w2 * 16 + w6) And 255))
            If w4 >= 0 Then strOut = strOut + Chr(((w3 * 64 + w4) And 255))
        Next
        strOut = Mid(strOut, 4)
        Return strOut

    End Function

    Private Shared Function mimedecode(ByVal strIn As String) As Integer
        If Len(strIn) = 0 Then
            mimedecode = -1
            Exit Function
        Else
            mimedecode = InStr(Base64Chars, strIn) - 1
        End If
    End Function

    Public Shared Function ValidarClave(ByVal vstrClaveLibre As String, ByVal vstrClaveEncript As String) As Boolean
        Dim bolRepta As Boolean = False

        If vstrClaveLibre = DesencriptaNet(vstrClaveEncript) And vstrClaveLibre <> "" Then
            bolRepta = True
        End If

        Return bolRepta

    End Function

#End Region

#Region " VARIOS "


    Public Shared Sub RegistroDetalleBusqueda(ByVal vstrConexionID As String, _
                                            ByVal vstrReferencia As String, _
                                            ByVal vintCodPag As Integer, _
                                            ByVal vstrURL As String)
        Dim oBLL As New ConsultasWeb
        Dim strValores(4) As String
        strValores(0) = vstrReferencia  '	@@pVDOCREF
        strValores(1) = GetCodigoRegistroUsuario.ToString '	@pNCODUSU
        strValores(2) = vintCodPag.ToString '	@pNCODPWE
        strValores(3) = "www.sat.gob.pe - " + System.Web.HttpContext.Current.Request.ServerVariables("REMOTE_ADDR") + " - " + System.Web.HttpContext.Current.Session.SessionID '	@pVCODSESION
        strValores(4) = System.Web.HttpContext.Current.Request.ServerVariables("SERVER_NAME") + vstrURL  '	@pvURL
        oBLL.RegistroDetalleBusqueda(vstrConexionID, strValores)
        oBLL = Nothing
    End Sub

    Public Shared Sub SetCombo(ByVal vdtValores As DataTable, _
                    ByVal vstrColValores As String, _
                    ByVal vstrColTexto As String, _
                    ByRef ddlCombo As DropDownList, _
                    Optional ByVal vbolTexto As Boolean = True, _
                    Optional ByVal vstrMensaje As String = "")
        With ddlCombo
            .DataSource = vdtValores
            .DataValueField = vstrColValores
            .DataTextField = vstrColTexto
            .DataBind()
        End With
        If vstrMensaje = "" Then
            vstrMensaje = GetTextoSeleccione()
        End If
        If vbolTexto Then
            ddlCombo.Items.Insert(0, New ListItem(vstrMensaje, ""))
        End If
    End Sub

    Public Shared Sub SetCombo(ByVal vdtValores As DataTable, _
                        ByRef ddlCombo As DropDownList, _
                        Optional ByVal vbolPonerTexto As Boolean = True)
        With ddlCombo
            .DataSource = vdtValores
            .DataValueField = vdtValores.Columns(0).ColumnName
            .DataTextField = vdtValores.Columns(1).ColumnName
            .DataBind()
        End With
        If vbolPonerTexto Then
            ddlCombo.Items.Insert(0, New ListItem(GetTextoSeleccione, ""))
        End If
    End Sub

    Public Shared Function GetNombrePagina(ByVal vintPagina As Paginas, _
                                    Optional ByVal vstrParam As String = "", _
                                    Optional ByVal vstrEstado As String = "") As String

        Dim strPagina As String
        'nombre de la pagina
        Select Case vintPagina
            Case Paginas.Inicio
                strPagina = "~/bienvenida.aspx"
            Case Paginas.CarritoPagos
                strPagina = "CarritoPagos.aspx"
            Case Paginas.BuscadorTributos
                strPagina = "~/modulos/BusquedaTributario.aspx"
            Case Paginas.EstadoCuentaTributario
                strPagina = "TributosRef.aspx"
            Case Paginas.CarritoPagar
                strPagina = "CarritoPagosPagar.aspx"
            Case Paginas.Papeletas
                strPagina = "Papeletas.aspx"
            Case Paginas.VerPagos
                strPagina = "VerPagos.aspx"
            Case Paginas.TributarioResumen
                strPagina = "~/modulos/TributosResumen.aspx"
            Case Paginas.Cargando
                strPagina = "~/modulos/Cargando.aspx"
            Case Paginas.PapeletasEmail
                strPagina = "~/modulos/VerMisPlacas.aspx"
            Case Paginas.Record
                strPagina = "~/modulos/RecordConductor.aspx"
            Case Paginas.Capturas
                strPagina = "~/modulos/Capturas.aspx"
            Case Else
                strPagina = "Mensaje.aspx"
        End Select
        'setear session
        strPagina += "?mysession=" & MySessionIdURL()
        'para el estado
        If Not vstrEstado = "" Then
            strPagina += "&" + SetURL("est", vstrEstado)
        End If
        'parametros
        If vstrParam <> "" Then
            strPagina += "&" + vstrParam
        End If

        Return strPagina

    End Function

    Public Shared Function GetMuniID() As Integer
        Return 1
    End Function

    Public Shared Function GetFecha() As String
        Return Date.Today.ToShortDateString
    End Function

    Public Shared Function GetFechaLarga() As String
        Return Date.Today.ToShortDateString + " " + Date.Now.Hour.ToString + ":" + Date.Now.Minute.ToString + ":00"
    End Function

    Public Shared Sub SetComboSeleccionado(ByVal vstrVal As String, ByRef vobjDDL As DropDownList)
        If Not vobjDDL Is Nothing Then
            vobjDDL.ClearSelection()
            If Not vobjDDL.Items.FindByValue(vstrVal) Is Nothing Then
                vobjDDL.Items.FindByValue(vstrVal).Selected = True
            End If
        End If
    End Sub

    Public Shared Function GetEstadoPagos() As Boolean
        Dim bolPagos As Boolean = False
        Dim dtFecIniSinPagos As DateTime = Convert.ToDateTime(Resources.Parametros.strInicioSinPagos)
        Dim dtFecFinSinPagos As DateTime = Convert.ToDateTime(Resources.Parametros.strFinSinPagos)

        If IsNumeric(ConfigurationManager.AppSettings("intPermitirPagar")) Then
            If CInt(ConfigurationManager.AppSettings("intPermitirPagar")) = 1 And Not (Date.Now >= dtFecIniSinPagos And Date.Now <= dtFecFinSinPagos) Then
                bolPagos = True
            End If
        End If
        Return bolPagos
    End Function

    Public Shared Function GetEstadoPagosTransito() As Boolean
        Dim bolPagos As Boolean = False
        Dim dtFecIniSinPagos As DateTime = Convert.ToDateTime(Resources.Parametros.strInicioSinPagos)
        Dim dtFecFinSinPagos As DateTime = Convert.ToDateTime(Resources.Parametros.strFinSinPagos)
        If IsNumeric(ConfigurationManager.AppSettings("intPermitirPagarTransito")) Then
            If CInt(ConfigurationManager.AppSettings("intPermitirPagarTransito")) = 1 And Not (Date.Now >= dtFecIniSinPagos And Date.Now <= dtFecFinSinPagos) Then
                bolPagos = True
            End If
        End If
        Return bolPagos
    End Function

    Public Shared Function HabilitarCheckPago(ByVal vstrConcepto As String) As Boolean
        Dim strConceptos As String = CheckStr(ConfigurationManager.AppSettings("strConceptosPermitirPago"))
        Dim bolRepta As Boolean = False
        If strConceptos.Contains(vstrConcepto) Then
            bolRepta = True
        End If
        Return bolRepta
    End Function

    Public Shared Function MostrarTodosLosAnios(ByVal vstrConcepto As String) As Boolean
        Dim strConceptos As String = CheckStr(ConfigurationManager.AppSettings("strConceptosTodosLosAnios"))
        Dim bolRepta As Boolean = False
        If strConceptos.Contains(vstrConcepto) Then
            bolRepta = True
        End If
        Return bolRepta
    End Function

    Public Shared Function GetEstadoBeneficio(ByVal vintAnio As Integer) As Boolean
        Dim strFecIni, strFecFin As String
        Dim bolRepta As Boolean = False
        'si es menor 2007 retornar true
        'If vintAnio = 2007 Then Return False : Exit Function
        strFecIni = CheckStr(ConfigurationManager.AppSettings("strFechaBeneficioIni"))
        strFecFin = CheckStr(ConfigurationManager.AppSettings("strFechaBeneficioFin"))
        If IsDate(strFecIni) And IsDate(strFecFin) Then
            If CDate(strFecFin) >= CDate(Date.Today.ToShortDateString) And CDate(strFecIni) <= Date.Today Then
                bolRepta = True
            End If
        End If
        Return bolRepta
    End Function

    Public Shared Function GetEstadoBeneficio() As Boolean
        Dim strFecIni, strFecFin As String
        Dim bolRepta As Boolean = False
        'strFecIni = CheckStr(ConfigurationManager.AppSettings("strFechaBeneficioIni"))
        'strFecFin = CheckStr(ConfigurationManager.AppSettings("strFechaBeneficioFin"))
        'If IsDate(strFecIni) And IsDate(strFecFin) Then
        '    If CDate(strFecFin) >= CDate(Date.Today.ToShortDateString) And CDate(strFecIni) <= Date.Today Then
        '        bolRepta = True
        '    End If
        'End If
        Return bolRepta
    End Function

    Public Shared Function GetCodigoUsuario() As String
        Dim strCadenaValida As String
        Dim arrSession As String()
        Dim strUsuario As String = ""

        strCadenaValida = CheckStr(Decrypt(MySessionID(), GetCadenaEncript))
        arrSession = Split(strCadenaValida, "|")
        If arrSession.GetLength(0) > 0 Then
            strUsuario = arrSession(0)
        End If
        strCadenaValida = Nothing
        arrSession = Nothing
        Return strUsuario
    End Function

    Public Shared Function GetCodigoRegistroUsuario() As Integer
        Dim strCadenaValida As String
        Dim arrSession As String()
        Dim strUsuario As String = ""
        Dim intUsuario As Integer = 0
        strCadenaValida = CheckStr(Decrypt(MySessionID(), GetCadenaEncript))
        arrSession = Split(strCadenaValida, "|")
        If arrSession.GetLength(0) > 3 Then
            strUsuario = arrSession(3)
        End If
        If IsNumeric(strUsuario) Then
            intUsuario = CInt(strUsuario)
        End If
        strCadenaValida = Nothing
        arrSession = Nothing
        Return intUsuario
    End Function

    Public Shared Function GetTipBusqueda() As String
        Dim strCadenaValida As String
        Dim arrSession As String()
        Dim strTipBus As String = ""
        strCadenaValida = CheckStr(Decrypt(MySessionID(), GetCadenaEncript))
        arrSession = Split(strCadenaValida, "|")
        If arrSession.GetLength(0) > 4 Then
            strTipBus = arrSession(4)
        End If
        strCadenaValida = Nothing
        arrSession = Nothing
        Return strTipBus
    End Function

    Public Shared Function GetValBusqueda() As String
        Dim strCadenaValida As String
        Dim arrSession As String()
        Dim strValBus As String = ""
        strCadenaValida = CheckStr(Decrypt(MySessionID(), GetCadenaEncript))
        arrSession = Split(strCadenaValida, "|")
        If arrSession.GetLength(0) > 5 Then
            strValBus = arrSession(5).Trim
        End If
        strCadenaValida = Nothing
        arrSession = Nothing
        Return strValBus
    End Function

    Public Shared Function GetCodigoBuscado() As Integer
        Dim intCodPer As Integer = 0
        intCodPer = CheckInt(Web.HttpContext.Current.Session.Item("icodper_buscado"))
        Return intCodPer
    End Function

    Public Shared Function GetAdministradoBuscado() As String
        Dim strAdministrado As String = ""
        strAdministrado = CheckStr(Web.HttpContext.Current.Session.Item("vnombre_buscado"))
        Return strAdministrado
    End Function

    Public Shared Sub SetCodigoBuscado(ByVal vstrCodPer As String)
        Web.HttpContext.Current.Session.Item("icodper_buscado") = vstrCodPer
    End Sub

    Public Shared Sub SetAdministradoBuscado(ByVal vstrAdministrado As String)
        Web.HttpContext.Current.Session.Item("vnombre_buscado") = vstrAdministrado
    End Sub

    Public Shared Sub ValidarCodigoBuscado()
        Dim intCodPer As Integer = GetCodigoBuscado()
        If intCodPer <= 0 Then
            Redireccionar(Paginas.BuscadorTributos, SetUrlLibre("tri", GetUrlLibre("tri")))
        End If
    End Sub

    Public Shared Function GetConceptoReca() As Integer
        Dim strConcepto As String
        Dim intConcepto As Integer
        strConcepto = CheckStr(System.Web.HttpContext.Current.Request("tri"))
        Select Case strConcepto.ToUpper
            Case "P"
                intConcepto = 145
            Case "A"
                intConcepto = 200
            Case "V"
                intConcepto = 146
            Case "L"
                intConcepto = 110
            Case "M"
                intConcepto = 400
            Case "F"
                intConcepto = 820
            Case "B"
                intConcepto = 110
            Case Else
                intConcepto = -1
        End Select
        Return intConcepto
    End Function

    Public Shared Function GetConceptoDescripcion() As String
        Dim strConcepto, strRepta As String
        strConcepto = CheckStr(System.Web.HttpContext.Current.Request("tri"))
        Select Case strConcepto.ToUpper
            Case "P"
                strRepta = "Impuesto Predial"
            Case "A"
                strRepta = "Arbitrios"
            Case "V"
                strRepta = "Impuesto Vehicular"
            Case "L"
                strRepta = "Papeletas"
            Case "M"
                strRepta = "Multas Tributarias"
            Case "F"
                strRepta = "Fraccionamiento Tributario"
            Case "B"
                strRepta = "Alcabala"
            Case "T"
                strRepta = "Total Deuda por Tributos"
            Case Else
                strRepta = "No definido"
        End Select
        Return strRepta
    End Function

    Public Shared Function GetRutaFisica(ByVal vstrPath As String) As String
        Return Web.HttpContext.Current.Server.MapPath(vstrPath)
    End Function

    Public Shared Sub Redireccionar(ByVal vintPagina As Paginas, _
                             Optional ByVal vstrParam As String = "", _
                             Optional ByVal vstrEstado As String = "")
        Web.HttpContext.Current.Response.Redirect(GetNombrePagina(vintPagina, vstrParam, vstrEstado))
    End Sub

    Public Shared Function GetTextoSeleccione() As String
        Return "(Seleccione)"
    End Function

    Public Shared Sub CargarEstadoDocumento(ByRef vddlEstado As DropDownList)
        Dim dsAnios As New DataSet
        dsAnios.ReadXml(Web.HttpContext.Current.Request.MapPath("~/App_Data/") + "EstDocumento.xml")
        If Not dsAnios Is Nothing Then
            vddlEstado.DataSource = dsAnios.Tables(0)
            vddlEstado.DataTextField = "valor"
            vddlEstado.DataValueField = "id"
            vddlEstado.DataBind()
        End If
    End Sub

    Public Shared Sub CargarAnios(ByRef vddlAnios As DropDownList)
        Dim dsAnios As New DataSet
        dsAnios.ReadXml(Web.HttpContext.Current.Request.MapPath("~/App_Data/") + "Anios.xml")
        If Not dsAnios Is Nothing Then
            vddlAnios.DataSource = dsAnios.Tables(0)
            vddlAnios.DataTextField = "anno"
            vddlAnios.DataValueField = "anno"
            vddlAnios.DataBind()
        End If
    End Sub

    Public Shared Function BuscarMensaje(ByVal vstrCodMensaje As String) As String
        Dim dsMensajes As New DataSet
        Dim strRepta As String = ""
        Dim dv As DataView
        dsMensajes.ReadXml(Web.HttpContext.Current.Request.MapPath("~/App_Data/") + "MensajesSistema.xml")
        If Not dsMensajes Is Nothing Then
            dv = New DataView(dsMensajes.Tables(0))
            dv.RowFilter = "id='" + vstrCodMensaje + "'"
            If dv.Count > 0 Then
                strRepta = CheckStr(dv.Item(0).Item("valor"))
            End If
        End If
        Return strRepta
    End Function

    Public Shared Function GetEstructuraTablaReferencia() As DataTable
        Dim dt As New DataTable("dt_referencia")
        dt.Columns.Add(New DataColumn("id", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("referencia", Type.GetType("System.String")))
        Return dt
    End Function

    Public Shared Function GetEstadoDescuentoArbitrios2008(ByVal vintAnio As Integer) As Boolean
        Dim strFecIni, strFecFin As String
        Dim bolRepta As Boolean = False
        Dim intAnioDescuento As Integer = CInt(ConfigurationManager.AppSettings("intAnioDescuentoArbitrios"))

        strFecIni = CheckStr(ConfigurationManager.AppSettings("strFechaDescuentoIni"))
        strFecFin = CheckStr(ConfigurationManager.AppSettings("strFechaDescuentoFin"))
        If IsDate(strFecIni) And IsDate(strFecFin) Then
            If CDate(strFecFin) >= CDate(Date.Today.ToShortDateString) And CDate(strFecIni) <= Date.Today And vintAnio = intAnioDescuento Then
                bolRepta = True
            End If
        End If
        Return bolRepta

    End Function

    Public Shared Function BuscarPrico(ByVal vstrConexionID As String, ByVal vintCodPer As Integer, ByVal vintCodCre As Integer) As Boolean
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim bolOK As Boolean = False

        If vintCodCre = 200 Or vintCodCre = 146 Or vintCodCre = 0 Or vintCodCre = -1 Or vintCodCre = 400 Or vintCodCre = 145 Then
            ds = oBLL.BuscarPrico(vstrConexionID, vintCodPer)
            If ds.Tables(0).Rows.Count > 0 Then
                bolOK = True
            End If
        End If

        oBLL = Nothing

        Return bolOK
    End Function

    ''' <summary>M�todo para obtener el nombre de la pagina de error de la pasarela de pagos de la muni.</summary>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor>David Miranda P.</CreadoPor></item>
    ''' <item><FecCrea>10/06/2013</FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu></FecActu></item>
    ''' <item><Resp></Resp></item>
    ''' <item><Mot></Mot></item></list></remarks>
    Public Shared Function GetPaginaErrorMuni() As String
        Return ConfigurationManager.AppSettings("strPaginaErrorMuni")
    End Function

#End Region

#Region " DATASET "
    Public Shared Function GetNroRegistros(ByVal vdsDatos As DataSet, _
                                           Optional ByVal vintTabla As Integer = 0) As Integer
        Dim intNumReg As Integer = -1
        Using vdsDatos
            If Not (vdsDatos Is Nothing) Then
                If vdsDatos.Tables.Count >= 0 Then
                    intNumReg = vdsDatos.Tables(vintTabla).Rows.Count
                End If
            End If
        End Using
        Return intNumReg
    End Function
#End Region

#Region " DATATABLE "
    Public Shared Function GetNroRegistros(ByVal vdtDatos As DataTable) As Integer
        Dim intNumReg As Integer = -1
        Using vdtDatos
            If Not (vdtDatos Is Nothing) Then
                If vdtDatos.Rows.Count >= 0 Then
                    intNumReg = vdtDatos.Rows.Count
                End If
            End If
        End Using
        Return intNumReg
    End Function
#End Region

#Region " JAVA SCRIPT "
    ''' <summary>M�todo para registrar un bloque de c�digo Javascript en un p�gina.</summary>
    ''' <param name="pagWebForm">Nombre de p�gina web</param>
    ''' <param name="sbJavaScript">String Builder con el contenido del c�digo javascript</param>
    ''' <param name="strClientScript">Nombre del bloque de c�digo javascript</param>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor>David Miranda P.</CreadoPor></item>
    ''' <item><FecCrea>20/10/2009</FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu></FecActu></item>
    ''' <item><Resp></Resp></item>
    ''' <item><Mot></Mot></item></list></remarks>
    Public Shared Sub pJSClientScriptBlock(ByVal pagWebForm As Page, _
                                           ByVal sbJavaScript As StringBuilder, _
                                           Optional ByVal strClientScript As String = "ClientScript")
        Dim strBld As StringBuilder = sbJavaScript
        If pagWebForm.ClientScript.IsClientScriptBlockRegistered(strClientScript) = False Then
            pagWebForm.ClientScript.RegisterClientScriptBlock(GetType(String), strClientScript, strBld.ToString, True)
        End If
    End Sub

    ''' <summary>M�todo para registrar un bloque de c�digo Javascript en un p�gina.</summary>
    ''' <param name="pagWebForm">Nombre de p�gina web</param>
    ''' <param name="strJavaScript">C�digo javascript a registrar</param>
    ''' <param name="strClientScript">Nombre del bloque de c�digo javascript</param>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor>David Miranda P.</CreadoPor></item>
    ''' <item><FecCrea>20/10/2009</FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu></FecActu></item>
    ''' <item><Resp></Resp></item>
    ''' <item><Mot></Mot></item></list></remarks>
    Public Shared Sub pJSClientScriptBlock(ByVal pagWebForm As Page, _
                                           ByVal strJavaScript As String, _
                                           Optional ByVal strClientScript As String = "ClientScript")
        If pagWebForm.ClientScript.IsClientScriptBlockRegistered(strClientScript) = False Then
            pagWebForm.ClientScript.RegisterClientScriptBlock(GetType(String), strClientScript, strJavaScript, True)
        End If
    End Sub
#End Region

#Region "MOSTAR DATOS"
    Public Shared Function GetCodigoMunicipalidad() As Integer
        Dim intCodMunicipalidad As Integer
        intCodMunicipalidad = CheckInt(ConfigurationManager.AppSettings("CodigoMunicipalidad"))

        Return intCodMunicipalidad

    End Function

    Public Shared Function GetCodigoDeposito() As Integer
        Dim intCodDeposito As Integer
        intCodDeposito = CheckInt(ConfigurationManager.AppSettings("CodigoDeposito"))

        Return intCodDeposito

    End Function

    Public Shared Function GetTipoOperacion() As String
        Dim intTipoOperacion As String
        intTipoOperacion = CheckStr(ConfigurationManager.AppSettings("TipoOperacion"))

        Return intTipoOperacion

    End Function

    Public Shared Function GetGrua() As Integer
        Dim intGrua As Integer
        intGrua = CheckInt(ConfigurationManager.AppSettings("Grua"))

        Return intGrua

    End Function


    Public Shared Function GetTextoMTC() As String
        Dim intGrua As String
        intGrua = CheckStr(ConfigurationManager.AppSettings("TextoMTC"))

        Return intGrua

    End Function

#End Region

#Region "Mostra Fecha Corta"
    Public Shared Function GetFechaCorta() As String
        Dim strFecha As String
        strFecha = Date.Today.ToShortDateString
        Return strFecha
    End Function
#End Region

#Region "Formatear Monto"
    Public Shared Function fstr_FormatearMonto(ByVal vdblMonto As Double) As String
        Return vdblMonto.ToString("#,##0.00")
    End Function
#End Region

#Region "Mostar Datos Dep�sito"

#Region "C�digo de Dep�sito"

    Public Shared Function GetCodDepositoZarate() As Integer
        Dim intCodDepZarate As Integer
        intCodDepZarate = CheckInt(ConfigurationManager.AppSettings("CodDepZarate"))

        Return intCodDepZarate

    End Function

    Public Shared Function GetCodDepositoAte() As Integer
        Dim intCodDepAte As Integer
        intCodDepAte = CheckInt(ConfigurationManager.AppSettings("CodDepAte"))

        Return intCodDepAte

    End Function

    Public Shared Function GetCodDepositoSantaAnita() As Integer
        Dim intCodDepSantaAnita As Integer
        intCodDepSantaAnita = CheckInt(ConfigurationManager.AppSettings("CodDepSantaAnita"))

        Return intCodDepSantaAnita

    End Function

    Public Shared Function GetCodDepositoColonial() As Integer
        Dim intCodDepColonial As Integer
        intCodDepColonial = CheckInt(ConfigurationManager.AppSettings("CodDepColonial"))

        Return intCodDepColonial

    End Function
#End Region

#Region "Direcci�n de Dep�sito"
    Public Shared Function GetDireccionDepositoZarate() As String
        Dim intDirDepZarate As String
        intDirDepZarate = CheckStr(ConfigurationManager.AppSettings("DirDepZarate"))

        Return intDirDepZarate

    End Function

    Public Shared Function GetDireccionDepositoAte() As String
        Dim intDirDepAte As String
        intDirDepAte = CheckStr(ConfigurationManager.AppSettings("DirDepATE"))

        Return intDirDepAte

    End Function

    Public Shared Function GetDireccionDepositoSantaAnita() As String
        Dim intDirDepSantaAnita As String
        intDirDepSantaAnita = CheckStr(ConfigurationManager.AppSettings("DirDepSantaAnita"))

        Return intDirDepSantaAnita

    End Function

    Public Shared Function GetDireccionDepositoColonial() As String
        Dim intDirDepColonial As String
        intDirDepColonial = CheckStr(ConfigurationManager.AppSettings("DirDepColonial"))

        Return intDirDepColonial

    End Function

#End Region

#Region "Tel�fono de Dep�sito"
    Public Shared Function GetTelefonoDepositoZarate() As String
        Dim intTelDepZarate As String
        intTelDepZarate = CheckStr(ConfigurationManager.AppSettings("TelfDepZarate"))

        Return intTelDepZarate

    End Function

    Public Shared Function GetTelefonoDepositoAte() As String
        Dim intTelDepAte As String
        intTelDepAte = CheckStr(ConfigurationManager.AppSettings("TelfDepAte"))

        Return intTelDepAte

    End Function

    Public Shared Function GetTelefonoSantaAnita() As String
        Dim intTelDepSantaAnita As String
        intTelDepSantaAnita = CheckStr(ConfigurationManager.AppSettings("TelfDepSantaAnita"))

        Return intTelDepSantaAnita

    End Function

    Public Shared Function GetTelefonoColonial() As String
        Dim intTelDepColonial As String
        intTelDepColonial = CheckStr(ConfigurationManager.AppSettings("TelDepColonial"))

        Return intTelDepColonial

    End Function
#End Region

#Region "Im�genes de Dep�sito"
    Public Shared Function GetImagenDepZarate() As String
        Dim intTelDepZarate As String
        intTelDepZarate = CheckStr(ConfigurationManager.AppSettings("ImgZarate"))

        Return intTelDepZarate

    End Function

    Public Shared Function GetImagenDepAte() As String
        Dim intTelDepAte As String
        intTelDepAte = CheckStr(ConfigurationManager.AppSettings("ImagenAte"))

        Return intTelDepAte

    End Function

    Public Shared Function GetImagenDepSantaAnita() As String
        Dim intTelDepSantaAnita As String
        intTelDepSantaAnita = CheckStr(ConfigurationManager.AppSettings("ImagenSantaAnita"))

        Return intTelDepSantaAnita

    End Function

    Public Shared Function GetImagenDepColonial() As String
        Dim intTelDepColonial As String
        intTelDepColonial = CheckStr(ConfigurationManager.AppSettings("ImagenColonial"))

        Return intTelDepColonial

    End Function
#End Region

#End Region
    ''//////////////////////////////////// MIGRAR A COMPONENTES DATOS ///////////////////////////////////
    ''//////////////////////////////////// MIGRAR A COMPONENTES DATOS ///////////////////////////////////

    Private Shared strNameCnxSIAT001 As String = "BDSIAT001"
    Private Shared strNameCnxSIAT002 As String = "BDSIAT002"

    Public Shared Function fdta_Papeleta_BuscarEstado(ByVal pshsiCodMun As Int16, ByVal pstrcPapele As String) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Papeleta_BuscarEstado", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psiCodMun", pshsiCodMun)
        cmd.Parameters.AddWithValue("@pcPapele", pstrcPapele)

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function

    Public Function fdta_Infraccion_BuscarPorCodigo(ByVal pdtFechaRef As Date, ByVal piCodPPo As Int16, ByVal piCodTFo As Int16, ByVal pstrCodFal As String) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Infraccion_BuscarPorCodigo", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psdFechaRef", pdtFechaRef)
        cmd.Parameters.AddWithValue("@psiCodPPo", piCodPPo)
        cmd.Parameters.AddWithValue("@psiCodTFo", piCodTFo)
        cmd.Parameters.AddWithValue("@pcCodFal", pstrCodFal)

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function
    ''//////////////////////////////////// FIN - MIGRAR A COMPONENTES ///////////////////////////////////







End Class
