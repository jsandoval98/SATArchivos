Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL
Imports System.IO

Partial Class modulos_CarritoPagosPagarV2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            pPagarV3()
        End If
    End Sub

    Private Sub pPagarV2()

        Dim dsCarrito As DataSet = GetCarrito()
        Dim dblTotalWeb As Double = 0
        Dim dblTotalSiat As Double = 0
        Dim strCodPer As String = ""
        Dim intCantidad As Integer = 0
        Dim i As Integer
        Dim dtPagos As New DataTable
        Dim oBLL As ConsultasVarias
        Dim oBLLPagos As New ConsultasWeb
        Dim strCuotaUnica As String = ""
        Dim strDocumento As String
        Dim dblMontoWeb, dblMontoSiat As Double
        Dim strDiferencias As String = ""
        Dim strCodCre As String
        Dim strCadenaEnvio As String = ""
        Dim strNumOperacion As String = ""
        Dim strCorreo1, strCorreo2, strTipoTarjeta, strPAN, strAnio, strMes As String
        Dim intCodUsu As Integer = CheckInt(Session.Item("ncodusu"))
        Dim strError As String = "Ha ocurrido un error al procesar el pedido, favor de reintentar mas tarde. "
        Dim bolCuotaUnica As Boolean = False

        strCorreo1 = Request.Form("hidEmail")
        strCorreo2 = CheckStr(Session.Item("email"))

        If strCorreo1.ToLower <> strCorreo2.ToLower Or intCodUsu <= 1 Then
            Me.lblMensajeServer.Text = strError + "Cod: 101. " + strCorreo1 + " | " + strCorreo2 + " | " + intCodUsu.ToString
            Exit Sub
        End If

        strTipoTarjeta = Request.Form("TipoTar")
        strPAN = Request.Form("PAN")
        strAnio = Request.Form("EXPIRYYEAR")
        strMes = Request.Form("EXPIRYMONTH")

        If Not IsNumeric(strTipoTarjeta) Then
            Me.lblMensajeServer.Text = strError + "Cod: 102. "
            Exit Sub
        End If

        If strTipoTarjeta <> "1" Then '1 = Scotia
            If strPAN = "" Or strAnio = "" Or strMes = "" Then
                Me.lblMensajeServer.Text = strError + "Cod: 103. "
                Exit Sub
            End If
            If Not IsNumeric(strAnio) Or Not IsNumeric(strMes) Then
                Me.lblMensajeServer.Text = strError + "Cod: 104. "
                Exit Sub
            End If
        End If

        If Not dsCarrito Is Nothing Then
            If dsCarrito.Tables.Count = 0 Then
                Exit Sub
            End If
            oBLL = New ConsultasVarias
            dtPagos = oBLL.BuscarDetalleCuentaCte(GetConexionSiatTributosLinea, GetMuniID, dsCarrito.Tables(0), GetFecha)
            intCantidad = dtPagos.Rows.Count
            If intCantidad > 0 Then
                For i = 0 To dtPagos.Rows.Count - 1
                    With dtPagos.Rows(i)
                        strDocumento = CheckStr(.Item("documento")).Replace(".", "")
                        strCodPer = CheckStr(.Item("icodper"))
                        strCodCre = CheckStr(.Item("siCodCre"))
                        dblMontoWeb = Math.Round(CheckDbl(.Item("monto")), 2)
                        If strCodCre = "200" Then
                            dblMontoSiat = Math.Round(CheckDbl(.Item("montosiat")) - CheckDbl(.Item("descuento")), 2)
                        Else
                            dblMontoSiat = Math.Round(CheckDbl(.Item("montosiat")), 2)
                        End If
                        dblTotalWeb += Math.Round(dblMontoWeb, 2)
                        dblTotalSiat += Math.Round(dblMontoSiat, 2)
                        If dblMontoWeb <> dblMontoSiat Then
                            strDiferencias += strDocumento + ";"
                        End If
                    End With
                    'registrar la cuota unica en caso exista
                    strCuotaUnica = CheckStr(dtPagos.Rows(i)("cuotaunica"))
                    If strCuotaUnica <> "" Then
                        bolCuotaUnica = True
                    End If
                Next
            End If
        End If
        oBLLPagos = Nothing
        oBLL = Nothing

        If dblTotalWeb > 0 And Math.Round(dblTotalWeb, 2) = Math.Round(dblTotalSiat, 2) Then

            Using oBLLTx As New SAT.HomeSiteBLL.ProcesosWEB
                Dim dsTX As DataSet
                dsTX = oBLLTx.RegistrarPago(strTipoTarjeta, strCorreo1, dtPagos.Rows.Count, dblTotalWeb, GetIPTerminal, "", intCodUsu, dtPagos)
                If dsTX.Tables(0).Rows.Count > 0 Then
                    strNumOperacion = CheckStr(dsTX.Tables(0).Rows(0)("VCTRN_NUMERO"))
                End If
            End Using

            If strNumOperacion <> "" Then
                dsCarrito.Tables.Clear()
                dsCarrito.Tables.Add(dtPagos.Copy)
                SalvarCarrito(dsCarrito)

                If bolCuotaUnica Then
                    For Each drTemp As DataRow In dtPagos.Rows
                        strCuotaUnica = CheckStr(drTemp("cuotaunica"))
                        strDocumento = CheckStr(drTemp("documento")).Replace(".", "")
                        If strCuotaUnica <> "" Then
                            oBLLPagos.PagosVirtualesRegistrarCuotaUnica(GetConexionPagosVirtuales, strDocumento, strCuotaUnica, strNumOperacion)
                        End If
                    Next
                End If

                strCadenaEnvio = strNumOperacion + "|" + _
                                  strCorreo1 + "|" + _
                                  intCodUsu.ToString() + "|" + _
                                  intCantidad.ToString + "|" + _
                                  strTipoTarjeta + "|" + _
                                  strPAN + "|" + _
                                  strAnio + "|" + _
                                  strMes + "|" + _
                                  dblTotalSiat.ToString("#0.00")

                dsCarrito.Tables(0).Clear()
                SalvarCarrito(dsCarrito)

                Response.Redirect(BuscarMensaje("pagina_pagos_virtuales") + "?" + SetURL("mysession", MySessionID) + "&" + SetURL("par", strCadenaEnvio))

            End If


        Else
            'mensaje error
            Dim oFile As New StreamWriter(GetRutaFisica("../app_data/") + "ErrorCarritoSuma.txt", True)
            oFile.WriteLine("-----------------------" + Date.Now.ToString + "-------------------")
            oFile.WriteLine("Cod  :" + strCodPer.ToString)
            oFile.WriteLine("Web  :" + dblTotalWeb.ToString)
            oFile.WriteLine("Siat :" + dblTotalSiat.ToString)
            oFile.WriteLine("Dif  :" + strDiferencias)
            Me.lblMensajeServer.Text = "Ha ocurrido un error al procesar el pedido, favor de reintentar mas tarde."
            oFile.Close()
        End If

    End Sub

    Private Sub pPagarV3()

        Dim dsCarrito As DataSet = GetCarrito()
        Dim dblTotalWeb As Double = 0
        Dim dblTotalSiat As Double = 0
        Dim strCodPer As String = ""
        Dim intCantidad As Integer = 0
        Dim i As Integer
        Dim dtPagos As New DataTable
        Dim oBLL As ConsultasVarias
        Dim oBLLPagos As New ConsultasWeb
        Dim strCuotaUnica As String = ""
        Dim strDocumento As String
        Dim dblMontoWeb, dblMontoSiat As Double
        Dim strDiferencias As String = ""
        Dim strCodCre As String
        Dim strCadenaEnvio As String = ""
        Dim strNumOperacion As String = ""
        Dim strCorreo1, strCorreo2, strTipoTarjeta, strPAN, strAnio, strMes As String
        Dim intCodUsu As Integer = CheckInt(Session.Item("ncodusu"))
        Dim strError As String = "Ha ocurrido un error al procesar el pedido, favor de reintentar mas tarde. "
        Dim bolCuotaUnica As Boolean = False

        strCorreo1 = Request.Form("ctl00$cplSecond$hidEmail")
        strCorreo2 = CheckStr(Session.Item("email"))

        If strCorreo1.ToLower <> strCorreo2.ToLower Or intCodUsu <= 1 Then
            Me.lblMensajeServer.Text = strError + "Cod: 101. " + strCorreo1 + " | " + strCorreo2 + " | " + intCodUsu.ToString
            Exit Sub
        End If

        strTipoTarjeta = Request.Form("ctl00$cplSecond$TipoTar")
        strPAN = ""
        strAnio = ""
        strMes = ""

        If Not IsNumeric(strTipoTarjeta) Then
            Me.lblMensajeServer.Text = strError + "Cod: 102. "
            Exit Sub
        End If

        If Not dsCarrito Is Nothing Then
            If dsCarrito.Tables.Count = 0 Then
                Exit Sub
            End If
            oBLL = New ConsultasVarias
            dtPagos = oBLL.BuscarDetalleCuentaCte(GetConexionSiatTributosLinea, GetMuniID, dsCarrito.Tables(0), GetFecha)
            intCantidad = dtPagos.Rows.Count
            If intCantidad > 0 Then
                For i = 0 To dtPagos.Rows.Count - 1
                    With dtPagos.Rows(i)
                        strDocumento = CheckStr(.Item("documento")).Replace(".", "")
                        strCodPer = CheckStr(.Item("icodper"))
                        strCodCre = CheckStr(.Item("siCodCre"))
                        dblMontoWeb = Math.Round(CheckDbl(.Item("monto")), 2)
                        If strCodCre = "200" Then
                            dblMontoSiat = Math.Round(CheckDbl(.Item("montosiat")) - CheckDbl(.Item("descuento")), 2)
                        Else
                            dblMontoSiat = Math.Round(CheckDbl(.Item("montosiat")), 2)
                        End If

                        'Solo para Papeletas DDJJ
                        Dim strDic As String = GetUrlLibre("dic")
                        If strDic = "1" Then
                            dblMontoSiat = dblMontoWeb
                        End If

                        dblTotalWeb += Math.Round(dblMontoWeb, 2)
                        dblTotalSiat += Math.Round(dblMontoSiat, 2)
                        If dblMontoWeb <> dblMontoSiat Then
                            strDiferencias += strDocumento + ";"
                        End If
                    End With
                    'registrar la cuota unica en caso exista
                    strCuotaUnica = CheckStr(dtPagos.Rows(i)("cuotaunica"))
                    If strCuotaUnica <> "" Then
                        bolCuotaUnica = True
                    End If
                Next
            End If
        End If
        oBLL = Nothing

        If dblTotalWeb > 0 And Math.Round(dblTotalWeb, 2) = Math.Round(dblTotalSiat, 2) Then

                Using oBLLTx As New SAT.HomeSiteBLL.ProcesosWEB
                    Dim dsTX As DataSet
                    dsTX = oBLLTx.RegistrarPago(strTipoTarjeta, strCorreo1, dtPagos.Rows.Count, dblTotalWeb, GetIPTerminal, "", intCodUsu, dtPagos.Copy)
                    If dsTX.Tables(0).Rows.Count > 0 Then
                        strNumOperacion = CheckStr(dsTX.Tables(0).Rows(0)("VCTRN_NUMERO"))
                    End If
                End Using

                If strNumOperacion <> "" Then
                    dsCarrito.Tables.Clear()
                    dsCarrito.Tables.Add(dtPagos.Copy)
                    SalvarCarrito(dsCarrito)

                    If bolCuotaUnica Then
                        For Each drTemp As DataRow In dtPagos.Rows
                            strCuotaUnica = CheckStr(drTemp("cuotaunica"))
                            strDocumento = CheckStr(drTemp("documento")).Replace(".", "")
                            If strCuotaUnica <> "" Then
                                oBLLPagos.PagosVirtualesRegistrarCuotaUnica(GetConexionPagosVirtuales, strDocumento, strCuotaUnica, strNumOperacion)
                            End If
                        Next
                    End If
                    oBLLPagos = Nothing

                    strCadenaEnvio = strNumOperacion + "|" + _
                                  strCorreo1 + "|" + _
                                  intCodUsu.ToString() + "|" + _
                                  intCantidad.ToString + "|" + _
                                  strTipoTarjeta + "|" + _
                                  strPAN + "|" + _
                                  strAnio + "|" + _
                                  strMes + "|" + _
                                  dblTotalSiat.ToString("#0.00")

                dsCarrito.Tables(0).Clear()
                    SalvarCarrito(dsCarrito)

                'PRUEBA -------------------------------------------------------------------------------------
                'mensaje error
                Dim oFile As New StreamWriter(GetRutaFisica("../app_data/") + "ErrorCarritoSuma.txt", True)
                oFile.WriteLine("-----------------------" + Date.Now.ToString + "-------------------")
                oFile.WriteLine("Cod  :" + strCodPer.ToString)
                oFile.WriteLine("Web  :" + dblTotalWeb.ToString)
                oFile.WriteLine("Siat :" + dblTotalSiat.ToString)
                oFile.WriteLine("Dif  :" + strDiferencias)
                oFile.WriteLine(BuscarMensaje("pagina_pagos_virtuales") + "?" + SetURL("mysession", MySessionID) + "&" + SetURL("par", strCadenaEnvio))
                oFile.WriteLine(BuscarMensaje("pagina_pagos_virtuales") + "?")
                oFile.WriteLine("mysession=" + MySessionID() + "&")
                oFile.WriteLine("par=" + strCadenaEnvio)

                Me.lblMensajeServer.Text = "Ha ocurrido un error al procesar el pedido, favor de reintentar mas tarde."
                oFile.Close()
                'PRUEBA -------------------------------------------------------------------------------------

                Response.Redirect(BuscarMensaje("pagina_pagos_virtuales") + "?" + SetURL("mysession", MySessionID) + "&" + SetURL("par", strCadenaEnvio))

            End If


            Else
                'mensaje error
                Dim oFile As New StreamWriter(GetRutaFisica("../app_data/") + "ErrorCarritoSuma.txt", True)
            oFile.WriteLine("-----------------------" + Date.Now.ToString + "-------------------")
            oFile.WriteLine("Cod  :" + strCodPer.ToString)
            oFile.WriteLine("Web  :" + dblTotalWeb.ToString)
            oFile.WriteLine("Siat :" + dblTotalSiat.ToString)
            oFile.WriteLine("Dif  :" + strDiferencias)
            Me.lblMensajeServer.Text = "Ha ocurrido un error al procesar el pedido, favor de reintentar mas tarde."
            oFile.Close()
        End If

        oBLLPagos = Nothing

    End Sub

End Class
