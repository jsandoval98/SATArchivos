/* MENU */
function init(){
}

$(function() {
    $("#menu").accordion({
      heightStyle: "content"
    });
});

$(document).ready(function() {
    if ($("#ctl00_cplPrincipal_lblTitulo").html() == "TOTAL DEUDA POR TRIBUTOS") {
        $("#menu").accordion({
            animate: false,
            active: 0
        });
        $("#menuOption01").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "IMPUESTO VEHICULAR") {
        $("#menu").accordion({
            animate: false,
            active: 1
        });
        $("#menuOption02").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "IMPUESTO PREDIAL") {
        $("#menu").accordion({
            animate: false,
            active: 1
        });
        $("#menuOption03").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "ARBITRIOS") {
        $("#menu").accordion({
            animate: false,
            active: 1
        });
        $("#menuOption04").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "ALCABALA") {
        $("#menu").accordion({
            animate: false,
            active: 1
        });
        $("#menuOption05").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "MULTAS TRIBUTARIAS") {
        $("#menu").accordion({
            animate: false,
            active: 1
        });
        $("#menuOption06").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "DEUDA POR INFRACCIONES") {
        $("#menu").accordion({
            animate: false,
            active: 2
        });
        $("#menuOption07").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "INFRACCIONES DEL CONDUCTOR") {
        $("#menu").accordion({
            animate: false,
            active: 2
        });
        $("#menuOption9").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "CAPTURA DE VEHICULOS") {
        $("#menu").accordion({
            animate: false,
            active: 3
        });
        $("#menuOption10").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "INTERNAMIENTO DE VEHICULOS") {
        $("#menu").accordion({
            animate: false,
            active: 3
        });
        $("#menuOption11").css("color", "#0080ba");
    } else if ($("#ctl00_cplPrincipal_lblTitulo").html() == "CONSULTA DE PAGOS") {
        $("#menu").accordion({
            animate: false,
            active: 4
        });
        $("#menuOption13").css("color", "#0080ba");
    } else if ($("#pagoweb").html() == "PAGOS DESDE LA WEB DEL SAT") {
        $("#menu").accordion({
            animate: false,
            active: 6
        });
        $("#menuOption16").css("color", "#0080ba");
    } else if ($("#webBanco").html() == "PAGOS DESDE LA WEB DE SU BANCO") {
        $("#menu").accordion({
            animate: false,
            active: 6
        });
        $("#menuOption20").css("color", "#0080ba");
	} else if ($("#pagoweb").html() == "VER DEMO PAGO WEB") {
        $("#menu").accordion({
            animate: false,
            active: 6
        });
        $("#menuOption18").css("color", "#0080ba");	
    } else {
    }
	$("#menu").accordion({
        animate: true
    });
});

$(document).ready(function(){
	if($(window).width() > 767){
		$("a.openmenu").attr("id","");
	} else {
		$("a.openmenu").attr("id","openmenu");		
	}
});

$(window).resize(function(){
	if($(window).width() > 767){
		$("a.openmenu").attr("id","");
	} else {
		$("a.openmenu").attr("id","openmenu");		
	}
});


/* MENU MOVIL */
$("#openmenu").click(function(){
    verMenu();	
});
function verMenu(){
    $('#menu').slideToggle('slow');
};


